from qgis.PyQt.QtWidgets import QToolButton

class CustomToolButton(QToolButton):
    def __init__(self, parent=None):
        super(CustomToolButton, self).__init__(parent)
        
        self.setPopupMode(QToolButton.MenuButtonPopup)
        self.triggered.connect(self.chageAction)
        
    def chageAction(self, action):
        self.setDefaultAction(action)