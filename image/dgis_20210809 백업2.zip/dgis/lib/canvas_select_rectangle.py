import os
import shutil
import requests

from qgis.utils import iface
from qgis.gui import QgsMapToolEmitPoint, QgsRubberBand
from qgis.core import (
    QgsVectorLayer, QgsFeature, QgsPointXY, QgsWkbTypes,
    QgsGeometry, QgsProject, QgsVectorFileWriter, QgsRectangle
)
from qgis.PyQt.QtCore import Qt, pyqtSignal

from ..Util import overlapFileName, Mss_bar_warn, runProcessing

class SelectExtentOnCanvas(QgsMapToolEmitPoint):
    reSelectSignal = pyqtSignal()
    successfulFlagSignal = pyqtSignal(str, str)
    endEventSignal = pyqtSignal()

    def __init__(self, canvas):
        QgsMapToolEmitPoint.__init__(self, canvas)
        self.canvas = canvas
        
        self.rubberBand = QgsRubberBand(self.canvas, True)
        self.rubberBand.setWidth(1)
        self.reset()

    def reset(self):
        self.startPoint = self.endPoint = None
        self.isEmittingPoint = False
        self.rubberBand.reset(True)

    def canvasPressEvent(self, e):
        self.startPoint = self.toMapCoordinates(e.pos())
        self.endPoint = self.startPoint
        self.isEmittingPoint = True
        self.showRect(self.startPoint, self.endPoint)
    
    def canvasMoveEvent(self, e):
        if not self.isEmittingPoint:
          return
    
        self.endPoint = self.toMapCoordinates(e.pos())
        self.showRect(self.startPoint, self.endPoint)
    
    def showRect(self, startPoint, endPoint):
        self.rubberBand.reset(QgsWkbTypes.PolygonGeometry)
        if startPoint.x() == endPoint.x() or startPoint.y() == endPoint.y():
          return
    
        point1 = QgsPointXY(startPoint.x(), startPoint.y())
        point2 = QgsPointXY(startPoint.x(), endPoint.y())
        point3 = QgsPointXY(endPoint.x(), endPoint.y())
        point4 = QgsPointXY(endPoint.x(), startPoint.y())
    
        self.rubberBand.addPoint(point1, False)
        self.rubberBand.addPoint(point2, False)
        self.rubberBand.addPoint(point3, False)
        self.rubberBand.addPoint(point4, True)    # true to update canvas
        self.rubberBand.show()
    
    def rectangle(self):
        if self.startPoint is None or self.endPoint is None:
          return None
        elif self.startPoint.x() == self.endPoint.x() or self.startPoint.y() == self.endPoint.y():
          return None
    
        return QgsRectangle(self.startPoint, self.endPoint)
    
    def canvasReleaseEvent(self, e):
        self.isEmittingPoint = False
        r = self.rectangle()        
        self.reset()

        self.saveClipAsShape(r)
    
    def dataSettings(self, path, layers, extension, visible=True):
        self.path = path
        self.layers = layers
        self.extension = extension
        self.visible = visible
    
    def saveClipAsShape(self, r):
        if not r: return 
        reFlag = True
        self.endEventSignal.emit()
    
        tempLayer = self.createSelectAreaPolygon(r)
        for l in self.layers:
            if type(l)!=QgsVectorLayer: continue;
            try:
                params = { 
                    'INPUT' : l.source(), 
                    'INPUT_FIELDS' : [], 
                    'OUTPUT' : 'TEMPORARY_OUTPUT', 
                    'OVERLAY' : tempLayer.source(), 
                    'OVERLAY_FIELDS' : [], 
                    'OVERLAY_FIELDS_PREFIX' : '' 
                }
                
                rst = runProcessing("native:intersection", params)['OUTPUT']

                #intersection에서 나온 결과값이 없다면 파일을 저장하지 않음.
                if rst.featureCount()>0:
                    self.createShapeFile(l, rst)
                    reFlag = False
                
            except Exception as e:
                Mss_bar_warn(f"{l.name()} 레이어를 내보내는 도중 오류가 발생하였습니다. 자세한 내용은 공간처리 로그 메시지 박스를 참조하시길 바랍니다 . : {e}")
        
        QgsProject.instance().removeMapLayer(tempLayer.id())
        if reFlag: 
            self.reSelectSignal.emit()
            
    def createSelectAreaPolygon(self, r):
        coord = r.asPolygon().split(", ")
        points = []
        for c in coord:
            x, y = c.split(" ")
            points.append(QgsPointXY(float(x), float(y)))

        #layer = QgsVectorLayer('Polygon', 'temporary_polygon_layer' , 'memory')
        projectCrs = self.canvas.mapSettings().destinationCrs().authid()
        layer = QgsVectorLayer('Polygon?crs='+projectCrs, 'temporary_polygon_layer' , 'memory')
        #layer = QgsVectorLayer('Polygon?crs=EPSG:5181', 'temporary_polygon_layer' , 'memory')

        prov = layer.dataProvider()
        feat = QgsFeature()
        feat.setGeometry(QgsGeometry.fromPolygonXY([points]))
        prov.addFeatures([feat])
        layer.updateExtents()
        QgsProject.instance().addMapLayer(layer, True)
        
        return layer
    
    def createShapeFile(self, oriLyr, rstLry=None):
        rstLry = rstLry if rstLry else oriLyr
        ex = ".shp" if "ESRI" in self.extension else ".kml"
        path = overlapFileName(os.path.join(self.path, oriLyr.name()+'_clip'+ex))
        rstName = os.path.basename(path).replace(ex, "")
        
        rstPrint, err = QgsVectorFileWriter.writeAsVectorFormat(rstLry, path, 'utf-8', driverName=self.extension)
        self.successfulFlagSignal.emit(err, path)
#         rstLayer = QgsVectorLayer(path, rstName, 'ogr')
#         QgsProject.instance().addMapLayer(rstLayer, self.visible)