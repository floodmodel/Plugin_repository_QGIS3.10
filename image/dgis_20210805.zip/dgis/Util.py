# -*- coding: utf-8 -*-
import os
import time
import socket
import processing
import urllib.request
import xml.etree.ElementTree as ET
from PIL import Image
from enum import Enum, auto

from qgis.gui import QgsStatusBar
from qgis.core import Qgis, QgsProcessingFeedback
from qgis.utils import iface
from qgis.PyQt import uic
from PyQt5.QtCore import Qt
from PyQt5.QtGui import *
from PyQt5.QtWidgets import *
from pyplugin_installer import installer as plugin_installer
from qgis.PyQt.QtCore import QSettings, QTimer
    

# 네트워크 연결 확인 부분 
def Chk_internet():
    ipaddress=socket.gethostbyname(socket.gethostname())
    if ipaddress=="127.0.0.1":
        return False
    else:
        return True

# 플러그인 버전 체크 (github 확인)    
def Chk_Version():

    settings = QSettings()
    pluginName = unicode(settings.value('/PluginReloader/plugin', '', type=str))
    pluginInfo = plugin_installer.plugins.all()[pluginName]
    installVersion = pluginInfo['version_installed']
    githubUrl = 'https://raw.githubusercontent.com/floodmodel/Plugin_repository_QGIS3.8/master/plugins.xml'
    response = urllib.request.urlopen(githubUrl).read()
    tree = ET.fromstring(response)
    doc = tree.findall('pyqgis_plugin')[0]
    githubVersion = doc.find('version').text
        
    if installVersion!=githubVersion:
        QMessageBox.information(None, 'DGIS', f"설치된 버전 : {installVersion} \n설치 가능 버전 : {githubVersion} \n최신 버전이 있습니다. \n업데이트 하세요!")


def Mss_Err(message):
    QMessageBox.warning(None, 'DGIS',str(message))

def Mss_inf(message):
    QMessageBox.information(None, 'DGIS',str(message))

def Mss_bar_error(msg, context="DGIS"):
    iface.messageBar().pushMessage(context, str(msg), level=Qgis.Critical)

def Mss_bar_warn(msg, context="DGIS", dur=5):
    iface.messageBar().pushMessage(context, str(msg), level=Qgis.Warning, duration=dur)
    
def Mss_bar_info(msg, context="DGIS", dur=5):
    iface.messageBar().pushMessage(context, str(msg), level=Qgis.Info, duration=dur)

# 테스트용
def MakeWater(mapimage):
    path = os.path.dirname(os.path.realpath(__file__))
    logoPath = path +'/icon/test.png' # 로고파일 
    rstPath = mapimage
#     test3 = path +'\icon\\logo.png'  

    # 로고 파일을 불러옵니다.
    logo = Image.open(logoPath)

    # 이미지를 불러옵니다.
    image = Image.open(rstPath)
    Xdim, Ydim = image.size

    resized_logo = logo.resize((Xdim, Ydim))
    image.paste(resized_logo, (int(Xdim/50), int(Ydim/50)), resized_logo)
    image.save(rstPath)
    image.close()

def icon_path(icon_filename):
    plugin_dir = os.path.dirname(__file__)
    return os.path.join(plugin_dir,  icon_filename)


def floder_dialog():
    folder_path = QFileDialog.getExistingDirectory(None, "Select Directory")
    return folder_path

def overlapFileName(path):
    osIsfile = os.path.isfile
    osSplit= os.path.split
    osSpliText = os.path.splitext
    
    if osIsfile(path):
        flag = True
        j = 1
        while(flag):
            j +=1
            folder, filename = osSplit(path)
            filename, extension = osSpliText(filename)
            
            splitCount = len(str(j))+3
            splitName = f" ({str(j)})"
            if filename[-splitCount:]==splitName:
                filename = filename[:-splitCount]
            
            rePath = f"{folder}/{filename}{splitName}{extension}"
            
            if not osIsfile(rePath):
                path = rePath
                flag = False
                
    return path


def getfileList(folderlist):
    _bin_List=[]
    for folder in folderlist:
        filenames = os.listdir(folder)
        for filename in filenames:
            full_filename = folder +"/"+ filename
            ext = os.path.splitext(full_filename)[-1]
            if ext.upper() == '.BIN': 
                _bin_List.append(full_filename)
    return _bin_List


def runProcessing(runType, params):
    global progressbar
    QApplication.setOverrideCursor(Qt.BusyCursor)
    progressMessageBar = iface.statusBarIface()
    progressbar = progressMessageBar.findChildren(QProgressBar)[1]
    toolButton = progressbar.parent()
    
    progressbar.setMaximum(100)
    toolButton.setVisible(True)
    toolButton.setEnabled(False)

    def setProgressValue(progress):
        global progressbar
        QApplication.processEvents()
        progressbar.setValue(progress) 
    
    f = QgsProcessingFeedback()
    f.progressChanged.connect(setProgressValue)
    QApplication.processEvents()
    
    try:
        rst = processing.run(runType, params, feedback=f)
        return rst
    
    except Exception as e:
        raise Warning(str(e)) 
    
    finally:
        progressbar.setMaximum(0)
        toolButton.setEnabled(True)
        progressbar.parent().setVisible(False)
        QApplication.restoreOverrideCursor()
    
