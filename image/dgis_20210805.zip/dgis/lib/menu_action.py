import os
from qgis.PyQt.QtCore import Qt
from qgis.core import QgsVectorLayer
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import QMenu, QAction

from ..Util import icon_path, floder_dialog
from .connect_geoserver import getLayerList, getWFSLayers, getWCSLayers
from ..KepoLoad_dialog import KepoLoadDialog
from ..OUTPUT_dialog import OUTPUTDialog
from ..Print_dialog import PrintDialog
from ..index_clip_dialog import IndexClipDialog
from .save_as_image import SaveAsImage

class MenuAction:
    def __init__(self, iface):
        self.iface = iface
        
        self.menu = self.createMenu()
        allActions = self.iface.mainWindow().menuBar().actions()
        lastAction = allActions[-1]
        self.iface.mainWindow().menuBar().insertMenu(lastAction, self.menu)   
        
        self.first_start = True
        self.save = SaveAsImage()

        #Action connnect - 액션 기능실행"
        #각 Action에 직접 connect : retrun bool(toggled)
        #for a in (actionKoreaList+actionOtherCountryList+actionCountryList):
        #    a.triggered.connect(runAction)
       
       
        #각 Action 이벤트를 한 함수로 통일한다면 아래 방법으로 가능 : return QAction
        self.menu.triggered.connect(self.runAction)
        
    def createMenu(self):
        #메뉴 선언
        mainWindow = self.iface.mainWindow()
        menuBar = mainWindow.menuBar()
        menu = QMenu("DGIS (&D)", menuBar)
        allActions = menuBar.actions()
        lastAction = allActions[-1]
        
        #액션 선언
        subMenu = QMenu("GeoServer 레이어 목록 조회 (&G)", menuBar)
        subSubMenu = QMenu("레이어 (&L)", menuBar)
        
        #액션 선언
        action1 = menu.addAction(QIcon(icon_path('icon/save image.png')), '이미지 저장')
        menu.addAction(QIcon(icon_path('icon/load data.png')), '지도 출력')
        menu.addAction(QIcon(icon_path('icon/view all.jpg')), '한전 전주 가져오기')
        menu.addAction(QIcon(icon_path('icon/view vector.jpg')), '설비정보 내보내기')
        #menu.addAction(QIcon(icon_path('icon/basemap.png')), '배경맵 선택')
        menu.addSeparator()
        
        #subMenu.addAction(QIcon(icon_path('icon/view all.jpg')), '인덱스 도역도로 자르기')
        #subMenu.addAction(QIcon(icon_path('icon/view vector.jpg')), '테스트')
        #subMenu.addAction(QIcon(icon_path('icon/view raster.png')), '테스트')
        
        #subSubMenu.addAction(QIcon(icon_path('icon/view info.png')), '테스트')
        #subSubMenu.addAction(QIcon(icon_path('icon/modify vector.png')), '테스트')
        #action2 = subSubMenu.addAction(QIcon(icon_path('icon/modify raster.png')), '테스트')
        #subSubMenu.addAction(QIcon(icon_path('icon/save layer.png')), '테스트')
        #subSubMenu.insertSeparator(action2)
        
        #메인 메뉴에 액션 및 하위 메뉴 추가        
        #subMenu.addMenu(subSubMenu)
        #menu.addMenu(subMenu)
        
        return menu
    
    
    def runAction(self, a):
        actions = {
            "이미지 저장" : self.save.SaveMapAsImage,
            "지도 출력" : PrintDialog,
            "한전 전주 가져오기" : KepoLoadDialog,
            "설비정보 내보내기" : OUTPUTDialog,
            "인덱스 도역도로 자르기" : IndexClipDialog
        }
        
        try:
            for key in actions:
                if a.text() == key:
                        actions[key]().exec_()
        
        except AttributeError:
            pass