import os

from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtGui import QPalette, QPixmap, QBrush

class CSS:
    def getIconPath(self, fileName):
        filePath = os.path.join(os.path.dirname(__file__), "../icon", fileName)
        return filePath
    
    def grayBackground(self):
        css = "background-color: rgb(244, 244, 244);"
        return css

    def whiteBackground(self):
        css = """
            color : rgb(0, 0, 0);
            background-color : rgb(255, 255, 255);
        """
        return css
    
    def blackBackground(self):
        css = """
            color : rgb(255, 255, 255);
            background-color : rgb(0, 0, 0);
        """
        return css
    
    def orangeBackground(self):
        css = """
            color: rgb(255, 255, 255);
            background-color: rgb(206, 110, 10);
        """
        return css
    
    def insertImage(self, fileName, w, h):
        filePath = self.getIconPath(fileName)
        css = f'<img width="{w}" height="{h}" src="{filePath}"/>'
        return css
    
    def changeBackgroundImage(self, fileName, size):
        filePath = self.getIconPath(fileName)
        bkgnd = QPixmap(filePath);
        bkgnd = bkgnd.scaled(size, Qt.IgnoreAspectRatio);
        palette = QPalette();
        palette.setBrush(QPalette.Window, QBrush(bkgnd));
        return palette
        
        
        return css
    
    def infoText(self, conDic):
        content = ""
        for key in conDic.keys():
            content += f"""
                <tr>
                    <td width="50%"><a href="{key}"> {conDic[key][0]} </a></td>
                    <td width="50%" class="right"> {conDic[key][1]} </td>
                </tr>
            """
        
        css = """
            <html>
                <head/>
                <body>
                    <style type="text/css">
                        a:link { color: rgb(99, 99, 99); text-decoration: none; }
                        td { padding-bottom: 10px; color: rgb(99, 99, 99); font-size:9px;}
                        .right { text-align: right; }
                    </style>
                    <table>
                        """+content+"""
                    </table>
                    <br>
                </body>
            </html>
        """
        return css
    
    def moreViewText(self, con, url="더보기"):
        css = f"<a href='{url}' style='color: black; text-decoration: none; font-size: 7pt;'>{con}</a>"
        return css