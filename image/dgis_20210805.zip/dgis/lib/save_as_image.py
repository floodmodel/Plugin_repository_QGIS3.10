from qgis.utils import iface
from qgis.PyQt.QtCore import QLocale
from qgis.PyQt.QtWidgets import QWidget, QPlainTextEdit, QDockWidget, QTabWidget

from ..Util import MakeWater

class SingleTon(type):
    _instances = {}
    
    def __call__(self, *args, **kwargs):
        if self not in self._instances:
            self._instances[self] = super(SingleTon, self).__call__(*args, **kwargs)
        return self._instances[self]

class SaveAsImage(metaclass=SingleTon):
    def __init__(self):
        self.txtDoc = None
        
    def findLogPanel(self):
        msgLog = iface.mainWindow().findChild(QDockWidget, 'MessageLog')  
        tabChild = msgLog.widget().findChild(QTabWidget)
        cnt = tabChild.count() 
        tarName = self.language()[0]
    
        for i in range(cnt):
            txt = tabChild.tabText(i)

            if tabChild.tabText(i)==tarName and tabChild.widget(i)!=QWidget:
                self.txtDoc = tabChild.widget(i).document()
                break
    
        if self.txtDoc!=None:
            self.txtDoc.blockCountChanged.connect(self.getSaveAsImageLog)
#             txtEdit = QPlainTextEdit()
#             tabChild.addTab(txtEdit, tarName)
#             self.txtDoc = txtEdit.document()
    
    def SaveMapAsImage(self):
        if not self.txtDoc:
            self.findLogPanel()
        iface.actionSaveMapAsImage().trigger()
       
    def language(self): 
            local = QLocale()
            lang = local.nativeLanguageName()
            if lang=='한국어':
                return ["메시지", "이미지로 저장"]
            else:
                return ["Messages", "Save as image"]
            
    def getSaveAsImageLog(self, cnt):
        try:
            sp = self.txtDoc.lastBlock().text().split('\xa0\xa0\xa0')
            if len(sp)>2 and sp[1].strip()=="SUCCESS" and sp[2].find(self.language()[1])!=-1:
                findCnt = sp[2].find(":\\")
                drive = sp[2][:findCnt].split(' ')[-1]
                path = (drive+sp[2][findCnt:]).replace("에 성공적으로 저장했습니다", "")
                #이미지 워터마크 삽입하는 소스 
                MakeWater(path)
        except Exception as e:
            print(e)