import requests
import threading

from qgis.PyQt.QtCore import QSettings
from qgis.core import QgsProject, QgsVectorLayer, QgsRasterLayer
from qgis.PyQt.QtWidgets import QMessageBox

def confirmConnctionGeoserver(tot, msgFlag=False):
    try:
        #url = 'http://192.168.100.242:8080/geoserver'
        url = 'http://192.168.123.242:8080/geoserver'
        response = requests.get(url=url, timeout=tot)
        return True
    except Exception as e:
        if msgFlag:
            QMessageBox.warning(None, "Connection error", "GeoServer 연결에 실패했습니다. 서버 또는 인터넷 연결을 확인해 주시길 바랍니다.")
        
    return False    
    
def settingGeoserver(iface):
    try:
        #geoserver 연결 정보
        conDic = {
            'connections-wfs/geoWFS' : {
                'ignoreAxisOrientation' : 'false',
                'invertAxisOrientation' : 'false',
                'maxnumfeatures' : '',
                'pagesize' : '',
                'pagingenabled' : 'true',
                'url' : 'http://192.168.123.242:8080/geoserver/DGIS/wfs?SERVICE=WFS&VERSION=1.1.1',
                'version' : 'auto',
            }
        }
        
        #qgis 탐색기에서 geoserver 연결 정보가 없다면 추가 
        for conName in conDic.keys():
            for key in conDic[conName].keys():
                settingKey = f'qgis/{conName}/{key}'
        
                if not QSettings().contains(settingKey):
                    QSettings().setValue(settingKey, conDic[conName][key])

        iface.reloadConnections()
    except Exception as e:
        print("except:", e)

def settingLayer(iface):
    #geoserver의 레이어 qgis에 자동으로 올리기 
    canvas = iface.mapCanvas()
    crs = "EPSG:5181"

    newdict = {"자체함체전주":"DGIS:jache_hamche_junju",
                "자제전주":"DGIS:jache_junju",
                "한전함체전주":"DGIS:hanjun_hamche_junju",
                "한전전주":"DGIS:hanjun_junju","기타함체전주":"DGIS:etc_hamchejunju",
                "기타전주":"DGIS:etc_junju",
                "자체함체맨홀":"DGIS:jache_hamche_manhole","자체맨홀":"DGIS:jache_manhole",
                "임차함체맨홀":"DGIS:imcha_hamche_manhole","임차맨홀":"DGIS:imcha_manhole",
                "자체가공케이블":"DGIS:jache_gagong_cable","자체지중케이블":"DGIS:jache_jijung_cable",
                "자체지하철케이블":"DGIS:jache_subway_cable",
                "임차케이블":"DGIS:imcha_cable","자체관로":"DGIS:jache_guanlo",
                "임차관로":"DGIS:imcha_guanlo","고객건물":"DGIS:cstm_bld",
                "DIST":"DGIS:dist","자체국사":"DGIS:jache_guksa",
                "임대국사":"DGIS:imde_guksa",
                "배전지능화":"DGIS:bejun_jineung",
                "KTM기지국":"DGIS:ktm_gijiguk",
                "KTF기지국":"DGIS:ktf_gijiguk",
                "LGT기지국":"DGIS:lgt_gijiguk",
                "SKT기지국":"DGIS:skt_gijiguk",
                "STI기지국":"DGIS:sti_gijiguk",
                "KTM중계기":"DGIS:ktm_junggyegi",
                "KTF중계기":"DGIS:ktf_junggyegi",
                "LGT중계기":"DGIS:lgt_junggyegi",
                "SKT중계기":"DGIS:skt_junggyegi",
                "STI중계기":"DGIS:sti_junggyegi",
                "KTMMSC":"DGIS:ktmmsc",
                "KTFMSC":"DGIS:ktfmsc","LGTMSC":"DGIS:lgtmsc","SKTMSC":"DGIS:sktmsc","STIMSC":"DGIS:stimsc",
                "국사":"DGIS:guksa","상호접속국사":"DGIS:sangho_jupsok_gukga",
                "광가입자국":"DGIS:guang_gaipja","맨홀":"DGIS:manhole",
                "기타시설물전주":"DGIS:junju","인수공":"DGIS:insugong",
                "지상광케이블":"DGIS:jisang_guang_cable",
                "지하광케이블":"DGIS:jiha_guang_cable","PE구간":"DGIS:pe_gugan","기타시설물관로":"DGIS:guanlo","기타시설물공동구":"DGIS:gongdonggu"}

    for key, val in newdict.items():
        urlstring=f"http://192.168.123.242:8080/geoserver/DGIS/wfs?service=WFS&version=1.1.0&request=GetFeature&typename={val}&crs={crs}"
        vlayer = QgsVectorLayer(urlstring, key, "WFS")
        QgsProject.instance().addMapLayers([vlayer], True)

     

def getLayerList():
    try:
        #url = 'http://210.92.123.134:8010/geoserver/rest/layers'
        url = 'http://192.168.123.242:8080/geoserver/DGIS'



        headers = {'Content-Type': 'text/xml'}
        
        r = requests.get(url, headers=headers)
        
        layers = [w['name'] for w in r.json()["layers"]["layer"]]
        return layers
    except Exception as e:
        print(e)
        return []
    
    
def getWFSLayers():
    try:
        url = 'http://192.168.123.242:8080/geoserver/DGIS' #/krm_geoserver/featuretypes.json
        #url = 'http://210.92.123.134:8010/geoserver/rest/workspaces' #/krm_geoserver/featuretypes.json
        headers = {'Content-Type': 'text/xml'}
        
        r = requests.get(url, headers=headers)
        workspace = [w['name'] for w in r.json()['workspaces']['workspace']]
        
        lry = []
        for w in workspace:
            fea = requests.get(f"{url}/{w}/featuretypes.json", headers=headers)
            rst = fea.json()['featureTypes']
            if rst:
                for l in rst['featureType']:
                    lry.append(f"{w}:{l['name']}")
        return lry
    except Exception as e:
        print(e)
        return []
    
def getWCSLayers():
    allLayer = getLayerList()
    if not allLayer:
        return []
    wfsLayer = getWFSLayers()
    wcsLayer = [l for l in allLayer if l not in wfsLayer]
    
    return wcsLayer
    
    