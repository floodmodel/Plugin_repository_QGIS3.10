# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'GRM_dockwidget_base.ui'
#
# Created by: PyQt5 UI code generator 5.11.3
#
# WARNING! All changes made in this file will be lost!

from qgis.PyQt import QtCore, QtWidgets


class Ui_GRMDockWidgetBase(object):
    def setupUi(self, GRMDockWidgetBase):
        GRMDockWidgetBase.setObjectName("GRMDockWidgetBase")
        GRMDockWidgetBase.resize(343, 491)
        self.dockWidgetContents = QtWidgets.QWidget()
        self.dockWidgetContents.setObjectName("dockWidgetContents")
        self.gridLayout = QtWidgets.QGridLayout(self.dockWidgetContents)
        self.gridLayout.setObjectName("gridLayout")
        self.treeWidget = QtWidgets.QTreeWidget(self.dockWidgetContents)
        self.treeWidget.setObjectName("treeWidget")
        self.treeWidget.headerItem().setText(0, "1")
        self.gridLayout.addWidget(self.treeWidget, 0, 0, 1, 1)
        GRMDockWidgetBase.setWidget(self.dockWidgetContents)

        self.retranslateUi(GRMDockWidgetBase)
        QtCore.QMetaObject.connectSlotsByName(GRMDockWidgetBase)

    def retranslateUi(self, GRMDockWidgetBase):
        _translate = QtCore.QCoreApplication.translate
        GRMDockWidgetBase.setWindowTitle(_translate("GRMDockWidgetBase", "QGIS-GRM"))
