# -*- coding: utf-8 -*-
import os
import sys
from subprocess import call,Popen

# 2019-04-05 박: 프로그램 개발에 앞서 내부 모듈에서 사용하는 함수 정리해두기     
    
# 파일 존재 여부 체크 함수
def ChFile_Exists(file):
    return os.path.exists(file)
    
# 파일 이름 반환 함수
def GetFile_Name(file):
    #FileName = os.path.splitext(file)[0]
    FileName = os.path.splitext(os.path.basename(file))[0]
    return FileName
    
# 파일폴더 경로 반환 
def GetFileDirectory_Path(file):
    return os.path.dirname(file)

# python 프로그램의 실행 경로를 받아옴 
def GetScriptDirectory_Path():
    scriptDirectory = os.path.dirname(os.path.realpath(__file__)).replace("lib","")
    return scriptDirectory


# 파일 전체를 읽어서 파일 내용을 반환 
def GetRead_Txt(file):
    f = open(file, 'r')
    AllText = f.read()
    f.close()
    return AllText



# 폴더 경로 맞는지 확인
def CheckFolder(path):
    filepath = path.replace('\\', '\\\\')
    if (os.path.isdir(filepath)):
        return True
    else:
        return False

def callExecute(arg):
    result = Popen(arg, shell=True)