﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Max_Value_ASC_Create
{
    class Util
    {
        public bool Check_Folder(string folder_path)
        {
            try
            {
                if (!Directory.Exists(folder_path))
                {
                    Directory.CreateDirectory(folder_path);
                }
                return true;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                return false;
            }
        }

        public bool Check_File(string file_path)
        {
            try
            {
                if (File.Exists(file_path))
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                return false;
            }
        }

        public bool Make_ASC_File(string path)
        {
            try
            {
                if (!File.Exists(path))
                {
                    File.Create(path);
                }
                return true;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                return false;
            }
        }

        public int Check_Out_File_Count(string path)
        {

            return 0;
        }
        
    }
}
