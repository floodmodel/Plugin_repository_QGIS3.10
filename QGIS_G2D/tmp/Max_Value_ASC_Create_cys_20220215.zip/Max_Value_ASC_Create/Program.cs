﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;
using System.IO;

namespace Max_Value_ASC_Create
{
    class Program
    {
        public static int Nrows { get; private set; }
        //[STAThread]
        static void Main(string[] args)
        {
            // 리소스 dll 취득
            AppDomain.CurrentDomain.AssemblyResolve += new ResolveEventHandler(ResolveAssembly);

            //G2D 분석 결과 파일 경로 폴더 단위로 입력 받음 
            string G2D_Folder_path = args[0];

            ////사용자가 지정하는 최소 맥스값
            string limit_Value = args[1];

            ////결과 ASC 파일 경로
            string result_path = args[2];


            //string G2D_Folder_path = "C:\\sample\\G2D\\G2D_Run";
            //string limit_Value = "0";
            //string result_path = "C:\\sample\\G2D\\G2D_Run\\Result\\test.asc";


            //Max 값으로 ASC 파일 만들기 시작
            Make_Body _Make = new Make_Body(G2D_Folder_path, Convert.ToDouble(limit_Value), result_path);
        }

        static Assembly ResolveAssembly(object sender, ResolveEventArgs args)
        {
            Assembly thisAssembly = Assembly.GetExecutingAssembly();
            var name = args.Name.Substring(0, args.Name.IndexOf(',')) + ".dll";

            var resources = thisAssembly.GetManifestResourceNames().Where(s => s.EndsWith(name));
            if (resources.Count() > 0)
            {
                string resourceName = resources.First();
                using (Stream stream = thisAssembly.GetManifestResourceStream(resourceName))
                {
                    if (stream != null)
                    {
                        byte[] assembly = new byte[stream.Length];
                        stream.Read(assembly, 0, assembly.Length);
                        //Console.WriteLine("Dll file load : " + resourceName);
                        return Assembly.Load(assembly);
                    }
                }
            }
            return null;
        }
    }

   
}
