﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using gentle;
using System.Threading;


namespace Max_Value_ASC_Create
{

    public class HeaderInfo
    {
        //헤더 값
        protected int Ncols { get; set; }
        protected int Nrows { get; set; }
        protected double Xllcorner { get; set; }
        protected double Yllcorner { get; set; }
        protected double Cellsize { get; set; }
        protected double NODATA_value { get; set; }
        
        //헤더 파일 
        //protected StringBuilder Header_Lines { get; set; }

        //파일 목록 
        public List<string> G2D_File_List { get; set; }
        Util _util = new Util();

        public HeaderInfo(string g2d_folder)
        {
            try
            {
                if (_util.Check_Folder(g2d_folder))
                {
                    G2D_File_List = Directory.GetFiles(g2d_folder, $"*.out", SearchOption.AllDirectories).OrderBy(s => s).ToList();
                    //G2D_File_List.Sort(naCom);
                }

                //깔끔한 뭐 없나 엄청 지저분허네
                int count = 0;
                string line;
                System.IO.StreamReader file = new System.IO.StreamReader(G2D_File_List[0]);
                while ((line = file.ReadLine()) != null)
                {
                    string[] result = line.Split(' ');
                    if (count == 0) { Ncols = Convert.ToInt16(result[1]); }
                    else if (count == 1) { Nrows = Convert.ToInt16(result[1]); }
                    else if (count == 2) { Xllcorner = Convert.ToDouble(result[1]); }
                    else if (count == 3) { Yllcorner = Convert.ToDouble(result[1]); }
                    else if (count == 4) { Cellsize = Convert.ToDouble(result[1]); }
                    else if (count == 5) { NODATA_value = Convert.ToDouble(result[1]); }
                    else { break; }
                    count++;
                }
                file.Close();

                ////Out 파일 폴더중 제일 처음 파일을 헤더값 받기
                //Header_Lines.Append("ncols " + Ncols.ToString + "\n");
                //Header_Lines.Append("nrows " + Nrows + "\n");
                //Header_Lines.Append("xllcorner " + Xllcorner + "\n");
                //Header_Lines.Append("yllcorner " + Yllcorner + "\n");
                //Header_Lines.Append("cellsize " + Cellsize + "\n");
                //Header_Lines.Append("NODATA_value " + NODATA_value + "\n");

            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }
    }

    //파일들 비교해서 최대값으로 ASC Body 배열 생성 하기 
    public class Make_Body : HeaderInfo
    {
        double[,] mArrayResult;
        string mHeaderStringAll;
        double mNodataValue;
        public Make_Body(string g2d_folder, double limit_value, string reult_asc) : base(g2d_folder)
        {
            try
            {
                int Count = 0;
                foreach (string filepath in G2D_File_List)
                {
                    cAscRasterReader ascfile = new cAscRasterReader(filepath);
                    if (Count == 0)
                    {
                        mArrayResult = new double[ascfile.Header.numberCols, ascfile.Header.numberRows];
                        mArrayResult = ascfile.ValuesFromTL();
                        mNodataValue = ascfile.Header.nodataValue;
                        mHeaderStringAll = ascfile.HeaderStringAll;
                    }
                    else
                    {
                        mArrayResult = cCalculator.staticsticsUsingTwo2DArrayOfASCraster(mArrayResult, ascfile.ValuesFromTL(), NODATA_value, cData.StatisticsType.Maximum, limit_value, false);
                    }
                    Count = Count + 1;
                }
                cTextFile.MakeASCTextFile(reult_asc, mHeaderStringAll, mArrayResult, -1, Convert.ToInt32(mNodataValue));
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }
    }
}

