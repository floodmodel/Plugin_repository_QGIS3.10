﻿# -*- coding: utf-8 -*-
import sys
import os
import os.path
from .lib.Util import *

class G2Dini:
    Proj_File = ""
    QGIS_Path = ""
    Condition_combo=["Select Type", "Depth", "Height"]
    Rainfall_Type=["Select Type", "TextFileMAP", "TextFileASCgrid"]
    def __init__(self):
        MsTitle("G2D")
        QGIS_Path=GetQGIS_Path()
 