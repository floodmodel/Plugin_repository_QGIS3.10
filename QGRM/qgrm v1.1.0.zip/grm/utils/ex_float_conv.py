def ex_to_float(ex: float) -> str:
    """Converts a string to a float, if possible."""
    value = "{:.10f}".format(ex)
    return value.rstrip("0").rstrip(".") if "." in value else value
