# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'Weather_data.ui'
#
# Created by: PyQt5 UI code generator 5.11.3
#
# WARNING! All changes made in this file will be lost!

from qgis.PyQt import QtCore, QtGui, QtWidgets


class Ui_Dialog(object):
    def setupUi(self, Dialog):
        Dialog.setObjectName("Dialog")
        Dialog.resize(971, 599)
        Dialog.setMinimumSize(QtCore.QSize(971, 599))
        self.gridLayout_7 = QtWidgets.QGridLayout(Dialog)
        self.gridLayout_7.setObjectName("gridLayout_7")
        self.gridLayout = QtWidgets.QGridLayout()
        self.gridLayout.setObjectName("gridLayout")
        self.gridLayout_5 = QtWidgets.QGridLayout()
        self.gridLayout_5.setObjectName("gridLayout_5")
        self.groupBox_2 = QtWidgets.QGroupBox(Dialog)
        self.groupBox_2.setObjectName("groupBox_2")
        self.groupBox_6 = QtWidgets.QGroupBox(self.groupBox_2)
        self.groupBox_6.setGeometry(QtCore.QRect(10, 10, 451, 121))
        self.groupBox_6.setTitle("")
        self.groupBox_6.setObjectName("groupBox_6")
        self.label_7 = QtWidgets.QLabel(self.groupBox_6)
        self.label_7.setGeometry(QtCore.QRect(10, 20, 431, 21))
        self.label_7.setObjectName("label_7")
        self.path_PrecipitationDataFile = QtWidgets.QLineEdit(self.groupBox_6)
        self.path_PrecipitationDataFile.setGeometry(QtCore.QRect(10, 50, 371, 20))
        self.path_PrecipitationDataFile.setReadOnly(False)
        self.path_PrecipitationDataFile.setClearButtonEnabled(False)
        self.path_PrecipitationDataFile.setObjectName("path_PrecipitationDataFile")
        self.spb_PrecipitationInterval_min = QtWidgets.QSpinBox(self.groupBox_6)
        self.spb_PrecipitationInterval_min.setGeometry(QtCore.QRect(160, 80, 91, 21))
        self.spb_PrecipitationInterval_min.setMaximum(1440)
        self.spb_PrecipitationInterval_min.setObjectName(
            "spb_PrecipitationInterval_min"
        )
        self.label = QtWidgets.QLabel(self.groupBox_6)
        self.label.setGeometry(QtCore.QRect(10, 80, 331, 21))
        self.label.setObjectName("label")
        self.load_btn_PrecipitationDataFile = QtWidgets.QPushButton(self.groupBox_6)
        self.load_btn_PrecipitationDataFile.setGeometry(QtCore.QRect(390, 50, 51, 23))
        self.load_btn_PrecipitationDataFile.setObjectName(
            "load_btn_PrecipitationDataFile"
        )
        self.gridLayout_5.addWidget(self.groupBox_2, 0, 0, 1, 1)
        self.groupBox_4 = QtWidgets.QGroupBox(Dialog)
        self.groupBox_4.setObjectName("groupBox_4")
        self.groupBox_9 = QtWidgets.QGroupBox(self.groupBox_4)
        self.groupBox_9.setGeometry(QtCore.QRect(10, 10, 451, 121))
        self.groupBox_9.setTitle("")
        self.groupBox_9.setObjectName("groupBox_9")
        self.label_10 = QtWidgets.QLabel(self.groupBox_9)
        self.label_10.setGeometry(QtCore.QRect(10, 20, 431, 21))
        self.label_10.setObjectName("label_10")
        self.path_SolarRadiationDataFile = QtWidgets.QLineEdit(self.groupBox_9)
        self.path_SolarRadiationDataFile.setGeometry(QtCore.QRect(10, 50, 371, 20))
        self.path_SolarRadiationDataFile.setReadOnly(False)
        self.path_SolarRadiationDataFile.setClearButtonEnabled(False)
        self.path_SolarRadiationDataFile.setObjectName("path_SolarRadiationDataFile")
        self.load_btn_SolarRadiationDataFile = QtWidgets.QPushButton(self.groupBox_9)
        self.load_btn_SolarRadiationDataFile.setGeometry(QtCore.QRect(390, 50, 51, 23))
        self.load_btn_SolarRadiationDataFile.setObjectName(
            "load_btn_SolarRadiationDataFile"
        )
        self.label_4 = QtWidgets.QLabel(self.groupBox_9)
        self.label_4.setGeometry(QtCore.QRect(10, 80, 331, 21))
        self.label_4.setObjectName("label_4")
        self.spb_SolarRadiationInterval_min = QtWidgets.QSpinBox(self.groupBox_9)
        self.spb_SolarRadiationInterval_min.setGeometry(QtCore.QRect(160, 80, 91, 21))
        self.spb_SolarRadiationInterval_min.setMaximum(1440)
        self.spb_SolarRadiationInterval_min.setObjectName(
            "spb_SolarRadiationInterval_min"
        )
        self.gridLayout_5.addWidget(self.groupBox_4, 2, 0, 1, 1)
        self.groupBox_3 = QtWidgets.QGroupBox(Dialog)
        self.groupBox_3.setObjectName("groupBox_3")
        self.groupBox_7 = QtWidgets.QGroupBox(self.groupBox_3)
        self.groupBox_7.setGeometry(QtCore.QRect(10, 20, 449, 122))
        self.groupBox_7.setTitle("")
        self.groupBox_7.setObjectName("groupBox_7")
        self.path_TemperatureMaxDataFile = QtWidgets.QLineEdit(self.groupBox_7)
        self.path_TemperatureMaxDataFile.setGeometry(QtCore.QRect(10, 50, 371, 20))
        self.path_TemperatureMaxDataFile.setReadOnly(False)
        self.path_TemperatureMaxDataFile.setClearButtonEnabled(False)
        self.path_TemperatureMaxDataFile.setObjectName("path_TemperatureMaxDataFile")
        self.spb_TemperatureMaxInterval_min = QtWidgets.QSpinBox(self.groupBox_7)
        self.spb_TemperatureMaxInterval_min.setGeometry(QtCore.QRect(160, 80, 91, 21))
        self.spb_TemperatureMaxInterval_min.setMaximum(1440)
        self.spb_TemperatureMaxInterval_min.setObjectName(
            "spb_TemperatureMaxInterval_min"
        )
        self.label_2 = QtWidgets.QLabel(self.groupBox_7)
        self.label_2.setGeometry(QtCore.QRect(10, 80, 331, 21))
        self.label_2.setObjectName("label_2")
        self.load_btn_TemperatureMaxDataFile = QtWidgets.QPushButton(self.groupBox_7)
        self.load_btn_TemperatureMaxDataFile.setGeometry(QtCore.QRect(390, 50, 51, 23))
        self.load_btn_TemperatureMaxDataFile.setObjectName(
            "load_btn_TemperatureMaxDataFile"
        )
        self.label_8 = QtWidgets.QLabel(self.groupBox_7)
        self.label_8.setGeometry(QtCore.QRect(10, 20, 431, 21))
        self.label_8.setObjectName("label_8")
        self.groupBox_8 = QtWidgets.QGroupBox(self.groupBox_3)
        self.groupBox_8.setGeometry(QtCore.QRect(10, 150, 449, 111))
        self.groupBox_8.setTitle("")
        self.groupBox_8.setObjectName("groupBox_8")
        self.load_btn_TemperatureMinDataFile = QtWidgets.QPushButton(self.groupBox_8)
        self.load_btn_TemperatureMinDataFile.setGeometry(QtCore.QRect(390, 50, 51, 23))
        self.load_btn_TemperatureMinDataFile.setObjectName(
            "load_btn_TemperatureMinDataFile"
        )
        self.path_TemperatureMinDataFile = QtWidgets.QLineEdit(self.groupBox_8)
        self.path_TemperatureMinDataFile.setGeometry(QtCore.QRect(10, 50, 371, 20))
        self.path_TemperatureMinDataFile.setReadOnly(False)
        self.path_TemperatureMinDataFile.setClearButtonEnabled(False)
        self.path_TemperatureMinDataFile.setObjectName("path_TemperatureMinDataFile")
        self.label_9 = QtWidgets.QLabel(self.groupBox_8)
        self.label_9.setGeometry(QtCore.QRect(10, 20, 431, 21))
        self.label_9.setObjectName("label_9")
        self.spb_TemperatureMinInterval_min = QtWidgets.QSpinBox(self.groupBox_8)
        self.spb_TemperatureMinInterval_min.setGeometry(QtCore.QRect(160, 80, 91, 21))
        self.spb_TemperatureMinInterval_min.setMaximum(1440)
        self.spb_TemperatureMinInterval_min.setObjectName(
            "spb_TemperatureMinInterval_min"
        )
        self.label_3 = QtWidgets.QLabel(self.groupBox_8)
        self.label_3.setGeometry(QtCore.QRect(10, 80, 331, 21))
        self.label_3.setObjectName("label_3")
        self.gridLayout_5.addWidget(self.groupBox_3, 1, 0, 1, 1)
        self.gridLayout_5.setRowStretch(0, 1)
        self.gridLayout_5.setRowStretch(1, 2)
        self.gridLayout_5.setRowStretch(2, 1)
        self.gridLayout.addLayout(self.gridLayout_5, 0, 0, 3, 1)
        self.gridLayout_6 = QtWidgets.QGridLayout()
        self.gridLayout_6.setObjectName("gridLayout_6")
        self.btnOK = QtWidgets.QPushButton(Dialog)
        self.btnOK.setText("OK")
        self.btnOK.setAutoDefault(True)
        self.btnOK.setObjectName("btnOK")
        self.gridLayout_6.addWidget(self.btnOK, 2, 0, 1, 1)
        self.groupBox_55 = QtWidgets.QGroupBox(Dialog)
        self.groupBox_55.setObjectName("groupBox_55")
        self.groupBox_12 = QtWidgets.QGroupBox(self.groupBox_55)
        self.groupBox_12.setGeometry(QtCore.QRect(10, 20, 451, 111))
        self.groupBox_12.setTitle("")
        self.groupBox_12.setObjectName("groupBox_12")
        self.label_13 = QtWidgets.QLabel(self.groupBox_12)
        self.label_13.setGeometry(QtCore.QRect(10, 20, 431, 21))
        self.label_13.setObjectName("label_13")
        self.path_SnowPackTemperatureDataFile = QtWidgets.QLineEdit(self.groupBox_12)
        self.path_SnowPackTemperatureDataFile.setGeometry(QtCore.QRect(10, 50, 371, 20))
        self.path_SnowPackTemperatureDataFile.setReadOnly(False)
        self.path_SnowPackTemperatureDataFile.setClearButtonEnabled(False)
        self.path_SnowPackTemperatureDataFile.setObjectName(
            "path_SnowPackTemperatureDataFile"
        )
        self.load_btn_SnowPackTemperatureDataFile = QtWidgets.QPushButton(
            self.groupBox_12
        )
        self.load_btn_SnowPackTemperatureDataFile.setGeometry(
            QtCore.QRect(390, 50, 51, 23)
        )
        self.load_btn_SnowPackTemperatureDataFile.setObjectName(
            "load_btn_SnowPackTemperatureDataFile"
        )
        self.spb_SnowPackTemperatureInterval_min = QtWidgets.QSpinBox(self.groupBox_12)
        self.spb_SnowPackTemperatureInterval_min.setGeometry(
            QtCore.QRect(160, 80, 91, 21)
        )
        self.spb_SnowPackTemperatureInterval_min.setMaximum(1440)
        self.spb_SnowPackTemperatureInterval_min.setObjectName(
            "spb_SnowPackTemperatureInterval_min"
        )
        self.label_6 = QtWidgets.QLabel(self.groupBox_12)
        self.label_6.setGeometry(QtCore.QRect(10, 80, 331, 21))
        self.label_6.setObjectName("label_6")
        self.gridLayout_6.addWidget(self.groupBox_55, 1, 0, 1, 2)
        self.groupBox_5 = QtWidgets.QGroupBox(Dialog)
        self.groupBox_5.setObjectName("groupBox_5")
        self.groupBox_10 = QtWidgets.QGroupBox(self.groupBox_5)
        self.groupBox_10.setGeometry(QtCore.QRect(10, 10, 451, 121))
        self.groupBox_10.setTitle("")
        self.groupBox_10.setObjectName("groupBox_10")
        self.label_12 = QtWidgets.QLabel(self.groupBox_10)
        self.label_12.setGeometry(QtCore.QRect(10, 20, 431, 21))
        self.label_12.setObjectName("label_12")
        self.path_DaytimeLengthDataFile = QtWidgets.QLineEdit(self.groupBox_10)
        self.path_DaytimeLengthDataFile.setGeometry(QtCore.QRect(10, 50, 371, 20))
        self.path_DaytimeLengthDataFile.setReadOnly(False)
        self.path_DaytimeLengthDataFile.setClearButtonEnabled(False)
        self.path_DaytimeLengthDataFile.setObjectName("path_DaytimeLengthDataFile")
        self.load_btn_DaytimeLengthDataFile = QtWidgets.QPushButton(self.groupBox_10)
        self.load_btn_DaytimeLengthDataFile.setGeometry(QtCore.QRect(390, 50, 51, 23))
        self.load_btn_DaytimeLengthDataFile.setObjectName(
            "load_btn_DaytimeLengthDataFile"
        )
        self.label_5 = QtWidgets.QLabel(self.groupBox_10)
        self.label_5.setGeometry(QtCore.QRect(10, 80, 331, 21))
        self.label_5.setObjectName("label_5")
        self.spb_DaytimeLengthInterval_min = QtWidgets.QSpinBox(self.groupBox_10)
        self.spb_DaytimeLengthInterval_min.setGeometry(QtCore.QRect(160, 80, 91, 21))
        self.spb_DaytimeLengthInterval_min.setMaximum(1440)
        self.spb_DaytimeLengthInterval_min.setObjectName(
            "spb_DaytimeLengthInterval_min"
        )
        self.groupBox_11 = QtWidgets.QGroupBox(self.groupBox_5)
        self.groupBox_11.setGeometry(QtCore.QRect(10, 140, 451, 91))
        self.groupBox_11.setTitle("")
        self.groupBox_11.setObjectName("groupBox_11")
        self.label_11 = QtWidgets.QLabel(self.groupBox_11)
        self.label_11.setGeometry(QtCore.QRect(10, 20, 431, 21))
        self.label_11.setObjectName("label_11")
        self.path_DaytimeHoursRatioDataFile = QtWidgets.QLineEdit(self.groupBox_11)
        self.path_DaytimeHoursRatioDataFile.setGeometry(QtCore.QRect(10, 50, 371, 20))
        self.path_DaytimeHoursRatioDataFile.setReadOnly(False)
        self.path_DaytimeHoursRatioDataFile.setClearButtonEnabled(False)
        self.path_DaytimeHoursRatioDataFile.setObjectName(
            "path_DaytimeHoursRatioDataFile"
        )
        self.load_btn_DaytimeHoursRatioDataFile = QtWidgets.QPushButton(
            self.groupBox_11
        )
        self.load_btn_DaytimeHoursRatioDataFile.setGeometry(
            QtCore.QRect(390, 50, 51, 23)
        )
        self.load_btn_DaytimeHoursRatioDataFile.setObjectName(
            "load_btn_DaytimeHoursRatioDataFile"
        )
        self.gridLayout_6.addWidget(self.groupBox_5, 0, 0, 1, 2)
        self.btnCancel = QtWidgets.QPushButton(Dialog)
        self.btnCancel.setText("Cancel")
        self.btnCancel.setAutoDefault(True)
        self.btnCancel.setObjectName("btnCancel")
        self.gridLayout_6.addWidget(self.btnCancel, 2, 1, 1, 1)
        self.gridLayout.addLayout(self.gridLayout_6, 0, 1, 3, 1)
        self.gridLayout_7.addLayout(self.gridLayout, 0, 0, 1, 1)

        self.retranslateUi(Dialog)
        QtCore.QMetaObject.connectSlotsByName(Dialog)
        Dialog.setTabOrder(
            self.path_PrecipitationDataFile, self.load_btn_PrecipitationDataFile
        )
        Dialog.setTabOrder(
            self.load_btn_PrecipitationDataFile, self.spb_PrecipitationInterval_min
        )
        Dialog.setTabOrder(
            self.spb_PrecipitationInterval_min, self.path_TemperatureMaxDataFile
        )
        Dialog.setTabOrder(
            self.path_TemperatureMaxDataFile, self.load_btn_TemperatureMaxDataFile
        )
        Dialog.setTabOrder(
            self.load_btn_TemperatureMaxDataFile, self.spb_TemperatureMaxInterval_min
        )
        Dialog.setTabOrder(
            self.spb_TemperatureMaxInterval_min, self.path_TemperatureMinDataFile
        )
        Dialog.setTabOrder(
            self.path_TemperatureMinDataFile, self.load_btn_TemperatureMinDataFile
        )
        Dialog.setTabOrder(
            self.load_btn_TemperatureMinDataFile, self.spb_TemperatureMinInterval_min
        )
        Dialog.setTabOrder(
            self.spb_TemperatureMinInterval_min, self.path_SolarRadiationDataFile
        )
        Dialog.setTabOrder(
            self.path_SolarRadiationDataFile, self.load_btn_SolarRadiationDataFile
        )
        Dialog.setTabOrder(
            self.load_btn_SolarRadiationDataFile, self.spb_SolarRadiationInterval_min
        )
        Dialog.setTabOrder(
            self.spb_SolarRadiationInterval_min, self.path_DaytimeLengthDataFile
        )
        Dialog.setTabOrder(
            self.path_DaytimeLengthDataFile, self.load_btn_DaytimeLengthDataFile
        )
        Dialog.setTabOrder(
            self.load_btn_DaytimeLengthDataFile, self.spb_DaytimeLengthInterval_min
        )
        Dialog.setTabOrder(
            self.spb_DaytimeLengthInterval_min, self.path_DaytimeHoursRatioDataFile
        )
        Dialog.setTabOrder(
            self.path_DaytimeHoursRatioDataFile, self.load_btn_DaytimeHoursRatioDataFile
        )
        Dialog.setTabOrder(
            self.load_btn_DaytimeHoursRatioDataFile,
            self.path_SnowPackTemperatureDataFile,
        )
        Dialog.setTabOrder(
            self.path_SnowPackTemperatureDataFile,
            self.load_btn_SnowPackTemperatureDataFile,
        )
        Dialog.setTabOrder(
            self.load_btn_SnowPackTemperatureDataFile,
            self.spb_SnowPackTemperatureInterval_min,
        )
        Dialog.setTabOrder(self.spb_SnowPackTemperatureInterval_min, self.btnOK)
        Dialog.setTabOrder(self.btnOK, self.btnCancel)

    def retranslateUi(self, Dialog):
        _translate = QtCore.QCoreApplication.translate
        Dialog.setWindowTitle(_translate("Dialog", "Setup Weather Data"))
        self.groupBox_2.setTitle(_translate("Dialog", "Precipitation"))
        self.label_7.setText(_translate("Dialog", "Precipitation data file"))
        self.label.setText(_translate("Dialog", "Data time interval [min] :"))
        self.load_btn_PrecipitationDataFile.setText(_translate("Dialog", "Load"))
        self.groupBox_4.setTitle(_translate("Dialog", "Solar radiation"))
        self.label_10.setText(_translate("Dialog", "Solar radiation data file"))
        self.load_btn_SolarRadiationDataFile.setText(_translate("Dialog", "Load"))
        self.label_4.setText(_translate("Dialog", "Data time interval [min] :"))
        self.groupBox_3.setTitle(_translate("Dialog", "Temperature"))
        self.label_2.setText(_translate("Dialog", "Data time interval [min] :"))
        self.load_btn_TemperatureMaxDataFile.setText(_translate("Dialog", "Load"))
        self.label_8.setText(_translate("Dialog", "Maximum temperature data file"))
        self.load_btn_TemperatureMinDataFile.setText(_translate("Dialog", "Load"))
        self.label_9.setText(_translate("Dialog", "Minimum temperature data file"))
        self.label_3.setText(_translate("Dialog", "Data time interval [min] :"))
        self.groupBox_55.setTitle(_translate("Dialog", "Snowpack temperature"))
        self.label_13.setText(_translate("Dialog", "Snowpack temperature data file"))
        self.load_btn_SnowPackTemperatureDataFile.setText(_translate("Dialog", "Load"))
        self.label_6.setText(_translate("Dialog", "Data time interval [min] :"))
        self.groupBox_5.setTitle(_translate("Dialog", "Daytime"))
        self.label_12.setText(_translate("Dialog", "Daytime length data file"))
        self.load_btn_DaytimeLengthDataFile.setText(_translate("Dialog", "Load"))
        self.label_5.setText(_translate("Dialog", "Data time interval [min] :"))
        self.label_11.setText(_translate("Dialog", "Daytime hours ratio data file"))
        self.load_btn_DaytimeHoursRatioDataFile.setText(_translate("Dialog", "Load"))
