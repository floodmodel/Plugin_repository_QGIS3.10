﻿# -*- coding: utf-8 -*-
from grm.lib.Util import MsError


class set_Controls:
    # 라벨, 타입으로 구분
    def GlobalLabel(self, label):
        self.label1 = label

    # 라벨 텍스트,타입으로 구분
    def GlobalLabel_SetText(self, mess):
        self.label1.setText(mess)

    def set_wsinfo(self, _wsinfo):
        self._wsinfo = _wsinfo

    def get_wsinfo(self):
        return self._wsinfo

    def GlobalControl(
        self, CellCounts, Celltype, StreamValue, FD, FA, Slope, watershed
    ):
        self.txtCellCount = CellCounts
        self.txtCelltype = Celltype
        self.txtStreamValue = StreamValue
        self.txtFD = FD
        self.txtFA = FA
        self.txtSlope = Slope
        self.txtWatershedID = watershed

    def GlobalControl_SetValue(
        self, CellCounts, Celltype, StreamValue, FD, FA, Slope, watershed
    ):
        self.txtCellCount.setText(CellCounts)
        self.txtCelltype.setText(Celltype)
        self.txtCelltype.setCursorPosition(0)
        self.txtStreamValue.setText(StreamValue)
        self.txtFD.setText(FD)
        self.txtFA.setText(FA)
        self.txtSlope.setText(Slope)
        self.txtSlope.setCursorPosition(0)
        self.txtWatershedID.setText(watershed)

    def GlobalControl_Landcover(
        self,
        txtLandGridValue,
        txtLandType,
        txtRoughness,
        txtratio,
        txtCanopyRatio,
        txtInterceptionMaxWaterCanopy,
    ):
        self.txtLandGridValue = txtLandGridValue
        self.txtLandType = txtLandType
        self.txtRoughness = txtRoughness
        self.txtratio = txtratio
        self.txtCanopyRatio = txtCanopyRatio
        self.txtInterceptionMaxWaterCanopy = txtInterceptionMaxWaterCanopy

    def GlobalControl_Landcover_SetValue(
        self,
        txtLandGridValue,
        txtLandType,
        txtRoughness,
        txtratio,
        txtCanopyRatio,
        txtInterceptionMaxWaterCanopy,
    ):
        self.txtLandGridValue.setText(txtLandGridValue)
        self.txtLandType.setText(txtLandType)
        self.txtRoughness.setText(txtRoughness)
        self.txtratio.setText(txtratio)
        self.txtCanopyRatio.setText(txtCanopyRatio)
        self.txtInterceptionMaxWaterCanopy.setText(txtInterceptionMaxWaterCanopy)

    def GlobalControl_Depth(self, GridValue, UserDepthClass, SoilDepth):
        try:
            self.DepthGridValue = GridValue
            self.UserDepthClass = UserDepthClass
            self.SoilDepth = SoilDepth
        except Exception as e:
            MsError(e)

    def GlobalControl_Depth_SetValue(self, GridValue, UserDepthClass, SoilDepth):
        try:
            self.DepthGridValue.setText(str(GridValue))
            self.UserDepthClass.setText(UserDepthClass)
            self.SoilDepth.setText(str(SoilDepth))
        except Exception as e:
            MsError(e)

    def GlobalControl_texture(
        self,
        GridValue,
        GRMCode,
        Porosity,
        EffectivePorosity,
        WFSoilSuctionHead,
        HydraulicConductivity,
    ):
        self.GridValue = GridValue
        self.GRMCode = GRMCode
        self.Porosity = Porosity
        self.EffectivePorosity = EffectivePorosity
        self.WFSoilSuctionHead = WFSoilSuctionHead
        self.HydraulicConductivity = HydraulicConductivity

    def GlobalControl_texture_SetValue(
        self,
        GridValue,
        GRMCode,
        Porosity,
        EffectivePorosity,
        WFSoilSuctionHead,
        HydraulicConductivity,
    ):
        self.GridValue.setText(GridValue)
        self.GRMCode.setText(GRMCode)
        self.Porosity.setText(Porosity)
        self.EffectivePorosity.setText(EffectivePorosity)
        self.WFSoilSuctionHead.setText(WFSoilSuctionHead)
        self.HydraulicConductivity.setText(HydraulicConductivity)

    def set_GreenAmptCount(self, _GreenAmptCount):
        self._GreenAmptCount = _GreenAmptCount

    def get_GreenAmptCount(self):
        return self._GreenAmptCount

    def set_xmltodict(self, _xmltodict):
        self._xmltodict = _xmltodict

    def get_xmltodict(self):
        return self._xmltodict

    def set_SoilDepthCount(self, _SoilDepthCount):
        self._SoilDepthCount = _SoilDepthCount

    def get_SoilDepthCount(self):
        return self._SoilDepthCount

    def set_LandCoverCount(self, _LandCoverCount):
        self._LandCoverCount = _LandCoverCount

    def get_LandCoverCount(self):
        return self._LandCoverCount
