# -*- coding: utf-8 -*-
import os
from qgis.core import QgsProject
from qgis.PyQt import uic
from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtWidgets import QDialog, QMessageBox

from grm.lib.File_Class import GetFile_Name
from grm.lib.Util import (
    GetcomboSelectedLayerPath,
    GetTxtToLayerPath,
    MsInfo,
    SetCommbox,
)

FORM_CLASS, _ = uic.loadUiType(os.path.join(os.path.dirname(__file__), "Watershed_dialog_base.ui"))


class WatershedDialog(QDialog, FORM_CLASS):
    def __init__(self, _xmltodict={}, _grmDialogFlag=0, parent=None):
        super(WatershedDialog, self).__init__(parent)
        self.setupUi(self)

        self._xmltodict = _xmltodict
        self._grmDialogFlag = _grmDialogFlag  # Setup / Run GRM 창 실행 중인지 확인

        # 콤보 박스 레이어 목록 셋팅
        self.SetComboxLayerList()

        # 2017-06-22 프로젝트 파일에 콤보박스 레이어 목록과 QGIS 레이어 목록 비교하여
        # 둘이 동일한 파일이 있을시에 콤보 박스에 셋팅 기능
        self.SetProjectToCombobox()

        #self.chkDEMLayer.setChecked(False)  # 기본 설정
        self.chkDEMLayer.stateChanged.connect(self.chkDEMLayer_CheckedChanged)

        self.chkStreamLayer.setChecked(True)  # 기본 설정
        self.cmbStreamLayer.setEnabled(True)  # 기본 설정
        self.chkStreamLayer.stateChanged.connect(self.chkStreamLayer_CheckedChanged)

        # 체크 박스 클릭 이벤트 연동
        self.chkiniSoilRatioLayer.stateChanged.connect(
            self.chkiniSoilRatioLayer_CheckedChanged
        )
        self.chkChannelWidthLayer.stateChanged.connect(
            self.chkChannelWidthLayer_CheckedChanged
        )
        self.chkIniFlowLayer.stateChanged.connect(self.chkIniFlow_CheckedChanged)

        # OK 버튼 처리 이벤트
        self.btnOK.clicked.connect(self.ClickOK)

        # 폼 종료 버튼 이벤트 처리
        self.btnCancel.clicked.connect(self.Close_Form)

    def SetComboxLayerList(self):
        # QGIS 레이어 레전드 목록 받아오기
        layers = QgsProject.instance().mapLayers().values()
        cmbList = [
            self.cmbDEMLayer,
            self.cmbWatershedAreaLayer,
            self.cmbWatershedSlopeLayer,
            self.cmbFdirLayer,
            self.cmbFacLayer,
            self.cmbStreamLayer,
            self.cmbChannelWidthLayer,
            self.cmbiniSoilRatioLayer,
            self.cmbiniFlowLayer,
        ]

        if self._grmDialogFlag == 1:
            lly = list(layers)
            remove_set = QgsProject.instance().mapLayersByName("WSFAlayerload")
            layers = [i for i in lly if i not in remove_set]

        for cmb in cmbList:
            SetCommbox(layers, cmb, "tif")

    def chkDEMLayer_CheckedChanged(self):
            self.cmbDEMLayer.setEnabled(self.chkDEMLayer.isChecked())

    def chkStreamLayer_CheckedChanged(self):
        self.cmbStreamLayer.setEnabled(self.chkStreamLayer.isChecked())
        if self.chkStreamLayer.isChecked() == True:
            self.chkChannelWidthLayer.setEnabled(True)
            self.chkIniFlowLayer.setEnabled(True)
        if self.chkStreamLayer.isChecked() == False:
            self.chkChannelWidthLayer.setChecked(False)
            self.chkChannelWidthLayer.setEnabled(False)
            self.cmbChannelWidthLayer.setEnabled(False)
            self.chkIniFlowLayer.setChecked(False)
            self.chkIniFlowLayer.setEnabled(False)
            self.cmbiniFlowLayer.setEnabled(False)

    def chkChannelWidthLayer_CheckedChanged(self):
        self.cmbChannelWidthLayer.setEnabled(self.chkChannelWidthLayer.isChecked())

    def chkIniFlow_CheckedChanged(self):
        self.cmbiniFlowLayer.setEnabled(self.chkIniFlowLayer.isChecked())

    def chkiniSoilRatioLayer_CheckedChanged(self):
         self.cmbiniSoilRatioLayer.setEnabled(self.chkiniSoilRatioLayer.isChecked())

    def SetProjectToCombobox(self):
        # 각각의 변수에 XML 값 할당
        self.mGridDEMFPN = self._xmltodict["GRMProject"]["ProjectSettings"]["DEMFile"]
        if self.mGridDEMFPN != "" and self.mGridDEMFPN is not None:
            self.cmbDEMLayer.setEnabled(True)
            self.chkDEMLayer.setChecked(True)
            mGridNameDEM = GetFile_Name(self.mGridDEMFPN)
            self.Setcombobox(self.cmbDEMLayer, mGridNameDEM, self.mGridDEMFPN)
        else:
            self.chkDEMLayer.setChecked(False)
            self.cmbDEMLayer.setEnabled(False)

        self.mGridWSFPN = self._xmltodict["GRMProject"]["ProjectSettings"]["DomainFile"]
        if self.mGridWSFPN != "" and self.mGridWSFPN is not None:
            mGridNameWS = GetFile_Name(self.mGridWSFPN)
            self.Setcombobox(self.cmbWatershedAreaLayer, mGridNameWS, self.mGridWSFPN)

        # Slop
        self.mGridSlopeFPN = self._xmltodict["GRMProject"]["ProjectSettings"][
            "SlopeFile"
        ]
        if self.mGridSlopeFPN != "" and self.mGridSlopeFPN is not None:
            mGridNameSlope = GetFile_Name(self.mGridSlopeFPN)
            self.Setcombobox(self.cmbWatershedSlopeLayer, mGridNameSlope, self.mGridSlopeFPN)

        # Flowdirection
        self.mGridFdirFPN = self._xmltodict["GRMProject"]["ProjectSettings"][
            "FlowDirectionFile"
        ]
        if self.mGridFdirFPN != "" and self.mGridFdirFPN is not None:
            mGridNameFdir = GetFile_Name(self.mGridFdirFPN)
            self.Setcombobox(self.cmbFdirLayer, mGridNameFdir, self.mGridFdirFPN)

        # FlowAC
        self.mGridFacFPN = self._xmltodict["GRMProject"]["ProjectSettings"][
            "FlowAccumFile"
        ]
        if self.mGridFacFPN != "" and self.mGridFacFPN is not None:
            mGridNameFac = GetFile_Name(self.mGridFacFPN)
            self.Setcombobox(self.cmbFacLayer, mGridNameFac, self.mGridFacFPN)

        # Stream
        self.mGridStreamFPN = self._xmltodict["GRMProject"]["ProjectSettings"][
            "StreamFile"
        ]
        if self.mGridStreamFPN != "" and self.mGridStreamFPN is not None:
            self.chkStreamLayer.setChecked(True)
            self.cmbStreamLayer.setEnabled(True)
            mGridNameStream = GetFile_Name(self.mGridStreamFPN)
            self.Setcombobox(self.cmbStreamLayer, mGridNameStream, self.mGridStreamFPN)
        else:
            self.chkStreamLayer.setChecked(False)
            self.cmbStreamLayer.setEnabled(False)

        # Channel
        # 파싱 방법을 바꿔야 하는데 임시로 처리 흠 흠.....
        # 프로젝트 파일에서 null 처리
        self.mGridChannelWidthFPN = self._xmltodict["GRMProject"]["ProjectSettings"][
            "ChannelWidthFile"
        ]

        if self.mGridChannelWidthFPN is None or self.mGridChannelWidthFPN == "":
            self.chkChannelWidthLayer.setChecked(False)
            self.cmbChannelWidthLayer.setEnabled(False)
        else:
            self.chkChannelWidthLayer.setChecked(True)
            self.cmbChannelWidthLayer.setEnabled(True)
            mGridNameChannelWidth = GetFile_Name(self.mGridChannelWidthFPN)
            self.Setcombobox(
                self.cmbChannelWidthLayer,
                mGridNameChannelWidth,
                self.mGridChannelWidthFPN,
            )

        self.miniSoilRatio = self._xmltodict["GRMProject"]["ProjectSettings"][
            "InitialSoilSaturationRatioFile"
        ]
        if self.miniSoilRatio is not None and self.miniSoilRatio != "":
            self.chkiniSoilRatioLayer.setChecked(True)
            self.cmbiniSoilRatioLayer.setEnabled(True)
            name = GetFile_Name(self.miniSoilRatio)
            self.Setcombobox(self.cmbiniSoilRatioLayer, name, self.miniSoilRatio)
        else:
            self.chkiniSoilRatioLayer.setChecked(False)
            self.cmbiniSoilRatioLayer.setEnabled(False)

        self.InitialChannelFlowFile = self._xmltodict["GRMProject"]["ProjectSettings"][
            "InitialChannelFlowFile"
        ]
        if (
            self.InitialChannelFlowFile is not None
            and self.InitialChannelFlowFile != ""
        ):
            self.chkIniFlowLayer.setChecked(True)
            self.cmbiniFlowLayer.setEnabled(True)
            name = GetFile_Name(self.InitialChannelFlowFile)
            self.Setcombobox(self.cmbiniFlowLayer, name, self.InitialChannelFlowFile)
        else:
            self.chkIniFlowLayer.setChecked(False)
            self.cmbiniFlowLayer.setEnabled(False)

        # FD
        self.mFDType = self._xmltodict["GRMProject"]["ProjectSettings"][
            "FlowDirectionType"
        ]

        if self.mFDType == "StartsFromN":
            self.rbFDIndexTypeN.setChecked(True)
        elif self.mFDType == "StartsFromNE":
            self.rbFDIndexTypeNE.setChecked(True)
        elif self.mFDType == "StartsFromE":
            self.rdioEAST.setChecked(True)
        else:
            self.rdioTaudem.setChecked(True)

    # 콤보 박스에 있는 목록중에 프로젝트 상에 있는 레이어 비교 하여 셋팅
    def Setcombobox(self, commbox, layername, filepath):
        index = commbox.findText(str(layername), Qt.MatchFixedString)
        if GetTxtToLayerPath(layername) == filepath:
            if index >= 0:
                commbox.setCurrentIndex(index)

    # OK 버튼 이벤트
    def ClickOK(self):
        # 콤보 박스와 체크 박스등 기본적인 선택 내용 확인 하여 오류 메시지 출력
        try:
            flag = self.ValidateInputs()
            if flag:
                raise Exception
            # 선택된 값들 글로벌 변수에 값을 넣음 나중에 값을 XML에 넣을 것임
            if self.chkDEMLayer.isChecked():
                if self.cmbDEMLayer.currentIndex() != 0:
                    self.mGridDEMFPN = GetcomboSelectedLayerPath(
                        self.cmbDEMLayer
                    )
                else:
                    self.mGridDEMFPN = ""
            
            self.mGridWSFPN = GetcomboSelectedLayerPath(self.cmbWatershedAreaLayer)
            self.mGridSlopeFPN = GetcomboSelectedLayerPath(self.cmbWatershedSlopeLayer)
            self.mGridFdirFPN = GetcomboSelectedLayerPath(self.cmbFdirLayer)
            self.mGridFacFPN = GetcomboSelectedLayerPath(self.cmbFacLayer)

            if self.rbFDIndexTypeN.isChecked() == True:
                self.mFDType = "StartsFromN"
            elif self.rbFDIndexTypeNE.isChecked() == True:
                self.mFDType = "StartsFromNE"
            elif self.rdioEAST.isChecked() == True:
                self.mFDType = "StartsFromE"
            else:
                self.mFDType = "StartsFromE_TauDEM"

            if self.chkiniSoilRatioLayer.isChecked():
                if self.cmbiniSoilRatioLayer.currentIndex() != 0:
                    self.miniSoilRatio = GetcomboSelectedLayerPath(
                        self.cmbiniSoilRatioLayer
                    )
                else:
                    self.miniSoilRatio = ""

            if self.chkStreamLayer.isChecked():
                self.mGridStreamFPN = GetcomboSelectedLayerPath(self.cmbStreamLayer)
                if self.chkChannelWidthLayer.isChecked():
                    if self.cmbChannelWidthLayer.currentIndex() != 0:
                        self.mGridChannelWidthFPN = GetcomboSelectedLayerPath(
                            self.cmbChannelWidthLayer
                        )
                    else:
                        self.mGridChannelWidthFPN = ""

            if self.chkIniFlowLayer.isChecked():
                if self.cmbiniFlowLayer.currentIndex() != 0:
                    self.InitialChannelFlowFile = GetcomboSelectedLayerPath(
                        self.cmbiniFlowLayer
                    )
                else:
                    self.InitialChannelFlowFile = ""

            self.SetXML()
        except Exception:
            pass
        else:
            quit_msg = " Watershed setup was completed.   "
            reply = QMessageBox.information(self, "Watershed", quit_msg, QMessageBox.Ok)
            if reply == QMessageBox.Ok:
                self.close()

    def ValidateInputs(self):
        # 각각 콥보 박스중 선택된것이 없을때 메시지 출력및 포커스 이동
        try:
            if self.cmbWatershedAreaLayer.currentIndex() == 0:
                self.cmbWatershedAreaLayer.setFocus()
                raise Exception("\n No layer selected. \n")
            elif self.cmbWatershedSlopeLayer.currentIndex() == 0:
                self.cmbWatershedSlopeLayer.setFocus()
                raise Exception("\n No layer selected. \n")
            elif self.cmbFdirLayer.currentIndex() == 0:
                self.cmbFdirLayer.setFocus()
                raise Exception("\n No layer selected. \n")
            elif self.cmbFacLayer.currentIndex() == 0:
                self.cmbFacLayer.setFocus()
                raise Exception("\n No layer selected. \n")
            elif self.cmbStreamLayer.currentIndex() == 0:
                self.cmbStreamLayer.setFocus()
                raise Exception("\n No layer selected. \n")

        except Exception as exce:
            MsInfo(exce.args[0])
            return True

    def SetXML(self):
        # DEMFile
        self._xmltodict["GRMProject"]["ProjectSettings"]["DEMFile"] = self.mGridDEMFPN
        # WatershedFile
        self._xmltodict["GRMProject"]["ProjectSettings"]["DomainFile"] = self.mGridWSFPN
        # Slop
        self._xmltodict["GRMProject"]["ProjectSettings"][
            "SlopeFile"
        ] = self.mGridSlopeFPN
        # Flowdirection
        self._xmltodict["GRMProject"]["ProjectSettings"][
            "FlowDirectionFile"
        ] = self.mGridFdirFPN
        # FlowAccu
        self._xmltodict["GRMProject"]["ProjectSettings"][
            "FlowAccumFile"
        ] = self.mGridFacFPN
        # FDType
        self._xmltodict["GRMProject"]["ProjectSettings"][
            "FlowDirectionType"
        ] = self.mFDType
        # Stream

        if self.chkIniFlowLayer.isChecked():
            self._xmltodict["GRMProject"]["ProjectSettings"][
                "InitialChannelFlowFile"
            ] = self.InitialChannelFlowFile
        else:
            self._xmltodict["GRMProject"]["ProjectSettings"][
                "InitialChannelFlowFile"
            ] = ""

        if self.chkStreamLayer.isChecked():
            self._xmltodict["GRMProject"]["ProjectSettings"][
                "StreamFile"
            ] = self.mGridStreamFPN
        else:
            self._xmltodict["GRMProject"]["ProjectSettings"]["StreamFile"] = ""

        # ChannelWidthFile
        if self.chkChannelWidthLayer.isChecked() and self.chkStreamLayer.isChecked():
            self._xmltodict["GRMProject"]["ProjectSettings"][
                "ChannelWidthFile"
            ] = self.mGridChannelWidthFPN
        else:
            self._xmltodict["GRMProject"]["ProjectSettings"]["ChannelWidthFile"] = ""

        if self.chkiniSoilRatioLayer.isChecked():
            self._xmltodict["GRMProject"]["ProjectSettings"][
                "InitialSoilSaturationRatioFile"
            ] = self.miniSoilRatio
        else:
            self._xmltodict["GRMProject"]["ProjectSettings"][
                "InitialSoilSaturationRatioFile"
            ] = ""

    # 프로그램 종료
    def Close_Form(self):
        self.close()
