import os
from typing import Callable, Dict, List
from qgis.PyQt.QtWidgets import QDialog, QFileDialog, QLineEdit, QPushButton

from grm.lib.Util import MsError, MsInfo
from grm.ui.Weather_data_dialog_base import Ui_Dialog


class WeatherDataDialog(QDialog):
    def __init__(self, _xmltodic={}, parent=None):
        super(WeatherDataDialog, self).__init__(parent)
        self.ui = Ui_Dialog()
        self.ui.setupUi(self)
        
        # 얕은 복사. 해당 값은 주의깊게 사용해야 한다.
        self.__xmltodict = _xmltodic
        self.current_value_dict = {}
        self.ui.rbPET.setChecked(True)
        self.setControlsFunction()

        self.set_xmlValue_to_CurrentValue()
        self.initControlsValue()
        self.set_spb_event()

        self.required_att_list = [
            "PrecipitationDataFile",
            "PrecipitationInterval_min",
        ]

    def error_handler_decorator(func: Callable) -> Callable:
        def wrapper(self, *args, **kwargs):
            try:
                func(self, *args, **kwargs)
            except Exception as e:
                return MsError(e, self)
        return wrapper

    def setControlsFunction(self):
        self.ui.load_btn_PrecipitationDataFile.clicked.connect(
             lambda: self.SelectWeatherDataFile("PrecipitationDataFile", self.ui.tb_fpn_PrecipitationDataFile)
        )
        self.ui.load_btn_TemperatureMaxDataFile.clicked.connect(
             lambda: self.SelectWeatherDataFile("TemperatureMaxDataFile",self.ui.tb_fpn_TemperatureMaxDataFile)
        )
        self.ui.load_btn_TemperatureMinDataFile.clicked.connect(
             lambda: self.SelectWeatherDataFile("TemperatureMinDataFile",self.ui.tb_fpn_TemperatureMinDataFile)
        )
        self.ui.load_btn_DewPointTemperatureDataFile.clicked.connect(
             lambda: self.SelectWeatherDataFile("DewPointTemperatureDataFile",self.ui.tb_fpn_DewPointTemperatureDataFile)
        )
        self.ui.load_btn_SolarRadiationDataFile.clicked.connect(
             lambda: self.SelectWeatherDataFile("SolarRadiationDataFile",self.ui.tb_fpn_SolarRadiationDataFile)
        )
        self.ui.load_btn_WindSpeedDataFile.clicked.connect(
             lambda: self.SelectWeatherDataFile("WindSpeedDataFile",self.ui.tb_fpn_WindSpeedDataFile)
        )
        self.ui.load_btn_DaytimeLengthDataFile.clicked.connect(
             lambda: self.SelectWeatherDataFile("DaytimeLengthDataFile",self.ui.tb_fpn_DaytimeLengthDataFile)
        )
        self.ui.load_btn_UserETDataFile.clicked.connect(
             lambda: self.SelectWeatherDataFile("UserETDataFile",self.ui.tb_fpn_UserETDataFile)
        )
        self.ui.load_btn_SnowPackTemperatureDataFile.clicked.connect(
             lambda: self.SelectWeatherDataFile("SnowPackTemperatureDataFile",self.ui.tb_fpn_SnowPackTemperatureDataFile)
        )

        self.ui.rbPET.clicked.connect(self.rbPET_AET_Clicked)
        self.ui.rbAET.clicked.connect(self.rbPET_AET_Clicked)
        self.ui.btnOK.clicked.connect(self.__btn_ok_clicked)
        self.ui.btnCancel.clicked.connect(self.close)

    @error_handler_decorator
    def SelectWeatherDataFile(self, attName, txtbox):
        dir = os.path.dirname(txtbox.text())
        filePathName = QFileDialog.getOpenFileName(
            self, "Select weather data file ", dir, "*.*")[0]
        if filePathName:
            txtbox.setText(filePathName)
            if attName =="UserETDataFile":
                if self.ui.rbPET.isChecked():
                    self.current_value_dict["UserPETDataFile"] = filePathName
                else:
                    self.current_value_dict["UserAETDataFile"] = filePathName
            else:
                self.current_value_dict[attName] = filePathName

    def rbPET_AET_Clicked(self):
        if self.ui.rbPET.isChecked():
            self.current_value_dict["UserPETDataFile"] = self.ui.tb_fpn_UserETDataFile.text()
            self.current_value_dict["UserAETDataFile"] = None
        else:
            self.current_value_dict["UserPETDataFile"] = None
            self.current_value_dict["UserAETDataFile"] = self.ui.tb_fpn_UserETDataFile.text()

    def set_xmlValue_to_CurrentValue(self):
        """
        xml에 있는 값들을 클래스 내의 current_value_dict에 저장한다.
        """
        attr_list = [
            "PrecipitationDataFile",
            "PrecipitationInterval_min",
            "TemperatureMaxDataFile",
            "TemperatureMaxInterval_min",
            "TemperatureMinDataFile",
            "TemperatureMinInterval_min",
            "DaytimeLengthDataFile",
            "DaytimeLengthInterval_min",
            "SolarRadiationDataFile",
            "SolarRadiationInterval_min",
            "DewPointTemperatureDataFile",
            "DewPointTemperatureInterval_min",
            "WindSpeedDataFile",
            "WindSpeedInterval_min",
            "UserPETDataFile",
            "UserAETDataFile",
            "UserETDataInterval_min",
            "SnowPackTemperatureDataFile",
            "SnowPackTemperatureInterval_min",
        ]

        for attr in attr_list:
            if self.__xmltodict["GRMProject"]["ProjectSettings"].get(attr):
                self.current_value_dict[attr] = self.__xmltodict["GRMProject"][
                    "ProjectSettings"][attr]
            else:
                self.current_value_dict[attr] = None


    def initControlsValue(self):
        for attr in self.current_value_dict.keys():
            attr_value = self.current_value_dict.get(attr)
            if attr_value:
                if attr.endswith("_min"):
                    getattr(self.ui, f"spb_{attr}").setValue(int(attr_value))
                elif attr=="PrecipitationDataFile":
                    self.ui.tb_fpn_PrecipitationDataFile.setText(attr_value)
                elif attr=="TemperatureMaxDataFile":
                    self.ui.tb_fpn_TemperatureMaxDataFile.setText(attr_value)
                elif attr=="TemperatureMinDataFile":
                    self.ui.tb_fpn_TemperatureMinDataFile.setText(attr_value)
                elif attr=="DaytimeLengthDataFile":
                    self.ui.tb_fpn_DaytimeLengthDataFile.setText(attr_value)
                elif attr=="SolarRadiationDataFile":
                    self.ui.tb_fpn_SolarRadiationDataFile.setText(attr_value)
                elif attr=="DewPointTemperatureDataFile":
                    self.ui.tb_fpn_DewPointTemperatureDataFile.setText(attr_value)
                elif attr=="WindSpeedDataFile":
                    self.ui.tb_fpn_WindSpeedDataFile.setText(attr_value)
                elif attr=="UserPETDataFile" or attr=="UserAETDataFile":
                    self.ui.tb_fpn_UserETDataFile.setText(attr_value)
                    if attr=="UserAETDataFile" and (attr_value != None or attr_value !=""):
                        self.ui.rbAET.setChecked(True)
                        self.current_value_dict["UserPETDataFile"]=None
                elif attr=="SnowPackTemperatureDataFile":
                    self.ui.tb_fpn_SnowPackTemperatureDataFile.setText(attr_value)

    def set_spb_event(self) -> None:
        spb_list: List[str] = [
            string.split("spb_")[1]
            for string in dir(self.ui)
            if string.startswith("spb_")
        ]
        for spb in spb_list:
            getattr(self.ui, f"spb_{spb}").valueChanged.connect(
                self.spb_value_changed(spb)
            )

    def spb_value_changed(self, attr: str) -> Callable:
        def value_changed():
            self.current_value_dict[attr] = getattr(self.ui, f"spb_{attr}").value()

        return value_changed

    @error_handler_decorator
    def __btn_ok_clicked(self, _: bool) -> None:
        for attName in self.required_att_list:
            if not self.current_value_dict.get(attName):
                raise Exception(f" '{attr}' 값이 입력되지 않았습니다. ")
        for attName in self.current_value_dict.keys():
            if (
                self.current_value_dict.get(attName)
                and attName in self.__xmltodict["GRMProject"]["ProjectSettings"].keys()
            ):
                self.__xmltodict["GRMProject"]["ProjectSettings"][
                    attName
                    ] = self.current_value_dict.get(attName)
            else:
                self.__xmltodict["GRMProject"]["ProjectSettings"][
                    attName] = None

        MsInfo("Weather data setup was completed. ")
        self.close()


if __name__ == "__main__":
    import os

    from grm.lib.Util import MsTitle

    os.environ[
        "QT_QPA_PLATFORM_PLUGIN_PATH"
    ] = r"C:\Program Files\QGIS 3.10\apps\Qt5\plugins"
    import sys

    from qgis.PyQt.QtWidgets import QApplication

    MsTitle("WeatherDataDialog")
    app = QApplication(sys.argv)
    ui = WeatherDataDialog(
        {
            "GRMProject": {
                "ProjectSettings": {
                    "PrecipitationDataFile": "",
                    "PrecipitationInterval_min": "",
                    "TemperatureMaxDataFile": "",
                    "TemperatureMaxInterval_min": "",
                    "TemperatureMinDataFile": "",
                    "TemperatureMinInterval_min": "",
                    "DaytimeLengthDataFile": "",
                    "DaytimeLengthInterval_min": "",
                    "SolarRadiationDataFile": "",
                    "SolarRadiationInterval_min": "",
                    "DewPointTemperatureDataFile": "",
                    "DewPointTemperatureInterval_min": "",
                    "WindSpeedDataFile": "",
                    "WindSpeedInterval_min": "",
                    "UserPETDataFile": "",
                    #"UserPETDataInterval_min": "",
                    "UserAETDataFile": "",
                    "UserETDataInterval_min": "",
                    "SnowPackTemperatureDataFile": "",
                    "SnowPackTemperatureInterval_min": "",
                }
            }
        }
    )
    ui.show()
    sys.exit(app.exec_())
