from enum import Enum

# grm.h의 내용과 내용, 번호 맞춘다.
EnumUnSaturatedKType = Enum("EnumUnSaturatedKType", {	"Constant": 1,
	"Linear": 2, "Exponential": 3, "None": 0} )
EnumInterceptionMethod = Enum("EnumInterceptionMethod", {"LAIRatio": 1, "None": 0})
EnumPETMethod = Enum(
    "EnumPETMethod",
    #{"FPM": 1, "BlaneyCriddle": 2, "Hamon": 3, "PriestleyTaylor": 4, "Hargreaves": 5, "UserET": 9,  "None": 0},
    {"BC": 1, "FPM": 2, "HMN": 3, "HRGV": 4, "PT": 5, "UserET": 9,  "None": 0},
)
EnumSnowMeltMethod = Enum("EnumSnowMeltMethod", {"Anderson": 1, "None": 0})
EnumDataName = Enum("EnumDataName", {"LandCover": 1, "GreenAmpt": 2, "SoilDepth": 3, "None": 0})


