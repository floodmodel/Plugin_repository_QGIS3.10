﻿# -*- coding: utf-8 -*-
import os
import tempfile
import xml.etree.ElementTree as ET

from qgis.core import QgsProject
from qgis.PyQt.QtCore import QRect, Qt
from qgis.PyQt.QtGui import QPixmap
from qgis.PyQt.QtWidgets import (
    QAbstractItemView,
    QDialog,
    QFileDialog,
    QLineEdit,
    QMessageBox,
    QWidget,
    QTableWidget,
    QTableWidgetItem,
)

from grm.lib.File_Class import ChFile_Exists, GetFile_Name
from grm.lib.Util import (
    GetcomboSelectedLayerPath,
    MsError,
    MsInfo,
    SetCommbox,
    SetCommbox2,
    error_decorator,
)
from grm.lib.xmltodict import parse, unparse
from grm.ui.LandCoverSoil_dialog_base import Ui_Dialog
from grm.utils.enum_types import EnumDataName
from grm.ui.emptyTable_Ok_Cancel import Ui_emptyTable_OK_Cancel

class attWindow(QDialog):
    def __init__(self, parent=None):
        super(attWindow, self).__init__(parent)
        self.ui = Ui_emptyTable_OK_Cancel()
        self.ui.setupUi(self)

        # 서브 UI 크기 및 위치 설정
        self.ui.windowTile = "Select an attribute"
        self.parentUI = None
        self.tableWidget = self.ui.tableWidget
        self.tableWidget.setObjectName("tableWidget")
        self.tableWidget.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.tableWidget.setEditTriggers(QAbstractItemView.NoEditTriggers)

        self.btnOK = self.ui.btnOK
        self.btnCancel = self.ui.btnCancel

        self.btnCancel.clicked.connect(self.close_window)

        self.setMinimumSize(900, 400)  # 최소 크기
        self.setMaximumSize(2000, 800)  # 최대 크기

    def close_window(self):
        """서브 창 닫기"""
        self.close()


class LandCoverSoilDialog(QDialog, Ui_Dialog):
    def __init__(
        self,
        _xmltodic={},
        _LandCoverCount=0,
        _GreenAmptCount=0,
        _SoilDepthCount=0,
        _grmDialogFlag=0,
        parent=None,
    ):
        super(LandCoverSoilDialog, self).__init__(parent)
        self.setupUi(self)
        # 프로젝트 XML to dic 자료 받아서 전역 변수 셋팅
        self._xmltodict = _xmltodic
        self._LandCoverCount = _LandCoverCount
        self._GreenAmptCount = _GreenAmptCount
        self._SoilDepthCount = _SoilDepthCount
        self._grmDialogFlag = _grmDialogFlag  # Setup / Run GRM 창 실행 중인지 확인
        self.StaticDB = (
            os.path.dirname(os.path.realpath(__file__)) + "\DLL\GRMStaticDB.xml"
        )

        print("self._grmDialogFlag :: " + str(self._grmDialogFlag))

        self.dataNameCur = None
        self.dataNameLC = EnumDataName(1).name
        self.dataNameST = EnumDataName(2).name
        self.dataNameSD = EnumDataName(3).name
        self.attUi = attWindow(self)
        #self.paranetUI = self
        self.attUi.btnOK.clicked.connect(self.applySelectedReferenceValues)
        self.initControls()

    def showAttTable(self, dataName, row):
        global _SelectedParentRow
        _SelectedParentRow = row
        self.dataNameCur = dataName
        self.attUi.setGeometry(1000, 1000, 900, 400)  # 서브 창의 위치와 크기 설정
        # 속성이 선택되면, 그에 맞게 내용 연결하고, 크기 등 조정
        if self.dataNameCur == self.dataNameLC:
            self.attUi.tableWidget.setGeometry(QRect(10, 10, 880, 340)) # Set geometry (x, y, width, height)
            self.SetLandcoverRefTable(self.attUi.tableWidget)
        if self.dataNameCur == self.dataNameST:
            self.SetGreenAmptRefTable(self.attUi.tableWidget)
        if self.dataNameCur == self.dataNameSD:
            self.SetSoilDepthRefTable(self.attUi.tableWidget)
        self.attUi.show()

    # 각각의 컨트롤 들을 초기 값이나 설정을 셋팅
    def initControls(self):
        self.btnCancel.clicked.connect(self.closeForm)

        # 확인버튼을 눌렀을 때
        self.btnOK.clicked.connect(self.OKForm)

        # 초기 모든 변수값 셋팅
        self.SetProjectValue()

        # 콤보 박스에 레이어 목록 적용 값 셋팅
        self.SetLayerListCombobox()

        # 라디오 버튼 셋팅
        self.SetRadio()

        # 테이블 헤더 설정
        self.SetTableHeader()

        # 각각의 테이블에 데이터 값 읽어서 넣기
        # 1순위 - 프로젝트 파일 데이터
        # 2순위 - 프로젝트 파일 내에 Vat 파일 경로
        self.SetTableData()
        self.tblLandCover.cellDoubleClicked.connect(
            lambda: self.showAttTable(self.dataNameLC, self.tblLandCover.currentRow())
        )
        self.tblGreenAmpt.cellDoubleClicked.connect(
            lambda: self.showAttTable(self.dataNameST, self.tblGreenAmpt.currentRow())
        )
        self.tblSoilDepth.cellDoubleClicked.connect(
            lambda: self.showAttTable(self.dataNameSD, self.tblSoilDepth.currentRow())
        )

        # 콤보 박스 변경시 선택된 콤보 박스 레이어 목록으로 Table 셋팅
        self.cmbLandCover.activated.connect(
            lambda: self.Get_ComboBox_LayerPath(
                self.cmbLandCover, self.tblLandCover, self.txtLandCover, self.dataNameLC
            )
        )
        self.cmbSoilTexture.activated.connect(
            lambda: self.Get_ComboBox_LayerPath(
                self.cmbSoilTexture, self.tblGreenAmpt, self.txtSoilTexture, self.dataNameST
            )
        )
        self.cmbSoilDepth.activated.connect(
            lambda: self.Get_ComboBox_LayerPath(
                self.cmbSoilDepth, self.tblSoilDepth, self.txtSoilDepth, self.dataNameSD
            )
        )

        # Vat 선택 버튼 클릭 이벤트(선택된 파일로 테이블값이 변경 됨)
        self.btnVatLand.clicked.connect(
            lambda: self.SelectVat("btnVatLand", self.txtLandCover)
        )
        self.btnVatSoilTexture.clicked.connect(
            lambda: self.SelectVat("btnVatSoilTexture", self.txtSoilTexture)
        )
        self.btnVatDepth.clicked.connect(
            lambda: self.SelectVat("btnVatDepth", self.txtSoilDepth)
        )

        self.btn_LAI_file.clicked.connect(
            lambda is_checked: self.select_txt_file(self.path_LAI_file)
        )
        self.btn_bianey_criddle_coet.clicked.connect(
            lambda is_checked: self.select_txt_file(self.path_blaney_criddle_coet)
        )

    # 사용자가 VAT 파일 바꿀때 테이블 값도 바뀌어서 적용
    def SelectVat(self, button, txtbox):
        try:
            dir = os.path.dirname(txtbox.text())
            filename = QFileDialog.getOpenFileName(
                self, "Select VAT file ", dir, "*.vat"
            )[0]
            if filename:
                txtbox.setText(filename)
                if button == "btnVatLand":
                    self.SetVATValue(
                        self.txtLandCover.text(), self.tblLandCover, self.dataNameLC
                    )
                elif button == "btnVatSoilTexture":
                    self.SetVATValue(
                        self.txtSoilTexture.text(), self.tblGreenAmpt, self.dataNameST
                    )
                elif button == "btnVatDepth":
                    self.SetVATValue(
                        self.txtSoilDepth.text(), self.tblSoilDepth, self.dataNameSD
                    )
        except Exception as e:
            MsError(e)

    @error_decorator
    def select_txt_file(self, txtbox: QLineEdit):
        dir = os.path.dirname(txtbox.text())
        filename = QFileDialog.getOpenFileName(
            self, "select output file ", dir, "*.txt"
        )[0]
        if filename:
            txtbox.setText(filename)

    def Get_ComboBox_LayerPath(self, combox, table, txtboxControl, dataName):
        try:
            if combox.currentIndex() != 0:
                self.layerPath = (
                    GetcomboSelectedLayerPath(combox)
                )
                self.pfn_vat = self.layerPath.replace(".asc", ".vat").replace(".tif", ".vat")
                if ChFile_Exists(self.pfn_vat.lower()):
                    txtboxControl.setText(str(self.pfn_vat))
                    self.SetVATValue(self.pfn_vat, table, dataName)
        except Exception as e:
            MsError(e)

    def OKForm(self):
        if self.rbtUseLCLayer.isChecked():
            if self.cmbLandCover.currentIndex() == 0:
                MsInfo(" Layer was not selected ")
                self.cmbLandCover.setFocus()
                return

            if self.txtLandCover.text() == "":
                MsInfo("The VAT file was not selected.")
                self.txtLandCover.setFocus()
                return

        if self.rbtUseSoilTextureLayer.isChecked():
            if self.cmbSoilTexture.currentIndex() == 0:
                MsInfo(" Layer was not selected ")
                self.cmbSoilTexture.setFocus()
                return

            if self.txtSoilTexture.text() == "":
                MsInfo("The VAT file was not selected.")
                self.txtSoilTexture.setFocus()
                return

        if self.rbtUseSoilDepthLayer.isChecked():
            if self.cmbSoilDepth.currentIndex() == 0:
                MsInfo(" Layer was not selected ")
                self.cmbSoilDepth.setFocus()
                return

            if self.txtSoilDepth.text() == "":
                MsInfo("The VAT file was not selected.")
                self.txtSoilDepth.setFocus()
                return

        # 1. 라디오 rbtUseConstLCAtt
        if self.rbtUseConstLCAtt.isChecked():
            if self.Checktxtbox(self.txtCoefficient):
                result = float(self.txtCoefficient.text())
                if not (0.0015 <= result and result <= 1.5):
                    MsInfo(
                        "{0}\n{1}".format(
                            "[Land cover roughness coefficient] is invalid.",
                            "0.0015<=Land cover roughness coefficient<=1.5",
                        )
                    )
                    self.txtCoefficient.setFocus()
                    return
            else:
                MsInfo(
                    "{0}\n{1}".format(
                        "[Land cover roughness coefficient] is invalid.",
                        "0.0015<=Land cover roughness coefficient<=1.5",
                    )
                )
                self.txtCoefficient.setFocus()
                return

            if self.Checktxtbox(self.txtImpervious):
                result = float(self.txtImpervious.text())
                if not (0 <= result and result <= 1):
                    MsInfo("[Impervious ratio] is invalid. \n0<=Impervious ration<=1")
                    self.txtImpervious.setFocus()
                    return
            else:
                MsInfo("[Impervious ratio] is invalid. \n0<=Impervious ration<=1")
                self.txtImpervious.setFocus()
                return

        # 2. rbtUseConstTextureAtt 선택 시,
        if self.rbtUseConstTextureAtt.isChecked():
            if self.Checktxtbox(self.txtPorosity):
                result = float(self.txtPorosity.text())
                if not (0 <= result and result <= 1):
                    MsInfo("[Porosity] is invalid. \n0<=Porosity<=1")
                    self.txtPorosity.setFocus()
                    return
            else:
                MsInfo("[Porosity] is invalid. \n0<=Porosity<=1")
                self.txtPorosity.setFocus()
                return

            if self.Checktxtbox(self.txtEffective_porosity):
                result = float(self.txtEffective_porosity.text())
                if not (0 <= result and result <= 1):
                    MsInfo(
                        "[Effective poropsity] is invalid. \n0<=Effective porosity<=1"
                    )
                    self.txtEffective_porosity.setFocus()
                    return
            else:
                MsInfo("[Effective poropsity] is invalid. \n0<=Effective porosity<=1")
                self.txtEffective_porosity.setFocus()
                return

            if self.Checktxtbox(self.txtSuction_head):
                result = float(self.txtSuction_head.text())
                if not (0 <= result and result <= 9999):
                    MsInfo(
                        "[Wetting front suction head] is invalid. \n0<=Wetting front suction head<=9999"
                    )
                    self.txtSuction_head.setFocus()
                    return
            else:
                MsInfo(
                    "[Wetting front suction head] is invalid. \n0<=Wetting front suction head<=9999"
                )
                self.txtSuction_head.setFocus()
                return

            if self.Checktxtbox(self.txtConductiovity):
                result = float(self.txtConductiovity.text())
                if not (0 <= result and result <= 1):
                    MsInfo(
                        "[Hydraulic conductivity] is invalid. \n0<=Hydraulic conductivity<=1"
                    )
                    self.txtConductiovity.setFocus()
                    return
            else:
                MsInfo(
                    "[Hydraulic conductivity] is invalid. \n0<=Hydraulic conductivity<=1"
                )
                self.txtConductiovity.setFocus()
                return

        # 3.rbtUseConstDepth 체크
        if self.rbtUseConstDepth.isChecked():
            if self.Checktxtbox(self.txtSoil_depth):
                result = float(self.txtSoil_depth.text())
                if not (0 <= result and result <= 9999):
                    MsInfo("[Soil Depth] is invalid.\n0<=Soil Depth<=9999")
                    self.txtSoil_depth.setFocus()
                    return
            else:
                MsInfo("[Soil Depth] is invalid.\n0<=Soil Depth<=9999")
                self.txtSoil_depth.setFocus()
                return

        # GMP 파일에 Lanccover,depth.. xml 생성
        self.DataSave()
        # _util.MessageboxShowInfo("Land cover / soil", "Land covers and soil attributes setup are completed.")

        quit_msg = " Land covers and soil attributes setup was completed.   "
        reply = QMessageBox.information(
            self, "Land cover / soil", quit_msg, QMessageBox.Ok
        )
        if reply == QMessageBox.Ok:
            self.close()

    # QlineEdit 값 체크
    def Checktxtbox(self, textbox):
        if textbox.text() != "" and self.isFloat(textbox.text()):
            return True
        else:
            return False

    # Vat 파일에서 읽어 와서 테이블에 값셋팅 하기
    def SetVATValue(self, path, table, dataName):
        try:
            if path != "":
                temOutput = tempfile.mktemp() + ".txt"
                # fileObj = codecs.open( path, "r", "utf-8" )
                # lines = fileObj.readlines()
                try:
                    with open(path, "r", encoding="cp949") as f:
                        lines = f.readlines()
                except Exception as e:
                    with open(path, "r", encoding="utf-8") as f:
                        lines = f.readlines()

            # 테이블 초기화
            table.clear()
            if dataName ==self.dataNameLC:
                table.setColumnCount(7)
                table.setHorizontalHeaderLabels(
                    [
                        "GridValue",
                        "UserLandCover",
                        "GRMCode",
                        "RoughnessCoefficient",
                        "ImperviousRatio",
                        "CanopyRatio",
                        "InterceptionMaxWaterCanopy_mm",
                    ]
                )

            elif dataName == self.dataNameST:
                table.setColumnCount(7)
                table.setHorizontalHeaderLabels(
                    [
                        "GridValue",
                        "USERSoil",
                        "GRMCode",
                        "Porosity",
                        "EffectivePorosity",
                        "WFSoilSuctionHead",
                        "HydraulicConductivity",
                    ]
                )
            elif dataName == self.dataNameSD:
                table.setColumnCount(4)
                table.setHorizontalHeaderLabels(
                    ["GridValue", "UserDepthClass", "GRMCode", "SoilDepth"]
                )
            table.setRowCount(int(len(lines)))

            # Table에 데이터 값 대입
            for i in range(0, len(lines)):
                if lines[i] is not None and lines[i] != "":
                    splitsdata = lines[i].split(",")
                    # item1 = QTableWidgetItem(splitsdata[0])
                    item1 = QTableWidgetItem(splitsdata[0])
                    item1.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                    table.setItem(i, 0, QTableWidgetItem(item1))
                    item2 = QTableWidgetItem(splitsdata[1])
                    item2.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                    table.setItem(i, 1, QTableWidgetItem(item2))

                    txtvalue = splitsdata[1]
                    if txtvalue.upper() == "USER":
                        user = True
                    else:
                        user = False
                    self.SetMainTableValue(
                        splitsdata[1].strip(), table, (i), dataName, user
                    )
        except Exception as es:
            MsError(es)

    # 메인창 Land cover tablewidget 테이블에 데이터 셋팅 (3~ 이후 컬럼의 데이터 값을 StaticDB 셋팅)
    def SetMainTableValue(self, value, widget, row, dataName, user):
        doc = ET.parse(self.StaticDB)
        root = doc.getroot()
        if dataName == self.dataNameLC:
            for element in root.findall(
                "{http://tempuri.org/DataSet1.xsd}LandCoverParameter"
            ):
                if user:
                    item1 = QTableWidgetItem(
                        element.findtext("{http://tempuri.org/DataSet1.xsd}GRMCode")
                    )
                    item1.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                    widget.setItem(row, 2, QTableWidgetItem("USER"))
                    widget.setItem(row, 3, QTableWidgetItem(""))
                    widget.setItem(row, 4, QTableWidgetItem(""))
                    widget.setItem(row, 5, QTableWidgetItem(""))
                    widget.setItem(row, 6, QTableWidgetItem(""))
                    break
                else:
                    if (
                        element.findtext("{http://tempuri.org/DataSet1.xsd}LandCoverK")
                        == value
                        or element.findtext(
                            "{http://tempuri.org/DataSet1.xsd}LandCoverE"
                        )
                        == value
                        or element.findtext("{http://tempuri.org/DataSet1.xsd}GRMCode")
                        == value
                    ):
                        item1 = QTableWidgetItem(
                            element.findtext("{http://tempuri.org/DataSet1.xsd}GRMCode")
                        )
                        item1.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                        widget.setItem(row, 2, QTableWidgetItem(item1))
                        widget.setItem(
                            row,
                            3,
                            QTableWidgetItem(
                                element.findtext(
                                    "{http://tempuri.org/DataSet1.xsd}RoughnessCoefficient"
                                )
                            ),
                        )
                        widget.setItem(
                            row,
                            4,
                            QTableWidgetItem(
                                element.findtext(
                                    "{http://tempuri.org/DataSet1.xsd}ImperviousRatio"
                                )
                            ),
                        )
                        widget.setItem(
                            row,
                            5,
                            QTableWidgetItem(
                                element.findtext(
                                    "{http://tempuri.org/DataSet1.xsd}CanopyRatio"
                                )
                            ),
                        )
                        widget.setItem(
                            row,
                            6,
                            QTableWidgetItem(
                                element.findtext(
                                    "{http://tempuri.org/DataSet1.xsd}InterceptionMaxWaterCanopy_mm"
                                )
                            ),
                        )
                        break

        elif dataName == self.dataNameST:
            for element in root.findall(
                "{http://tempuri.org/DataSet1.xsd}GreenAmptSoilParameter"
            ):
                if user:
                    item1 = QTableWidgetItem(
                        element.findtext("{http://tempuri.org/DataSet1.xsd}GRMCode")
                    )
                    item1.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                    widget.setItem(row, 2, QTableWidgetItem("USER"))
                    widget.setItem(row, 3, QTableWidgetItem(""))
                    widget.setItem(row, 4, QTableWidgetItem(""))
                    widget.setItem(row, 5, QTableWidgetItem(""))
                    widget.setItem(row, 6, QTableWidgetItem(""))
                else:
                    if (
                        element.findtext(
                            "{http://tempuri.org/DataSet1.xsd}SoilTextureK"
                        )
                        == value
                    ):
                        item1 = QTableWidgetItem(
                            element.findtext("{http://tempuri.org/DataSet1.xsd}GRMCode")
                        )
                        item1.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                        widget.setItem(
                            row,
                            2,
                            QTableWidgetItem(
                                element.findtext(
                                    "{http://tempuri.org/DataSet1.xsd}GRMCode"
                                )
                            ),
                        )
                        widget.setItem(
                            row,
                            3,
                            QTableWidgetItem(
                                element.findtext(
                                    "{http://tempuri.org/DataSet1.xsd}PorosityDefault"
                                )
                            ),
                        )
                        widget.setItem(
                            row,
                            4,
                            QTableWidgetItem(
                                element.findtext(
                                    "{http://tempuri.org/DataSet1.xsd}EffectivePorosityDefault"
                                )
                            ),
                        )
                        widget.setItem(
                            row,
                            5,
                            QTableWidgetItem(
                                element.findtext(
                                    "{http://tempuri.org/DataSet1.xsd}WFSoilSuctionHeadDefault"
                                )
                            ),
                        )
                        widget.setItem(
                            row,
                            6,
                            QTableWidgetItem(
                                element.findtext(
                                    "{http://tempuri.org/DataSet1.xsd}HydraulicConductivity"
                                )
                            ),
                        )
                        break

                    elif (
                        element.findtext(
                            "{http://tempuri.org/DataSet1.xsd}SoilTextureE"
                        )
                        == value
                    ):
                        item1 = QTableWidgetItem(
                            element.findtext("{http://tempuri.org/DataSet1.xsd}GRMCode")
                        )
                        item1.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                        widget.setItem(
                            row,
                            2,
                            QTableWidgetItem(
                                element.findtext(
                                    "{http://tempuri.org/DataSet1.xsd}GRMCode"
                                )
                            ),
                        )
                        widget.setItem(
                            row,
                            3,
                            QTableWidgetItem(
                                element.findtext(
                                    "{http://tempuri.org/DataSet1.xsd}PorosityDefault"
                                )
                            ),
                        )
                        widget.setItem(
                            row,
                            4,
                            QTableWidgetItem(
                                element.findtext(
                                    "{http://tempuri.org/DataSet1.xsd}EffectivePorosityDefault"
                                )
                            ),
                        )
                        widget.setItem(
                            row,
                            5,
                            QTableWidgetItem(
                                element.findtext(
                                    "{http://tempuri.org/DataSet1.xsd}WFSoilSuctionHeadDefault"
                                )
                            ),
                        )
                        widget.setItem(
                            row,
                            6,
                            QTableWidgetItem(
                                element.findtext(
                                    "{http://tempuri.org/DataSet1.xsd}HydraulicConductivity"
                                )
                            ),
                        )
                        break

                    elif (
                        element.findtext("{http://tempuri.org/DataSet1.xsd}GRMCode")
                        == value
                    ):
                        item1 = QTableWidgetItem(
                            element.findtext("{http://tempuri.org/DataSet1.xsd}GRMCode")
                        )
                        item1.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                        widget.setItem(
                            row,
                            2,
                            QTableWidgetItem(
                                element.findtext(
                                    "{http://tempuri.org/DataSet1.xsd}GRMCode"
                                )
                            ),
                        )
                        widget.setItem(
                            row,
                            3,
                            QTableWidgetItem(
                                element.findtext(
                                    "{http://tempuri.org/DataSet1.xsd}PorosityDefault"
                                )
                            ),
                        )
                        widget.setItem(
                            row,
                            4,
                            QTableWidgetItem(
                                element.findtext(
                                    "{http://tempuri.org/DataSet1.xsd}EffectivePorosityDefault"
                                )
                            ),
                        )
                        widget.setItem(
                            row,
                            5,
                            QTableWidgetItem(
                                element.findtext(
                                    "{http://tempuri.org/DataSet1.xsd}WFSoilSuctionHeadDefault"
                                )
                            ),
                        )
                        widget.setItem(
                            row,
                            6,
                            QTableWidgetItem(
                                element.findtext(
                                    "{http://tempuri.org/DataSet1.xsd}HydraulicConductivity"
                                )
                            ),
                        )
                        break

        elif dataName == self.dataNameSD:
            for element in root.findall(
                "{http://tempuri.org/DataSet1.xsd}SoilDepthParameter"
            ):
                if user:
                    item1 = QTableWidgetItem(
                        element.findtext("{http://tempuri.org/DataSet1.xsd}GRMCode")
                    )
                    item1.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                    widget.setItem(row, 2, QTableWidgetItem("USER"))
                    widget.setItem(row, 3, QTableWidgetItem(""))
                    break
                else:
                    if (
                        element.findtext(
                            "{http://tempuri.org/DataSet1.xsd}SoilDepthClassK"
                        )
                        == value
                    ):
                        item1 = QTableWidgetItem(
                            element.findtext("{http://tempuri.org/DataSet1.xsd}GRMCode")
                        )
                        item1.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                        widget.setItem(row, 2, QTableWidgetItem(item1))
                        widget.setItem(
                            row,
                            3,
                            QTableWidgetItem(
                                element.findtext(
                                    "{http://tempuri.org/DataSet1.xsd}SoilDepthDefault"
                                )
                            ),
                        )
                        break
                    elif (
                        element.findtext(
                            "{http://tempuri.org/DataSet1.xsd}SoilDepthClassE"
                        )
                        == value
                    ):
                        item1 = QTableWidgetItem(
                            element.findtext("{http://tempuri.org/DataSet1.xsd}GRMCode")
                        )
                        item1.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                        widget.setItem(row, 2, QTableWidgetItem(item1))
                        widget.setItem(
                            row,
                            3,
                            QTableWidgetItem(
                                element.findtext(
                                    "{http://tempuri.org/DataSet1.xsd}SoilDepthDefault"
                                )
                            ),
                        )
                        break
                    elif (
                        element.findtext("{http://tempuri.org/DataSet1.xsd}GRMCode")
                        == value
                    ):
                        item1 = QTableWidgetItem(
                            element.findtext("{http://tempuri.org/DataSet1.xsd}GRMCode")
                        )
                        item1.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                        widget.setItem(row, 2, QTableWidgetItem(item1))
                        widget.setItem(
                            row,
                            3,
                            QTableWidgetItem(
                                element.findtext(
                                    "{http://tempuri.org/DataSet1.xsd}SoilDepthDefault"
                                )
                            ),
                        )
                        break

    def closeForm(self):
        self.close()  # 폼 종료

    # 초기 모든 변수값 셋팅 (프로젝트 파일에서 값을 읽어서 초기 셋팅 값을 결정함)
    def SetProjectValue(self):
        self.LandCoverType = self._xmltodict["GRMProject"]["ProjectSettings"][
            "LandCoverDataType"
        ]
        self.SoilTextureType = self._xmltodict["GRMProject"]["ProjectSettings"][
            "SoilTextureDataType"
        ]
        self.SoilDepthType = self._xmltodict["GRMProject"]["ProjectSettings"][
            "SoilDepthDataType"
        ]

        # 그룹 박스 타이틀 부분 공백 줄이기
        self.grp1.setStyleSheet("QGroupBox{padding-top:15px;margin-top:-15px;}")
        self.grp_2.setStyleSheet("QGroupBox{padding-top:15px;margin-top:-15px;}")
        self.groupBox_3.setStyleSheet("QGroupBox{padding-top:15px;margin-top:-15px;}")
        self.groupBox_4.setStyleSheet("QGroupBox{padding-top:15px;margin-top:-15px;}")
        self.groupBox_5.setStyleSheet("QGroupBox{padding-top:15px;margin-top:-15px;}")
        self.groupBox_6.setStyleSheet("QGroupBox{padding-top:15px;margin-top:-15px;}")

    # 콤보 박스에 레이어 목록 넣어 두기
    def SetLayerListCombobox(self):
        # 콤보 박스 레이어 받아 오기 설정
        layers = QgsProject.instance().mapLayers().values()

        if self._grmDialogFlag == 1:
            lly = list(layers)
            remove_set = QgsProject.instance().mapLayersByName("WSFAlayerload")
            layers = [i for i in lly if i not in remove_set]

        SetCommbox(layers, self.cmbLandCover, "")
        SetCommbox(layers, self.cmbSoilTexture, "")
        SetCommbox(layers, self.cmbSoilDepth, "")

    # 라디오 버튼 셋팅
    def SetRadio(self):
        try:
            # Lanccover 첫번째 라디오 버튼 클릭 이벤트 처리
            self.rbtUseLCLayer.clicked.connect(self.LCLayer_CheckedChanged)

            # Lanccover 두번째 라디오 버튼 클릭 이벤트 처리
            self.rbtUseConstLCAtt.clicked.connect(self.ConstLCAtt_CheckedChanged)

            # SoilTexture 첫번째 라디오 버튼 클릭 이벤트 처리
            self.rbtUseSoilTextureLayer.clicked.connect(
                self.SoilTextureLayer_CheckedChanged
            )

            # SoilTexture 두번째 라디오 버튼 클릭 이벤트 처리
            self.rbtUseConstTextureAtt.clicked.connect(self.TextureAtt_CheckedChanged)

            # SoilDepth  첫번째 라디오 버튼 클릭 이벤트 처리
            self.rbtUseSoilDepthLayer.clicked.connect(
                self.SoilDepthLayer_CheckedChanged
            )

            # SoilDepth  두번째 라디오 버튼 클릭 이벤트 처리
            self.rbtUseConstDepth.clicked.connect(self.ConstDepth_CheckedChanged)

            # ------------------------Lndcover 라디오 버튼 셋팅 시작---------------------------------
            # 2017/11/27 =====

            if self.LandCoverType == "File":
                # 라디오 버튼 클릭시 활성, 비활성 컨트롤 함수
                self.LCLayer_CheckedChanged()

                # 라디오 버튼 체크 상태로 변환
                self.rbtUseLCLayer.setChecked(True)

                # 텍스트 파일에 Vat 파일 경로를 셋팅
                self.txtLandCover.setText(
                    self._xmltodict["GRMProject"]["ProjectSettings"]["LandCoverVATFile"]
                )

                # 콤보 박스의 선택 레이어를 프로젝트 파일에 있는 것으로 셋팅
                LandCoverFile = self._xmltodict["GRMProject"]["ProjectSettings"][
                    "LandCoverFile"
                ]
                if LandCoverFile != "" and LandCoverFile is not None:
                    LandCoverName = GetFile_Name(LandCoverFile)
                    SetCommbox2(self.cmbLandCover, LandCoverName, LandCoverFile)
            else:
                # 2번째 라디오 버튼 클릭시 이벤트 함수
                self.ConstLCAtt_CheckedChanged()

                # 2번째 라디오 버튼 체크 상태로 변환
                self.rbtUseConstLCAtt.setChecked(True)

                # 사용자 일괄 적용 라디오 버튼 클릭시 적용 할 텍스트 박스의 값을 셋팅
                self.txtCoefficient.setText(
                    self._xmltodict["GRMProject"]["ProjectSettings"][
                        "ConstantRoughnessCoeff"
                    ]
                )
                self.txtImpervious.setText(
                    self._xmltodict["GRMProject"]["ProjectSettings"][
                        "ConstantImperviousRatio"
                    ]
                )
            # ------------------------Lndcover 라디오 버튼 셋팅 종료----------------------------------

            self.path_LAI_file.setText(
                self._xmltodict["GRMProject"]["ProjectSettings"]["LAIFile"]
            )
            self.path_blaney_criddle_coet.setText(
                self._xmltodict["GRMProject"]["ProjectSettings"][
                    "BlaneyCriddleCoefDataFile"
                ]
            )

            # ------------------------SoilTextureVATFile 라디오 버튼 셋팅 시작---------------------------------
            # SoilTextureVATFile 이벤트
            if self.SoilTextureType == "File":
                # SoilTextureVATFile 항목의 첫번째 라디오 버튼 클릭 이벤트(컨트롤 활성, 비활성 기능 연동)
                self.SoilTextureLayer_CheckedChanged()

                # 라디오 버튼 클릭 상태로 셋팅
                self.rbtUseSoilTextureLayer.setChecked(True)

                # 텍스트 박스에 VAT 파일 경로 넣기
                self.txtSoilTexture.setText(
                    self._xmltodict["GRMProject"]["ProjectSettings"][
                        "SoilTextureVATFile"
                    ]
                )

                # layer 콤보 박스 항목을 프로젝트 파일의 데이터 내용에 해당되는 콤보 박스 항목으로 셋팅
                SoilTextureFile = self._xmltodict["GRMProject"]["ProjectSettings"][
                    "SoilTextureFile"
                ]
                if SoilTextureFile != "" and SoilTextureFile is not None:
                    SoilTextureName = GetFile_Name(SoilTextureFile)
                    SetCommbox2(self.cmbSoilTexture, SoilTextureName, SoilTextureFile)
            else:
                # 2번째 라디오 버튼(일괄 적용) 클릭 이벤트
                self.TextureAtt_CheckedChanged()

                # 라디오 버튼 클릭 상태로 설정
                self.rbtUseConstTextureAtt.setChecked(True)

                # 프로젝트 파일에서 각각 텍스트 값을 입력
                self.txtPorosity.setText(
                    self._xmltodict["GRMProject"]["ProjectSettings"][
                        "ConstantSoilPorosity"
                    ]
                )
                self.txtEffective_porosity.setText(
                    self._xmltodict["GRMProject"]["ProjectSettings"][
                        "ConstantSoilEffPorosity"
                    ]
                )
                self.txtSuction_head.setText(
                    self._xmltodict["GRMProject"]["ProjectSettings"][
                        "ConstantSoilWettingFrontSuctionHead"
                    ]
                )
                self.txtConductiovity.setText(
                    self._xmltodict["GRMProject"]["ProjectSettings"][
                        "ConstantSoilHydraulicConductivity"
                    ]
                )

            # ------------------------SoilTextureVATFile 라디오 버튼 셋팅 종료----------------------------------

            # ------------------------SoilDepth 라디오 버튼 셋팅 시작----------------------------------
            if self.SoilDepthType == "File":
                # SoilDepth 항목의 첫번째 체크 박스 선택 이벤트 함수
                self.SoilDepthLayer_CheckedChanged()

                # SoilDepth 항목의 첫번째 라디오 버튼 클릭 상태로 설정
                self.rbtUseSoilDepthLayer.setChecked(True)

                # 텍스트 박스에 VAT 파일 경로 넣기
                self.txtSoilDepth.setText(
                    self._xmltodict["GRMProject"]["ProjectSettings"]["SoilDepthVATFile"]
                )

                # layer 콤보 박스 항목을 프로젝트 파일의 데이터 내용에 해당되는 콤보 박스 항목으로 셋팅
                SoilDepthFile = self._xmltodict["GRMProject"]["ProjectSettings"][
                    "SoilDepthFile"
                ]
                if SoilDepthFile != "" and SoilDepthFile is not None:
                    SoilDepthName = GetFile_Name(SoilDepthFile)
                    SetCommbox2(self.cmbSoilDepth, SoilDepthName, SoilDepthFile)
            else:
                # SoilDepth 항목의 두번째 체크 박스 선택 이벤트 함수
                self.ConstDepth_CheckedChanged()

                # SoilDepth 항목의 두번째 라디오 버튼 클릭 상태로 설정
                self.rbtUseConstDepth.setChecked(True)

                # 프로젝트 파일에서 값읽어서 텍스트 박스에 셋팅
                self.txtSoil_depth.setText(
                    self._xmltodict["GRMProject"]["ProjectSettings"][
                        "ConstantSoilDepth"
                    ]
                )
        except Exception as e:
            MsError(e)

    # LandCover 첫번째 라이디오 버튼 클릭시 이벤트 처리
    def LCLayer_CheckedChanged(self):
        self.btnVatLand.setEnabled(True)
        self.txtLandCover.setEnabled(True)
        self.cmbLandCover.setEnabled(True)
        self.tblLandCover.setEnabled(True)
        self.txtCoefficient.setEnabled(False)
        self.txtImpervious.setEnabled(False)

    # LandCover 두번째 라이디오 버튼 클릭시 이벤트 처리
    def ConstLCAtt_CheckedChanged(self):
        self.btnVatLand.setEnabled(False)
        self.txtLandCover.setEnabled(False)
        self.cmbLandCover.setEnabled(False)
        self.tblLandCover.setEnabled(False)
        self.txtCoefficient.setEnabled(True)
        self.txtImpervious.setEnabled(True)

    # SoilTexture 첫번째 라디오 버튼 클릭 이벤트 처리
    def SoilTextureLayer_CheckedChanged(self):
        self.cmbSoilTexture.setEnabled(True)
        self.txtSoilTexture.setEnabled(True)
        self.btnVatSoilTexture.setEnabled(True)
        self.tblGreenAmpt.setEnabled(True)
        self.txtPorosity.setEnabled(False)
        self.txtEffective_porosity.setEnabled(False)
        self.txtSuction_head.setEnabled(False)
        self.txtConductiovity.setEnabled(False)

    # SoilTexture 두번째 라디오 버튼 클릭 이벤트 처리
    def TextureAtt_CheckedChanged(self):
        self.cmbSoilTexture.setEnabled(False)
        self.txtSoilTexture.setEnabled(False)
        self.btnVatSoilTexture.setEnabled(False)
        self.tblGreenAmpt.setEnabled(False)
        self.txtPorosity.setEnabled(True)
        self.txtEffective_porosity.setEnabled(True)
        self.txtSuction_head.setEnabled(True)
        self.txtConductiovity.setEnabled(True)

    # SoilDepth  첫번째 라디오 버튼 클릭 이벤트 처리
    def SoilDepthLayer_CheckedChanged(self):
        self.cmbSoilDepth.setEnabled(True)
        self.txtSoilDepth.setEnabled(True)
        self.btnVatDepth.setEnabled(True)
        self.tblSoilDepth.setEnabled(True)
        self.txtSoil_depth.setEnabled(False)

    # SoilDepth  두번째 라디오 버튼 클릭 이벤트 처리
    def ConstDepth_CheckedChanged(self):
        self.cmbSoilDepth.setEnabled(False)
        self.txtSoilDepth.setEnabled(False)
        self.btnVatDepth.setEnabled(False)
        self.tblSoilDepth.setEnabled(False)
        self.txtSoil_depth.setEnabled(True)

    # ====================각각의 테이블 헤더 셋팅 ======================================================================
    def SetTableHeader(self):
        self.SetLandCoverHeader()

        self.SetGreenAmptHeader()

        self.SetSoilDepthHeader()

    # LandCover Table 헤더 셋팅
    def SetLandCoverHeader(self):
        self.tblLandCover.setColumnCount(7)
        self.tblLandCover.setHorizontalHeaderLabels(
            [
                "GridValue",
                "UserLandCover",
                "GRMCode",
                "RoughnessCoefficient",
                "ImperviousRatio",
                "CanopyRatio",
                "InterceptionMaxWaterCanopy_mm",
            ]
        )

    # GreenAmpt Table 헤더 셋팅
    def SetGreenAmptHeader(self):
        self.tblGreenAmpt.setColumnCount(7)
        self.tblGreenAmpt.setHorizontalHeaderLabels(
            [
                "GridValue",
                "USERSoil",
                "GRMCode",
                "Porosity",
                "EffectivePorosity",
                "WFSoilSuctionHead",
                "HydraulicConductivity",
            ]
        )

    # SoilDepth 테이블 헤더 셋팅
    def SetSoilDepthHeader(self):
        self.tblSoilDepth.setColumnCount(4)
        self.tblSoilDepth.setHorizontalHeaderLabels(
            ["GridValue", "UserDepthClass", "GRMCode", "SoilDepth"]
        )

    # 테이블에 데이터 값 넣기
    def SetTableData(self):
        # 1순위 프로젝트 파일내 데이터 값
        # 2순위 Vat 파일 셋팅

        if self.LandCoverType == "File" and self._LandCoverCount != 0:
            self.SetLandCoverTable()

        if self.SoilTextureType == "File" and self._GreenAmptCount != 0:
            self.SetGreenAmptTable()

        if self.SoilDepthType == "File" and self._SoilDepthCount != 0:
            self.SetSoilDepthTable()

    def SetLandCoverTable(self):
        try:
            # 프로젝트 파일에서 불러온 데이터 테이블에 셋팅
            if self._LandCoverCount > 1:
                row = 0
                for artikel in self._xmltodict["GRMProject"]["LandCover"]:
                    self.tblLandCover.insertRow(row)

                    item1 = QTableWidgetItem(artikel["GridValue"])
                    item1.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                    self.tblLandCover.setItem(row, 0, QTableWidgetItem(item1))

                    item2 = QTableWidgetItem(artikel["UserLandCover"])
                    item2.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                    self.tblLandCover.setItem(row, 1, QTableWidgetItem(item2))

                    item3 = QTableWidgetItem(artikel["GRMCode"])
                    item3.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                    self.tblLandCover.setItem(row, 2, QTableWidgetItem(item3))

                    self.tblLandCover.setItem(
                        row, 3, QTableWidgetItem(artikel["RoughnessCoefficient"])
                    )
                    self.tblLandCover.setItem(
                        row, 4, QTableWidgetItem(artikel["ImperviousRatio"])
                    )
                    self.tblLandCover.setItem(
                        row, 5, QTableWidgetItem(artikel["CanopyRatio"])
                    )
                    self.tblLandCover.setItem(
                        row,
                        6,
                        QTableWidgetItem(artikel["InterceptionMaxWaterCanopy_mm"]),
                    )
                    row = row + 1
            elif self._LandCoverCount == 1:
                self.tblLandCover.insertRow(0)

                item1 = QTableWidgetItem(
                    self._xmltodict["GRMProject"]["LandCover"]["GridValue"]
                )
                item1.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                self.tblLandCover.setItem(row, 0, QTableWidgetItem(item1))

                item2 = QTableWidgetItem(
                    self._xmltodict["GRMProject"]["LandCover"]["UserLandCover"]
                )
                item2.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                self.tblLandCover.setItem(row, 1, QTableWidgetItem(item2))

                item3 = QTableWidgetItem(
                    self._xmltodict["GRMProject"]["LandCover"]["GRMCode"]
                )
                item3.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                self.tblLandCover.setItem(row, 2, QTableWidgetItem(item3))

                self.tblLandCover.setItem(
                    row,
                    3,
                    QTableWidgetItem(
                        self._xmltodict["GRMProject"]["LandCover"][
                            "RoughnessCoefficient"
                        ]
                    ),
                )
                self.tblLandCover.setItem(
                    row,
                    4,
                    QTableWidgetItem(
                        self._xmltodict["GRMProject"]["LandCover"]["ImperviousRatio"]
                    ),
                )
                self.tblLandCover.setItem(
                    row,
                    5,
                    QTableWidgetItem(
                        self._xmltodict["GRMProject"]["LandCover"]["CanopyRatio"]
                    ),
                )
                self.tblLandCover.setItem(
                    row,
                    6,
                    QTableWidgetItem(
                        self._xmltodict["GRMProject"]["LandCover"][
                            "InterceptionMaxWaterCanopy_mm"
                        ]
                    ),
                )
            elif self._LandCoverCount == 0:
                if self.cmbLandCover.currentIndex() != 0:
                    self.Get_ComboBox_LayerPath(
                        self.cmbLandCover,
                        self.tblLandCover,
                        self.txtLandCover,
                        self.dataNameLC,
                    )

        except KeyError:
            self.Get_ComboBox_LayerPath(
                self.cmbLandCover, self.tblLandCover, self.txtLandCover, self.dataNameLC
            )

    def SetGreenAmptTable(self):
        try:
            # 프로젝트 파일에서 불러온 데이터 테이블에 셋팅
            if self._GreenAmptCount > 1:
                row = 0
                for artikel in self._xmltodict["GRMProject"]["GreenAmptParameter"]:
                    self.tblGreenAmpt.insertRow(row)

                    item1 = QTableWidgetItem(artikel["GridValue"])
                    item1.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                    self.tblGreenAmpt.setItem(row, 0, QTableWidgetItem(item1))

                    item2 = QTableWidgetItem(artikel["USERSoil"])
                    item2.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                    self.tblGreenAmpt.setItem(row, 1, QTableWidgetItem(item2))

                    item3 = QTableWidgetItem(artikel["GRMCode"])
                    item3.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                    self.tblGreenAmpt.setItem(row, 2, QTableWidgetItem(item3))

                    self.tblGreenAmpt.setItem(
                        row, 3, QTableWidgetItem(artikel["Porosity"])
                    )
                    self.tblGreenAmpt.setItem(
                        row, 4, QTableWidgetItem(artikel["EffectivePorosity"])
                    )
                    self.tblGreenAmpt.setItem(
                        row, 5, QTableWidgetItem(artikel["WFSoilSuctionHead"])
                    )
                    self.tblGreenAmpt.setItem(
                        row, 6, QTableWidgetItem(artikel["HydraulicConductivity"])
                    )
                    row = row + 1
            elif self._GreenAmptCount == 1:
                self.tblGreenAmpt.insertRow(0)

                item1 = QTableWidgetItem(
                    self._xmltodict["GRMProject"]["GreenAmptParameter"]["GridValue"]
                )
                item1.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                self.tblGreenAmpt.setItem(row, 0, QTableWidgetItem(item1))

                item2 = QTableWidgetItem(
                    self._xmltodict["GRMProject"]["GreenAmptParameter"]["USERSoil"]
                )
                item2.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                self.tblGreenAmpt.setItem(row, 1, QTableWidgetItem(item2))

                item3 = QTableWidgetItem(
                    self._xmltodict["GRMProject"]["GreenAmptParameter"]["GRMCode"]
                )
                item3.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                self.tblGreenAmpt.setItem(row, 2, QTableWidgetItem(item3))

                self.tblGreenAmpt.setItem(
                    row,
                    3,
                    QTableWidgetItem(
                        self._xmltodict["GRMProject"]["GreenAmptParameter"]["Porosity"]
                    ),
                )
                self.tblGreenAmpt.setItem(
                    row,
                    4,
                    QTableWidgetItem(
                        self._xmltodict["GRMProject"]["GreenAmptParameter"][
                            "EffectivePorosity"
                        ]
                    ),
                )
                self.tblGreenAmpt.setItem(
                    row,
                    5,
                    QTableWidgetItem(
                        self._xmltodict["GRMProject"]["GreenAmptParameter"][
                            "WFSoilSuctionHead"
                        ]
                    ),
                )
                self.tblGreenAmpt.setItem(
                    row,
                    6,
                    QTableWidgetItem(
                        self._xmltodict["GRMProject"]["GreenAmptParameter"][
                            "HydraulicConductivity"
                        ]
                    ),
                )

        except KeyError:
            self.Get_ComboBox_LayerPath(
                self.cmbSoilTexture, self.tblGreenAmpt, self.txtSoilTexture, self.dataNameST
            )

    def SetSoilDepthTable(self):
        try:
            # 프로젝트 파일에서 불러온 데이터 테이블에 셋팅
            if self._SoilDepthCount > 1:
                row = 0
                for artikel in self._xmltodict["GRMProject"]["SoilDepth"]:
                    self.tblSoilDepth.insertRow(row)

                    item1 = QTableWidgetItem(artikel["GridValue"])
                    item1.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                    self.tblSoilDepth.setItem(row, 0, QTableWidgetItem(item1))

                    item2 = QTableWidgetItem(artikel["UserDepthClass"])
                    item2.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                    self.tblSoilDepth.setItem(row, 1, QTableWidgetItem(item2))

                    item3 = QTableWidgetItem(artikel["GRMCode"])
                    item3.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                    self.tblSoilDepth.setItem(row, 2, QTableWidgetItem(item3))

                    item4 = QTableWidgetItem(artikel["SoilDepth_cm"])
                    self.tblSoilDepth.setItem(row, 3, QTableWidgetItem(item4))
                    row = row + 1

            elif self._SoilDepthCount == 1:
                self.tblSoilDepth.insertRow(0)

                item1 = QTableWidgetItem(
                    self._xmltodict["GRMProject"]["SoilDepth"]["GridValue"]
                )
                item1.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                self.tblSoilDepth.setItem(row, 0, QTableWidgetItem(item1))

                item2 = QTableWidgetItem(
                    self._xmltodict["GRMProject"]["SoilDepth"]["UserDepthClass"]
                )
                item2.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                self.tblSoilDepth.setItem(row, 1, QTableWidgetItem(item2))

                item3 = QTableWidgetItem(
                    self._xmltodict["GRMProject"]["SoilDepth"]["GRMCode"]
                )
                item3.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                self.tblSoilDepth.setItem(row, 2, QTableWidgetItem(item3))

                item4 = QTableWidgetItem(
                    self._xmltodict["GRMProject"]["SoilDepth"]["SoilDepth_cm"]
                )
                self.tblSoilDepth.setItem(row, 3, QTableWidgetItem(item4))
        except Exception as e:
            self.Get_ComboBox_LayerPath(
                self.cmbSoilDepth, self.tblSoilDepth, self.txtSoilDepth, self.dataNameSD
            )
            MsError(e)

    # parent 테이블에서 더블 클릭시, 여기서 sub Qdialog 에 테이블 셋팅 하기
    def SetLandcoverRefTable(self, tableWidget):
        doc = ET.parse(self.StaticDB)
        root = doc.getroot()
        list = []
        for element in root.findall(
            "{http://tempuri.org/DataSet1.xsd}LandCoverParameter"
        ):
            list.append(element.findtext("{http://tempuri.org/DataSet1.xsd}LandCoverE"))
            list.append(element.findtext("{http://tempuri.org/DataSet1.xsd}LandCoverK"))
            list.append(element.findtext("{http://tempuri.org/DataSet1.xsd}GRMCode"))
            list.append(
                element.findtext(
                    "{http://tempuri.org/DataSet1.xsd}RoughnessCoefficient"
                )
            )
            list.append(
                element.findtext("{http://tempuri.org/DataSet1.xsd}ImperviousRatio")
            )
            list.append(
                element.findtext("{http://tempuri.org/DataSet1.xsd}CanopyRatio")
            )
            list.append(
                element.findtext(
                    "{http://tempuri.org/DataSet1.xsd}InterceptionMaxWaterCanopy_mm"
                )
            )

        # table에 값 셋팅
        tableWidget.verticalHeader().hide()
        tableWidget.setColumnCount(7)

        value = int(len(list) / 7)
        tableWidget.setRowCount(value)
        tableWidget.setHorizontalHeaderLabels(
            [
                "LandCoverE",
                "LandCoverK",
                "GRMCode",
                "RoughnessCoefficient",
                "ImperviousRatio",
                "CanopyRatio",
                "InterceptionMaxWaterCanopy_mm",
            ]
        )

        tableWidget.resizeColumnsToContents()
        tableWidget.resizeRowsToContents()
        self.dataNameCur = self.dataNameLC
        tableWidget.itemDoubleClicked.connect(
            lambda: self.applySelectedReferenceValues()
        )
        # 각각의 컬럼에 갑셋팅(xml 상에 'ObTSId', 'ObTSLegend', 'ObTSMissingCount' 항목의 값이 없음
        for i in range(0, value):
            for j in range(0, 7):
                #self.tableWidget.setItem(i, j, QTableWidgetItem(list[7 * i + j]))
                tableWidget.setItem(i, j, QTableWidgetItem(list[7 * i + j]))

    def SetGreenAmptRefTable(self, tableWidget):
        # 프로젝트 파일 로드
        doc = ET.parse(self.StaticDB)

        root = doc.getroot()
        list = []
        for element in root.findall(
            "{http://tempuri.org/DataSet1.xsd}GreenAmptSoilParameter"
        ):
            list.append(
                element.findtext("{http://tempuri.org/DataSet1.xsd}SoilTextureE")
            )
            list.append(
                element.findtext("{http://tempuri.org/DataSet1.xsd}SoilTextureK")
            )
            list.append(element.findtext("{http://tempuri.org/DataSet1.xsd}GRMCode"))
            list.append(
                element.findtext("{http://tempuri.org/DataSet1.xsd}PorosityMin")
            )
            list.append(
                element.findtext("{http://tempuri.org/DataSet1.xsd}PorosityMax")
            )
            list.append(
                element.findtext("{http://tempuri.org/DataSet1.xsd}PorosityDefault")
            )
            list.append(
                element.findtext(
                    "{http://tempuri.org/DataSet1.xsd}EffectivePorosityMin"
                )
            )
            list.append(
                element.findtext(
                    "{http://tempuri.org/DataSet1.xsd}EffectivePorosityMax"
                )
            )
            list.append(
                element.findtext(
                    "{http://tempuri.org/DataSet1.xsd}EffectivePorosityDefault"
                )
            )
            list.append(
                element.findtext(
                    "{http://tempuri.org/DataSet1.xsd}ResidualMoistureContent"
                )
            )
            list.append(
                element.findtext(
                    "{http://tempuri.org/DataSet1.xsd}WFSoilSuctionHeadMin"
                )
            )
            list.append(
                element.findtext(
                    "{http://tempuri.org/DataSet1.xsd}WFSoilSuctionHeadMax"
                )
            )
            list.append(
                element.findtext(
                    "{http://tempuri.org/DataSet1.xsd}WFSoilSuctionHeadDefault"
                )
            )
            list.append(
                element.findtext(
                    "{http://tempuri.org/DataSet1.xsd}HydraulicConductivity"
                )
            )

        # table에 값 셋팅
        tableWidget.verticalHeader().hide()
        tableWidget.setColumnCount(14)

        value = int(len(list) / 14)
        tableWidget.setRowCount(value)
        tableWidget.setHorizontalHeaderLabels(
            [
                "SoilTextureE",
                "SoilTextureK",
                "GRMCode",
                "PorosityMin",
                "PorosityMax",
                "PorosityDefault",
                "EffectivePorosityMin",
                "EffectivePorosityMax",
                "EffectivePorosityDefault",
                "ResidualMoistureContent",
                "WFSoilSuctionHeadMin",
                "WFSoilSuctionHeadMax",
                "WFSoilSuctionHeadDefault",
                "HydraulicConductivity",
            ]
        )

        tableWidget.resizeColumnsToContents()
        tableWidget.resizeRowsToContents()
        self.dataNameCur = self.dataNameST
        tableWidget.itemDoubleClicked.connect(
            lambda: self.applySelectedReferenceValues()
        )

        # 각각의 컬럼에 갑셋팅(xml 상에 'ObTSId', 'ObTSLegend', 'ObTSMissingCount' 항목의 값이 없음
        for i in range(0, value):
            for j in range(0, 14):
                #self.tableWidget.setItem(i, j, QTableWidgetItem(list[14 * i + j]))
                tableWidget.setItem(i, j, QTableWidgetItem(list[14 * i + j]))

    def SetSoilDepthRefTable(self, tableWidget):
        doc = ET.parse(self.StaticDB)

        root = doc.getroot()
        list = []
        for element in root.findall(
            "{http://tempuri.org/DataSet1.xsd}SoilDepthParameter"
        ):
            list.append(element.findtext("{http://tempuri.org/DataSet1.xsd}GRMCode"))
            list.append(
                element.findtext("{http://tempuri.org/DataSet1.xsd}SoilDepthClassE")
            )
            list.append(
                element.findtext("{http://tempuri.org/DataSet1.xsd}SoilDepthClassK")
            )
            list.append(
                element.findtext("{http://tempuri.org/DataSet1.xsd}SoilDepthMin")
            )
            list.append(
                element.findtext("{http://tempuri.org/DataSet1.xsd}SoilDepthMax")
            )
            list.append(
                element.findtext("{http://tempuri.org/DataSet1.xsd}SoilDepthDefault")
            )

        # table에 값 셋팅
        tableWidget.verticalHeader().hide()
        tableWidget.setColumnCount(6)

        value = int(len(list) / 6)

        tableWidget.setRowCount(value)
        tableWidget.setHorizontalHeaderLabels(
            [
                "GRMCode",
                "SoilDepthClassE",
                "SoilDepthClassK",
                "SoilDepthMin",
                "SoilDepthMax",
                "SoilDepth",
            ]
        )

        tableWidget.resizeColumnsToContents()
        tableWidget.resizeRowsToContents()
        self.dataNameCur = self.dataNameSD
        tableWidget.itemDoubleClicked.connect(
            lambda: self.applySelectedReferenceValues()
        )
        # 각각의 컬럼에 갑셋팅(xml 상에 'ObTSId', 'ObTSLegend', 'ObTSMissingCount' 항목의 값이 없음
        for i in range(0, value):
            for j in range(0, 6):
                #self.tableWidget.setItem(i, j, QTableWidgetItem(list[6 * i + j]))
                tableWidget.setItem(i, j, QTableWidgetItem(list[6 * i + j]))

    # 작은 창 테이블 클릭시 큰 테이블에 선택값 셋팅
    def applySelectedReferenceValues(self):
        row = self.attUi.tableWidget.currentRow()
        tableWidget =self.attUi.tableWidget
        try:
            items = []

            if self.dataNameCur == self.dataNameLC:
                item2 = tableWidget.item(row, 0)
                item3 = tableWidget.item(row, 1)
                item4 = tableWidget.item(row, 2)
                item5 = tableWidget.item(row, 3)
                item6 = tableWidget.item(row, 4)
                item7 = tableWidget.item(row, 5)
                item8 = tableWidget.item(row, 6)

                items = [item4, item5, item6, item7, item8]
                tbl = self.tblLandCover

            elif self.dataNameCur == self.dataNameST:
                item2 = tableWidget.item(row, 0)
                item3 = tableWidget.item(row, 1)
                item4 = tableWidget.item(row, 2)
                item5 = tableWidget.item(row, 5)
                item6 = tableWidget.item(row, 8)
                item7 = tableWidget.item(row, 12)
                item8 = tableWidget.item(row, 13)

                items = [item4, item5, item6, item7, item8]
                tbl = self.tblGreenAmpt

            elif self.dataNameCur == self.dataNameSD:
                item2 = tableWidget.item(row, 0)
                item3 = tableWidget.item(row, 1)
                item4 = tableWidget.item(row, 2)
                item5 = tableWidget.item(row, 5)

                items = [item2, item5]
                tbl = self.tblSoilDepth

            for i, it in enumerate(items):
                if tbl.item(_SelectedParentRow, i + 2):
                    tbl.item(_SelectedParentRow, i + 2).setText(it.text())
                else:
                    tbl.setItem(_SelectedParentRow, i + 2, QTableWidgetItem(it.text()))

        except AttributeError as e:
            print(e)
            MsError("This is not valid data.")
        finally:
            self.attUi.close_window()

    def DataSave(self):
        if self.rbtUseLCLayer.isChecked():
            self._xmltodict["GRMProject"]["ProjectSettings"][
                "LandCoverDataType"
            ] = "File"
            if self.cmbLandCover.currentIndex() != 0:
                LandCoverLayerPath = GetcomboSelectedLayerPath(self.cmbLandCover)
            else:
                LandCoverLayerPath = ""

            self._xmltodict["GRMProject"]["ProjectSettings"][
                "LandCoverFile"
            ] = LandCoverLayerPath
            self._xmltodict["GRMProject"]["ProjectSettings"][
                "LandCoverVATFile"
            ] = self.txtLandCover.text()
            self.dataSeve_Landcover()
        else:
            self._xmltodict["GRMProject"]["ProjectSettings"][
                "LandCoverDataType"
            ] = "Constant"
            self._xmltodict["GRMProject"]["ProjectSettings"][
                "ConstantRoughnessCoeff"
            ] = self.txtCoefficient.text()
            self._xmltodict["GRMProject"]["ProjectSettings"][
                "ConstantImperviousRatio"
            ] = self.txtImpervious.text()

        if self.path_LAI_file.text() != "":
            self._xmltodict["GRMProject"]["ProjectSettings"][
                "LAIFile"
            ] = self.path_LAI_file.text()
        if self.path_blaney_criddle_coet.text() != "":
            self._xmltodict["GRMProject"]["ProjectSettings"][
                "BlaneyCriddleCoefDataFile"
            ] = self.path_blaney_criddle_coet.text()

        #  타입 설정
        if self.rbtUseSoilTextureLayer.isChecked():
            self._xmltodict["GRMProject"]["ProjectSettings"][
                "SoilTextureDataType"
            ] = "File"
            if self.cmbSoilTexture.currentIndex() != 0:
                SoilTextureLayerPath = GetcomboSelectedLayerPath(self.cmbSoilTexture)
            else:
                SoilTextureLayerPath = ""
            self._xmltodict["GRMProject"]["ProjectSettings"][
                "SoilTextureFile"
            ] = SoilTextureLayerPath
            self._xmltodict["GRMProject"]["ProjectSettings"][
                "SoilTextureVATFile"
            ] = self.txtSoilTexture.text()
            self.dataSeve_SoilTexture()
        else:
            self._xmltodict["GRMProject"]["ProjectSettings"][
                "SoilTextureDataType"
            ] = "Constant"
            self._xmltodict["GRMProject"]["ProjectSettings"][
                "ConstantSoilPorosity"
            ] = self.txtPorosity.text()
            self._xmltodict["GRMProject"]["ProjectSettings"][
                "ConstantSoilEffPorosity"
            ] = self.txtEffective_porosity.text()
            self._xmltodict["GRMProject"]["ProjectSettings"][
                "ConstantSoilWettingFrontSuctionHead"
            ] = self.txtSuction_head.text()
            self._xmltodict["GRMProject"]["ProjectSettings"][
                "ConstantSoilHydraulicConductivity"
            ] = self.txtConductiovity.text()

        #  타입 설정
        if self.rbtUseSoilDepthLayer.isChecked():
            self._xmltodict["GRMProject"]["ProjectSettings"][
                "SoilDepthDataType"
            ] = "File"

            if self.cmbSoilDepth.currentIndex() != 0:
                SoilDepthLayerPath = GetcomboSelectedLayerPath(self.cmbSoilDepth)
            else:
                SoilDepthLayerPath = ""
            self._xmltodict["GRMProject"]["ProjectSettings"][
                "SoilDepthFile"
            ] = SoilDepthLayerPath
            self._xmltodict["GRMProject"]["ProjectSettings"][
                "SoilDepthVATFile"
            ] = self.txtSoilDepth.text()
            self.dataSeve_SoilDepth()
        else:
            self._xmltodict["GRMProject"]["ProjectSettings"][
                "SoilDepthDataType"
            ] = "Constant"
            self._xmltodict["GRMProject"]["ProjectSettings"][
                "ConstantSoilDepth"
            ] = self.txtSoil_depth.text()

    def dataSeve_Landcover(self):
        try:
            # dictionary 에서 LandCover 항목을 모두 제거
            check = self._xmltodict["GRMProject"]["LandCover"]
            if check is not None:
                del self._xmltodict["GRMProject"]["LandCover"]
        except:
            pass

        # dictionary 에서 엘레먼트 생성이 안되서 dic===> XML (element 생성 ) ===> dictionary 변환
        # DictoXml = xmltodict.unparse(self._xmltodict)
        DictoXml = unparse(self._xmltodict)
        ET.register_namespace("", "http://tempuri.org/GRMProject.xsd")
        xmltree = ET.ElementTree(ET.fromstring(DictoXml))
        root = xmltree.getroot()
        count = self.tblLandCover.rowCount()
        self._LandCoverCount = count

        try:
            for row in range(0, count):
                child = ET.Element("LandCover")
                root.append(child)

                GridValue = ET.Element("GridValue")
                # 특수문자 있음 제외 함
                GridValue.text = self.tblLandCover.item(row, 0).text().replace("﻿", "")
                child.append(GridValue)

                UserLandCover = ET.Element("UserLandCover")
                UserLandCover.text = self.tblLandCover.item(row, 1).text()
                child.append(UserLandCover)

                GRMLandCoverCode = ET.Element("GRMCode")
                GRMLandCoverCode.text = self.tblLandCover.item(row, 2).text()
                child.append(GRMLandCoverCode)

                RoughnessCoefficient = ET.Element("RoughnessCoefficient")
                RoughnessCoefficient.text = self.tblLandCover.item(row, 3).text()
                child.append(RoughnessCoefficient)

                ImperviousRatio = ET.Element("ImperviousRatio")
                ImperviousRatio.text = self.tblLandCover.item(row, 4).text()
                child.append(ImperviousRatio)

                CanopyRatio = ET.Element("CanopyRatio")
                CanopyRatio.text = self.tblLandCover.item(row, 5).text()
                child.append(CanopyRatio)

                InterceptionMaxWaterCanopy_mm = ET.Element(
                    "InterceptionMaxWaterCanopy_mm"
                )
                InterceptionMaxWaterCanopy_mm.text = self.tblLandCover.item(
                    row, 6
                ).text()
                child.append(InterceptionMaxWaterCanopy_mm)

            filepath = tempfile.mktemp()
            xmltree.write(filepath)

            # Dictionary 초기화
            self._xmltodict.clear()

            # 파일 읽어 오기
            Projectfile = open(filepath, "r")
            data = Projectfile.read()
            Projectfile.close()
            # 읽어온 파일 내용(XML)을 dictionary 로 변경
            docs = dict(parse(data))
            self._xmltodict.update(docs)
        except Exception as e:
            pass

    def dataSeve_SoilTexture(self):
        # dictionary 에서 GreenAmptParameter 항목을 모두 제거
        try:
            # dictionary 에서 LandCover 항목을 모두 제거
            check = self._xmltodict["GRMProject"]["GreenAmptParameter"]
            if check is not None:
                del self._xmltodict["GRMProject"]["GreenAmptParameter"]
        except:
            pass

        # dictionary 에서 엘레먼트 생성이 안되서 dic===> XML (element 생성 ) ===> dictionary 변환
        # DictoXml = xmltodict.unparse(self._xmltodict)
        DictoXml = unparse(self._xmltodict)
        ET.register_namespace("", "http://tempuri.org/GRMProject.xsd")
        xmltree = ET.ElementTree(ET.fromstring(DictoXml))
        root = xmltree.getroot()
        count = self.tblGreenAmpt.rowCount()
        self._GreenAmptCount = count
        for row in range(0, count):
            child = ET.Element("GreenAmptParameter")
            root.append(child)

            GridValue = ET.Element("GridValue")
            # 특수문자 있음 제외 함
            GridValue.text = self.tblGreenAmpt.item(row, 0).text().replace("﻿", "")
            child.append(GridValue)

            USERSoil = ET.Element("USERSoil")
            USERSoil.text = self.tblGreenAmpt.item(row, 1).text()
            child.append(USERSoil)

            GRMCode = ET.Element("GRMCode")
            GRMCode.text = self.tblGreenAmpt.item(row, 2).text()
            child.append(GRMCode)

            Porosity = ET.Element("Porosity")
            Porosity.text = self.tblGreenAmpt.item(row, 3).text()
            child.append(Porosity)

            EffectivePorosity = ET.Element("EffectivePorosity")
            EffectivePorosity.text = self.tblGreenAmpt.item(row, 4).text()
            child.append(EffectivePorosity)

            WFSoilSuctionHead = ET.Element("WFSoilSuctionHead")
            WFSoilSuctionHead.text = self.tblGreenAmpt.item(row, 5).text()
            child.append(WFSoilSuctionHead)

            HydraulicConductivity = ET.Element("HydraulicConductivity")
            HydraulicConductivity.text = self.tblGreenAmpt.item(row, 6).text()
            child.append(HydraulicConductivity)

        # xmltree.write("C:\Users\hermesys\Desktop\Sct2.gmp")
        filepath = tempfile.mktemp()
        xmltree.write(filepath)

        # Dictionary 초기화
        self._xmltodict.clear()

        # 파일 읽어 오기
        Projectfile = open(filepath, "r")
        data = Projectfile.read()
        Projectfile.close()
        # 읽어온 파일 내용(XML)을 dictionary 로 변경
        docs = dict(parse(data))
        self._xmltodict.update(docs)

    def dataSeve_SoilDepth(self):
        # dictionary 에서 GreenAmptParameter 항목을 모두 제거
        try:
            check = self._xmltodict["GRMProject"]["SoilDepth"]
            if check is not None:
                del self._xmltodict["GRMProject"]["SoilDepth"]
        except:
            pass

        # dictionary 에서 엘레먼트 생성이 안되서 dic===> XML (element 생성 ) ===> dictionary 변환
        DictoXml = unparse(self._xmltodict)
        ET.register_namespace("", "http://tempuri.org/GRMProject.xsd")
        xmltree = ET.ElementTree(ET.fromstring(DictoXml))
        root = xmltree.getroot()
        count = self.tblSoilDepth.rowCount()
        self._SoilDepthCount = count
        for row in range(0, count):
            child = ET.Element("SoilDepth")
            root.append(child)

            GridValue = ET.Element("GridValue")
            # 특수문자 있음 제외 함
            GridValue.text = self.tblSoilDepth.item(row, 0).text().replace("﻿", "")
            child.append(GridValue)

            UserDepthClass = ET.Element("UserDepthClass")
            UserDepthClass.text = self.tblSoilDepth.item(row, 1).text()
            child.append(UserDepthClass)

            GRMDepthCode = ET.Element("GRMCode")
            GRMDepthCode.text = self.tblSoilDepth.item(row, 2).text()
            child.append(GRMDepthCode)

            SoilDepth = ET.Element("SoilDepth_cm")
            SoilDepth.text = self.tblSoilDepth.item(row, 3).text()
            child.append(SoilDepth)

        # xmltree.write("C:\Users\hermesys\Desktop\Sct2.gmp")
        filepath = tempfile.mktemp()
        xmltree.write(filepath)

        # Dictionary 초기화
        self._xmltodict.clear()

        # 파일 읽어 오기
        Projectfile = open(filepath, "r")
        data = Projectfile.read()
        Projectfile.close()
        # 읽어온 파일 내용(XML)을 dictionary 로 변경
        docs = dict(parse(data))
        self._xmltodict.update(docs)

    def isFloat(self, Snumber):
        try:
            float(Snumber)
            return True
        except ValueError:
            return False


if __name__ == "__main__":
    import os

    from grm.lib.Util import MsTitle

    os.environ[
        "QT_QPA_PLATFORM_PLUGIN_PATH"
    ] = r"C:\Program Files\QGIS 3.10\apps\Qt5\plugins"
    import sys

    from qgis.PyQt.QtWidgets import QApplication

    #MsTitle("ClimateDataDialog")
    MsTitle("Land cover and Soil data dialog")
    app = QApplication(sys.argv)
    ui = LandCoverSoilDialog(
        {
            "GRMProject": {
                "ProjectSettings": {
                    "LandCoverDataType": "File",
                    "SoilTextureDataType": "File",
                    "SoilDepthDataType": "File",
                    "LandCoverVATFile": "",
                    "LandCoverFile": "",
                    "SoilTextureVATFile": "",
                    "SoilDepthVATFile": "",
                    "SoilTextureFile": "",
                    "SoilDepthFile": "",
                    "LAIFile": "",
                    "BlaneyCriddleCoefDataFile": "",
                }
            }
        }
    )
    ui.show()
    sys.exit(app.exec_())
