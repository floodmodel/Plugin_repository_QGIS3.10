<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis styleCategories="AllStyleCategories" labelsEnabled="1" simplifyDrawingHints="1" simplifyAlgorithm="0" minScale="1e+08" simplifyDrawingTol="1" simplifyMaxScale="1" maxScale="0" readOnly="0" version="3.8.3-Zanzibar" hasScaleBasedVisibilityFlag="0" simplifyLocal="1">
  <flags>
    <Identifiable>1</Identifiable>
    <Removable>1</Removable>
    <Searchable>1</Searchable>
  </flags>
  <renderer-v2 symbollevels="0" type="singleSymbol" enableorderby="0" forceraster="0">
    <symbols>
      <symbol force_rhr="0" clip_to_extent="1" type="fill" name="0" alpha="1">
        <layer locked="0" enabled="1" class="SimpleFill" pass="0">
          <prop v="3x:0,0,0,0,0,0" k="border_width_map_unit_scale"/>
          <prop v="225,89,137,0" k="color"/>
          <prop v="bevel" k="joinstyle"/>
          <prop v="0,0" k="offset"/>
          <prop v="3x:0,0,0,0,0,0" k="offset_map_unit_scale"/>
          <prop v="MM" k="offset_unit"/>
          <prop v="35,35,35,0" k="outline_color"/>
          <prop v="solid" k="outline_style"/>
          <prop v="0.26" k="outline_width"/>
          <prop v="MM" k="outline_width_unit"/>
          <prop v="solid" k="style"/>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" type="QString" name="name"/>
              <Option name="properties"/>
              <Option value="collection" type="QString" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </symbols>
    <rotation/>
    <sizescale/>
  </renderer-v2>
  <labeling type="simple">
    <settings>
      <text-style textOpacity="1" fieldName="if (DN>=0,DN,Null) " fontWeight="50" fontUnderline="0" textColor="0,0,0,255" fontLetterSpacing="0" fontItalic="0" useSubstitutions="0" namedStyle="" previewBkgrdColor="#ffffff" fontFamily="Gulim" fontWordSpacing="0" multilineHeight="1" fontSizeMapUnitScale="3x:0,0,0,0,0,0" fontSizeUnit="Point" isExpression="1" blendMode="0" fontSize="10" fontStrikeout="0" fontCapitals="0">
        <text-buffer bufferSize="1" bufferBlendMode="0" bufferDraw="0" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferColor="255,255,255,255" bufferSizeUnits="MM" bufferNoFill="1" bufferOpacity="1" bufferJoinStyle="128"/>
        <background shapeSizeX="0" shapeOpacity="1" shapeRotationType="0" shapeRadiiUnit="MM" shapeBlendMode="0" shapeRadiiX="0" shapeRadiiY="0" shapeFillColor="255,255,255,255" shapeSizeUnit="MM" shapeOffsetX="0" shapeBorderColor="128,128,128,255" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeSizeType="0" shapeRotation="0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeOffsetUnit="MM" shapeDraw="0" shapeJoinStyle="64" shapeBorderWidth="0" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeType="0" shapeSVGFile="" shapeBorderWidthUnit="MM" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeSizeY="0" shapeOffsetY="0"/>
        <shadow shadowRadiusUnit="MM" shadowOpacity="0.7" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowScale="100" shadowDraw="0" shadowOffsetUnit="MM" shadowColor="0,0,0,255" shadowBlendMode="6" shadowUnder="0" shadowRadiusAlphaOnly="0" shadowRadius="1.5" shadowOffsetGlobal="1" shadowOffsetAngle="135" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowOffsetDist="1"/>
        <substitutions/>
      </text-style>
      <text-format useMaxLineLengthForAutoWrap="1" formatNumbers="0" plussign="0" addDirectionSymbol="0" placeDirectionSymbol="0" multilineAlign="0" reverseDirectionSymbol="0" rightDirectionSymbol=">" autoWrapLength="0" decimals="3" wrapChar="" leftDirectionSymbol="&lt;"/>
      <placement fitInPolygonOnly="0" maxCurvedCharAngleIn="25" geometryGeneratorType="PointGeometry" repeatDistance="0" offsetUnits="MM" priority="5" rotationAngle="0" quadOffset="4" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" placementFlags="10" geometryGenerator="" xOffset="0" dist="0" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" centroidInside="0" offsetType="0" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" placement="0" centroidWhole="0" distUnits="MM" preserveRotation="1" distMapUnitScale="3x:0,0,0,0,0,0" maxCurvedCharAngleOut="-25" geometryGeneratorEnabled="0" repeatDistanceUnits="MM" yOffset="0"/>
      <rendering fontLimitPixelSize="0" obstacleType="0" upsidedownLabels="0" scaleMin="0" maxNumLabels="2000" zIndex="0" labelPerPart="0" fontMinPixelSize="3" minFeatureSize="0" scaleVisibility="0" scaleMax="0" limitNumLabels="0" displayAll="0" obstacleFactor="1" mergeLines="0" fontMaxPixelSize="10000" drawLabels="1" obstacle="1"/>
      <dd_properties>
        <Option type="Map">
          <Option value="" type="QString" name="name"/>
          <Option name="properties"/>
          <Option value="collection" type="QString" name="type"/>
        </Option>
      </dd_properties>
    </settings>
  </labeling>
  <customproperties>
    <property key="embeddedWidgets/count" value="0"/>
    <property key="variableNames"/>
    <property key="variableValues"/>
  </customproperties>
  <blendMode>0</blendMode>
  <featureBlendMode>0</featureBlendMode>
  <layerOpacity>1</layerOpacity>
  <SingleCategoryDiagramRenderer attributeLegend="1" diagramType="Histogram">
    <DiagramCategory sizeScale="3x:0,0,0,0,0,0" enabled="0" maxScaleDenominator="1e+08" lineSizeScale="3x:0,0,0,0,0,0" penWidth="0" backgroundColor="#ffffff" barWidth="5" rotationOffset="270" height="15" diagramOrientation="Up" penColor="#000000" sizeType="MM" penAlpha="255" scaleDependency="Area" opacity="1" scaleBasedVisibility="0" backgroundAlpha="255" labelPlacementMethod="XHeight" lineSizeType="MM" minimumSize="0" minScaleDenominator="0" width="15">
      <fontProperties style="" description="Gulim,11.25,-1,5,50,0,0,0,0,0"/>
    </DiagramCategory>
  </SingleCategoryDiagramRenderer>
  <DiagramLayerSettings obstacle="0" linePlacementFlags="18" placement="1" dist="0" zIndex="0" priority="0" showAll="1">
    <properties>
      <Option type="Map">
        <Option value="" type="QString" name="name"/>
        <Option name="properties"/>
        <Option value="collection" type="QString" name="type"/>
      </Option>
    </properties>
  </DiagramLayerSettings>
  <geometryOptions geometryPrecision="0" removeDuplicateNodes="0">
    <activeChecks/>
    <checkConfiguration/>
  </geometryOptions>
  <fieldConfiguration>
    <field name="DN">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
  </fieldConfiguration>
  <aliases>
    <alias index="0" name="" field="DN"/>
  </aliases>
  <excludeAttributesWMS/>
  <excludeAttributesWFS/>
  <defaults>
    <default expression="" applyOnUpdate="0" field="DN"/>
  </defaults>
  <constraints>
    <constraint constraints="0" exp_strength="0" notnull_strength="0" unique_strength="0" field="DN"/>
  </constraints>
  <constraintExpressions>
    <constraint exp="" desc="" field="DN"/>
  </constraintExpressions>
  <expressionfields/>
  <attributeactions>
    <defaultAction key="Canvas" value="{00000000-0000-0000-0000-000000000000}"/>
  </attributeactions>
  <attributetableconfig sortExpression="" sortOrder="0" actionWidgetStyle="dropDown">
    <columns>
      <column type="field" name="DN" hidden="0" width="-1"/>
      <column type="actions" hidden="1" width="-1"/>
    </columns>
  </attributetableconfig>
  <conditionalstyles>
    <rowstyles/>
    <fieldstyles/>
  </conditionalstyles>
  <editform tolerant="1"></editform>
  <editforminit/>
  <editforminitcodesource>0</editforminitcodesource>
  <editforminitfilepath></editforminitfilepath>
  <editforminitcode><![CDATA[# -*- coding: utf-8 -*-
"""
QGIS 양식은 양식이 열릴 때 호출된 파이썬 함수를 보유할 수 있습니다.

이 함수를 사용해서 사용자 양식에 추가 로직을 추가하십시오.

"파이썬 초기 함수" 란에 함수 이름을 입력하십시오.
예제:
"""
from qgis.PyQt.QtWidgets import QWidget

def my_form_open(dialog, layer, feature):
	geom = feature.geometry()
	control = dialog.findChild(QWidget, "MyLineEdit")
]]></editforminitcode>
  <featformsuppress>0</featformsuppress>
  <editorlayout>generatedlayout</editorlayout>
  <editable>
    <field name="DN" editable="1"/>
  </editable>
  <labelOnTop>
    <field labelOnTop="0" name="DN"/>
  </labelOnTop>
  <widgets/>
  <previewExpression>DN</previewExpression>
  <mapTip></mapTip>
  <layerGeometryType>2</layerGeometryType>
</qgis>
