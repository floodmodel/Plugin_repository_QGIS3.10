@echo off
call "C:\Program Files\QGIS 3.16\bin\o4w_env.bat"
call "C:\Program Files\QGIS 3.16\bin\qt5_env.bat"
call "C:\Program Files\QGIS 3.16\bin\py3_env.bat"

@echo on
pyuic5 AddFlowControl_dialog_base.ui > AddFlowControl_dialog_base.py