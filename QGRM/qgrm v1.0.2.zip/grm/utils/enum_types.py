from enum import Enum

EnumInterceptionMethod = Enum("EnumInterceptionMethod", {"LAIRatio": 1, "None": 10})
EnumPETMethod = Enum(
    "EnumPETMethod",
    {"BlaneyCriddle": 2, "Hamon": 3, "PriestleyTaylor": 4, "Hargreaves": 5, "None": 10},
)
EnumSnowMeltMethod = Enum("EnumSnowMeltMethod", {"Anderson": 1, "None": 10})
