# -*- coding: utf-8 -*-

import xml.etree.ElementTree as ET

from grm.lib.Util import indent

# from .lib.File_Class import *
# from .lib.Util import *


class xmls:
    def __init__(self):
        self.ProjectFile = ""

    def CheckGMP_SaveXML(self, filepath):
        self.ProjectFile = filepath
        # xml 요소 값을 배열에 넣음
        self.Set_XML_element_ProjectSettings()
        self.Set_XML_element_WatchPoints()
        self.Set_XML_element_SubWatershedSettings()
        self.Set_XML_element_ChannelSettings()
        self.Set_XML_element_FlowControlGrid()
        self.Set_XML_element_GreenAmptParameter()
        self.Set_XML_element_SoilDepth()
        self.Set_XML_element_LandCover()

        # xml 파싱
        doc = ET.parse(self.ProjectFile)
        root = doc.getroot()
        GRMProject = ET.Element("GRMProject")
        GRMProject.set("xmlns", "http://tempuri.org/GRMProject.xsd")

        # 아래의 테이블 순서에 따라서 xml 파일 기록 순서 결정됨
        rootValue = root.findall("{http://tempuri.org/GRMProject.xsd}ProjectSettings")
        for element in rootValue:
            ProjectSettings = ET.SubElement(GRMProject, "ProjectSettings")
            flag_WatershedFile = True
            for i in range(0, len(self.XML_eleProjectSettings)):
                Datavalue = element.findtext(
                    "{http://tempuri.org/GRMProject.xsd}" + self.XML_eleProjectSettings[i]
                )
                if self.XML_eleProjectSettings[i] == "GRMSimulationType" and (
                    Datavalue == "" or Datavalue is None
                ):
                    Datavalue = "Normal"
                if self.XML_eleProjectSettings[i] == "LandCoverDataType" and (
                    Datavalue == "" or Datavalue is None
                ):
                    Datavalue = "File"
                if self.XML_eleProjectSettings[i] == "SoilTextureDataType" and (
                    Datavalue == "" or Datavalue is None
                ):
                    Datavalue = "File"
                if self.XML_eleProjectSettings[i] == "SoilDepthDataType" and (
                    Datavalue == "" or Datavalue is None
                ):
                    Datavalue = "File"
                if self.XML_eleProjectSettings[i] == "FlowDirectionType" and (
                    Datavalue == "" or Datavalue is None
                ):
                    Datavalue = "StartsFromE_TauDEM"
                if self.XML_eleProjectSettings[i] == "MaxDegreeOfParallelism" and (
                    Datavalue == "" or Datavalue is None
                ):
                    Datavalue = "-1"
                if self.XML_eleProjectSettings[i] == "SimulationStartingTime" and (
                    Datavalue == "" or Datavalue is None
                ):
                    Datavalue = "0"
                if self.XML_eleProjectSettings[i] == "IsFixedTimeStep" and (
                    Datavalue == "" or Datavalue is None
                ):
                    Datavalue = "false"
                if self.XML_eleProjectSettings[i] == "'SimulateInfiltration'" and (
                    Datavalue == "" or Datavalue is None
                ):
                    Datavalue = "true"
                if self.XML_eleProjectSettings[i] == "SimulateSubsurfaceFlow" and (
                    Datavalue == "" or Datavalue is None
                ):
                    Datavalue = "true"
                if self.XML_eleProjectSettings[i] == "SimulateBaseFlow" and (
                    Datavalue == "" or Datavalue is None
                ):
                    Datavalue = "true"
                if self.XML_eleProjectSettings[i] == "SimulateInterception" and (
                    Datavalue == "" or Datavalue is None
                ):
                    Datavalue = "true"
                if self.XML_eleProjectSettings[i] == "SimulateEvapotranspiration" and (
                    Datavalue == "" or Datavalue is None
                ):
                    Datavalue = "true"
                if self.XML_eleProjectSettings[i] == "SimulateSnowMelt" and (
                    Datavalue == "" or Datavalue is None
                ):
                    Datavalue = "true"
                if self.XML_eleProjectSettings[i] == "SimulateFlowControl" and (
                    Datavalue == "" or Datavalue is None
                ):
                    Datavalue = "true"

                if self.XML_eleProjectSettings[i] == "MakeIMGFile" and (
                    Datavalue == "" or Datavalue is None
                ):
                    Datavalue = "false"
                if self.XML_eleProjectSettings[i] == "MakeASCFile" and (
                    Datavalue == "" or Datavalue is None
                ):
                    Datavalue = "false"
                if self.XML_eleProjectSettings[i] == "MakeSoilSaturationDistFile" and (
                    Datavalue == "" or Datavalue is None
                ):
                    Datavalue = "true"
                if self.XML_eleProjectSettings[i] == "MakeRfDistFile" and (
                    Datavalue == "" or Datavalue is None
                ):
                    Datavalue = "true"
                if self.XML_eleProjectSettings[i] == "MakeRFaccDistFile" and (
                    Datavalue == "" or Datavalue is None
                ):
                    Datavalue = "true"
                if self.XML_eleProjectSettings[i] == "MakeFlowDistFile" and (
                    Datavalue == "" or Datavalue is None
                ):
                    Datavalue = "true"
                if self.XML_eleProjectSettings[i] == "PrintOption" and (
                    Datavalue == "" or Datavalue is None
                ):
                    Datavalue = "All"
                if self.XML_eleProjectSettings[i] == "PrintAveValue" and (
                    Datavalue == "" or Datavalue is None
                ):
                    Datavalue = "false"
                if self.XML_eleProjectSettings[i] == "ValueSeparator" and (
                    Datavalue == "" or Datavalue is None
                ):
                    Datavalue = "Tab"

                if self.XML_eleProjectSettings[i] == "WriteLog" and (
                    Datavalue == "" or Datavalue is None
                ):
                    Datavalue = "false"


                ET.SubElement(
                    ProjectSettings, self.XML_eleProjectSettings[i]
                ).text = Datavalue

        self._WatchPointCount = 0
        for element in root.findall("{http://tempuri.org/GRMProject.xsd}WatchPoints"):
            WatchPoints = ET.SubElement(GRMProject, "WatchPoints")
            for i in range(0, len(self.XML_eleWatchPoints)):
                Datavalue = element.findtext(
                    "{http://tempuri.org/GRMProject.xsd}"
                    + self.XML_eleWatchPoints[i]
                )
                if self.XML_eleWatchPoints[i] == "Name" and (
                    Datavalue == "" or Datavalue is None
                ):
                    Datavalue = ""
                if self.XML_eleWatchPoints[i] == "ColX" and (
                    Datavalue == "" or Datavalue is None
                ):
                    Datavalue = ""
                if self.XML_eleWatchPoints[i] == "RowY" and (
                    Datavalue == "" or Datavalue is None
                ):
                    Datavalue = ""
                ET.SubElement(
                    WatchPoints, self.XML_eleWatchPoints[i]
                ).text = Datavalue
            self._WatchPointCount = self._WatchPointCount + 1


        self._SubWatershedCount = 0
        for element in root.findall(
            "{http://tempuri.org/GRMProject.xsd}SubWatershedSettings"
        ):
            SubWatershedSettings = ET.SubElement(GRMProject, "SubWatershedSettings")
            for i in range(0, len(self.XML_eleSubWatershedSettings)):
                Datavalue = element.findtext(
                    "{http://tempuri.org/GRMProject.xsd}"
                    + self.XML_eleSubWatershedSettings[i]
                )
                if self.XML_eleSubWatershedSettings[i] == "IniSaturation" and (
                    Datavalue == "" or Datavalue is None
                ):
                    Datavalue = "0.9"
                elif self.XML_eleSubWatershedSettings[i] == "IniLossPRCP_mm" and (
                    Datavalue == "" or Datavalue is None
                ):
                    Datavalue = "0.0"                    
                elif self.XML_eleSubWatershedSettings[i] == "MinSlopeOF" and (
                    Datavalue == "" or Datavalue is None
                ):
                    Datavalue = "0.0001"
                elif self.XML_eleSubWatershedSettings[i] == "MinSlopeChBed" and (
                    Datavalue == "" or Datavalue is None
                ):
                    Datavalue = "0.0001"
                elif self.XML_eleSubWatershedSettings[i] == "MinChBaseWidth" and (
                    Datavalue == "" or Datavalue is None
                ):
                    Datavalue = "00"
                elif self.XML_eleSubWatershedSettings[i] == "ChRoughness" and (
                    Datavalue == "" or Datavalue is None
                ):
                    Datavalue = "0.045"
                elif self.XML_eleSubWatershedSettings[i] == "DryStreamOrder" and (
                    Datavalue == "" or Datavalue is None
                ):
                    Datavalue = "0"
                elif self.XML_eleSubWatershedSettings[i] == "IniFlow" and (
                    Datavalue == "" or Datavalue is None
                ):
                    Datavalue = "0"
                elif self.XML_eleSubWatershedSettings[i] == "UnsaturatedKType" and (
                    Datavalue == "" or Datavalue is None
                ):
                    Datavalue = "Linear"
                elif self.XML_eleSubWatershedSettings[i] == "CoefUnsaturatedK" and (
                    Datavalue == "" or Datavalue is None
                ):
                    Datavalue = "0.2"
                elif self.XML_eleSubWatershedSettings[i] == "CalCoefLCRoughness" and (
                    Datavalue == "" or Datavalue is None
                ):
                    Datavalue = "1"
                elif self.XML_eleSubWatershedSettings[i] == "CalCoefPorosity" and (
                    Datavalue == "" or Datavalue is None
                ):
                    Datavalue = "1"
                elif self.XML_eleSubWatershedSettings[i] == "CalCoefWFSuctionHead" and (
                    Datavalue == "" or Datavalue is None
                ):
                    Datavalue = "1"
                elif self.XML_eleSubWatershedSettings[i] == "CalCoefHydraulicK" and (
                    Datavalue == "" or Datavalue is None
                ):
                    Datavalue = "1"
                elif self.XML_eleSubWatershedSettings[i] == "CalCoefSoilDepth" and (
                    Datavalue == "" or Datavalue is None
                ):
                    Datavalue = "1"
                elif self.XML_eleSubWatershedSettings[i] == "InterceptionMethod" and (
                    Datavalue == "" or Datavalue is None
                ):
                    Datavalue = "None"
                elif self.XML_eleSubWatershedSettings[i] == "PETMethod" and (
                    Datavalue == "" or Datavalue is None
                ):
                    Datavalue = "None"
                elif self.XML_eleSubWatershedSettings[i] == "ETCoef" and (
                    Datavalue == "" or Datavalue is None
                ):
                    Datavalue = "0.6"
                elif self.XML_eleSubWatershedSettings[i] == "SnowmeltMethod" and (
                    Datavalue == "" or Datavalue is None
                ):
                    Datavalue = "None"
                elif self.XML_eleSubWatershedSettings[i] == "TempSnowRain" and (
                    Datavalue == "" or Datavalue is None
                ):
                    Datavalue = "0"
                elif self.XML_eleSubWatershedSettings[i] == "SnowmeltingTemp" and (
                    Datavalue == "" or Datavalue is None
                ):
                    Datavalue = "4"
                elif self.XML_eleSubWatershedSettings[i] == "SnowCovRatio" and (
                    Datavalue == "" or Datavalue is None
                ):
                    Datavalue = "0.7"
                elif self.XML_eleSubWatershedSettings[i] == "SnowmeltCoef" and (
                    Datavalue == "" or Datavalue is None
                ):
                    Datavalue = "1"
                if self.XML_eleSubWatershedSettings[i] == "UserSet" and (
                    Datavalue == "" or Datavalue is None
                ):
                    Datavalue = "false"
                ET.SubElement(
                    SubWatershedSettings, self.XML_eleSubWatershedSettings[i]
                ).text = Datavalue
            self._SubWatershedCount = self._SubWatershedCount + 1


        self._ChannelSettingsCount = 0
        # 2020-06-03 박: 오래된 GMP 파일이면 분리해서 새로 생성 함
        Channel_Count = len(
            root.findall("{http://tempuri.org/GRMProject.xsd}ChannelSettings")
        )
        if Channel_Count > 0:
            for element in root.findall(
                "{http://tempuri.org/GRMProject.xsd}ChannelSettings"
            ):
                ChannelSettings = ET.SubElement(GRMProject, "ChannelSettings")
                for i in range(0, len(self.XML_eleChannelSettings)):
                    Datavalue = element.findtext(
                        "{http://tempuri.org/GRMProject.xsd}"
                        + self.XML_eleChannelSettings[i]
                    )
                    if self.XML_eleChannelSettings[i] == "WSID" and (
                        Datavalue == "" or Datavalue is None
                    ):
                        Datavalue = ""
                    if self.XML_eleChannelSettings[i] == "CrossSectionType" and (
                        Datavalue == "" or Datavalue is None
                    ):
                        Datavalue = "CSSingle"
                    if self.XML_eleChannelSettings[
                        i
                    ] == "SingleCSChannelWidthType" and (
                        Datavalue == "" or Datavalue is None
                    ):
                        Datavalue = "CWGeneration"
                    if self.XML_eleChannelSettings[i] == "ChannelWidthEQc" and (
                        Datavalue == "" or Datavalue is None
                    ):
                        Datavalue = "1.698"
                    if self.XML_eleChannelSettings[i] == "ChannelWidthEQd" and (
                        Datavalue == "" or Datavalue is None
                    ):
                        Datavalue = "0.318"
                    if self.XML_eleChannelSettings[i] == "ChannelWidthEQe" and (
                        Datavalue == "" or Datavalue is None
                    ):
                        Datavalue = "0.5"
                    if self.XML_eleChannelSettings[
                        i
                    ] == "ChannelWidthMostDownStream" and (
                        Datavalue == "" or Datavalue is None
                    ):
                        Datavalue = "400"
                    if self.XML_eleChannelSettings[i] == "LowerRegionHeight" and (
                        Datavalue == "" or Datavalue is None
                    ):
                        Datavalue = "0"
                    if self.XML_eleChannelSettings[
                        i
                    ] == "LowerRegionBaseWidth" and (
                        Datavalue == "" or Datavalue is None
                    ):
                        Datavalue = "0"
                    if self.XML_eleChannelSettings[
                        i
                    ] == "UpperRegionBaseWidth" and (
                        Datavalue == "" or Datavalue is None
                    ):
                        Datavalue = "0"
                    if self.XML_eleChannelSettings[
                        i
                    ] == "CompoundCSChannelWidthLimit" and (
                        Datavalue == "" or Datavalue is None
                    ):
                        Datavalue = "0"
                    if self.XML_eleChannelSettings[i] == "BankSideSlopeRight" and (
                        Datavalue == "" or Datavalue is None
                    ):
                        Datavalue = "1.5"
                    if self.XML_eleChannelSettings[i] == "BankSideSlopeLeft" and (
                        Datavalue == "" or Datavalue is None
                    ):
                        Datavalue = "1.5"
                    ET.SubElement(
                        ChannelSettings, self.XML_eleChannelSettings[i]
                    ).text = Datavalue
                self._ChannelSettingsCount = self._ChannelSettingsCount + 1


        self._FlowControlCount = 0
        for element in root.findall(
            "{http://tempuri.org/GRMProject.xsd}FlowControlGrid"
        ):
            FlowControlGrid = ET.SubElement(GRMProject, "FlowControlGrid")
            for i in range(0, len(self.XML_eleFlowControlGrid)):
                Datavalue = element.findtext(
                    "{http://tempuri.org/GRMProject.xsd}"
                    + self.XML_eleFlowControlGrid[i]
                )
                if self.XML_eleFlowControlGrid[i] == "ColX" and (
                    Datavalue == "" or Datavalue is None
                ):
                    Datavalue = ""
                if self.XML_eleFlowControlGrid[i] == "RowY" and (
                    Datavalue == "" or Datavalue is None
                ):
                    Datavalue = ""
                if self.XML_eleFlowControlGrid[i] == "Name" and (
                    Datavalue == "" or Datavalue is None
                ):
                    Datavalue = ""
                if self.XML_eleFlowControlGrid[i] == "ControlType" and (
                    Datavalue == "" or Datavalue is None
                ):
                    Datavalue = ""
                if self.XML_eleFlowControlGrid[i] == "FlowDataFile" and (
                    Datavalue == "" or Datavalue is None
                ):
                    Datavalue = ""
                if self.XML_eleFlowControlGrid[i] == "DT_min" and (
                    Datavalue == "" or Datavalue is None
                ):
                    Datavalue = ""
                if self.XML_eleFlowControlGrid[i] == "IniStorage" and (
                    Datavalue == "" or Datavalue is None
                ):
                    Datavalue = ""
                if self.XML_eleFlowControlGrid[i] == "MaxStorage" and (
                    Datavalue == "" or Datavalue is None
                ):
                    Datavalue = "0"
                if self.XML_eleFlowControlGrid[i] == "NormalHighStorage" and (
                    Datavalue == "" or Datavalue is None
                ):
                    Datavalue = "0"
                if self.XML_eleFlowControlGrid[i] == "RestrictedStorage" and (
                    Datavalue == "" or Datavalue is None
                ):
                    Datavalue = "0"
                if self.XML_eleFlowControlGrid[i] == "RestrictedPeriod_Start" and (
                    Datavalue == "" or Datavalue is None
                ):
                    Datavalue = "0"
                if self.XML_eleFlowControlGrid[i] == "RestrictedPeriod_End" and (
                    Datavalue == "" or Datavalue is None
                ):
                    Datavalue = "0"
                if self.XML_eleFlowControlGrid[i] == "ROType" and (
                    Datavalue == "" or Datavalue is None
                ):
                    Datavalue = ""
                if self.XML_eleFlowControlGrid[i] == "AutoROMmaxOutflow_CMS" and (
                    Datavalue == "" or Datavalue is None
                ):
                    Datavalue = ""
                if self.XML_eleFlowControlGrid[i] == "ROConstRatio" and (
                    Datavalue == "" or Datavalue is None
                ):
                    Datavalue = ""
                if self.XML_eleFlowControlGrid[i] == "ROConstDischarge" and (
                    Datavalue == "" or Datavalue is None
                ):
                    Datavalue = ""
                if self.XML_eleFlowControlGrid[i] == "ROConstDischargeDuration_hr" and (
                    Datavalue == "" or Datavalue is None
                ):
                    Datavalue = ""

                if self.XML_eleFlowControlGrid[i] == "DP_QT_StoD_CMS" and (
                    Datavalue == "" or Datavalue is None
                ):
                    Datavalue = ""
                if self.XML_eleFlowControlGrid[i] == "DP_Qi_max_CMS" and (
                    Datavalue == "" or Datavalue is None
                ):
                    Datavalue = ""
                if self.XML_eleFlowControlGrid[i] == "DP_Qo_max_CMS" and (
                    Datavalue == "" or Datavalue is None
                ):
                    Datavalue = ""
                if self.XML_eleFlowControlGrid[i] == "DP_Wdi_m" and (
                    Datavalue == "" or Datavalue is None
                ):
                    Datavalue = ""
                if self.XML_eleFlowControlGrid[i] == "DP_Ws_m" and (
                    Datavalue == "" or Datavalue is None
                ):
                    Datavalue = ""
                if self.XML_eleFlowControlGrid[i] == "DP_Cr_StoD" and (
                    Datavalue == "" or Datavalue is None
                ):
                    Datavalue = ""

                ET.SubElement(
                    FlowControlGrid, self.XML_eleFlowControlGrid[i]
                ).text = Datavalue
            self._FlowControlCount = self._FlowControlCount + 1


        self._LandCoverCount = 0
        rootValue = root.findall("{http://tempuri.org/GRMProject.xsd}LandCover")
        for element in rootValue:
            LandCover = ET.SubElement(GRMProject, "LandCover")
            for i in range(0, len(self.XML_eleLandCover)):
                Datavalue = element.findtext(
                    "{http://tempuri.org/GRMProject.xsd}"
                    + self.XML_eleLandCover[i]
                )
                if self.XML_eleLandCover[i] == "GridValue" and (
                    Datavalue == "" or Datavalue is None
                ):
                    Datavalue = ""

                if self.XML_eleLandCover[i] == "UserLandCover" and (
                    Datavalue == "" or Datavalue is None
                ):
                    Datavalue = ""

                if self.XML_eleLandCover[i] == "GRMCode" and (
                    Datavalue == "" or Datavalue is None
                ):
                    Datavalue = ""

                # if self.XML_element_LandCover[i] == "GRMLandCoverE" :
                #    rootValue.remove(element)
                # if self.XML_element_LandCover[i] == "GRMLandCoverK":
                #    rootValue.remove(element)

                if self.XML_eleLandCover[i] == "RoughnessCoefficient" and (
                    Datavalue == "" or Datavalue is None
                ):
                    Datavalue = ""

                if self.XML_eleLandCover[i] == "ImperviousRatio" and (
                    Datavalue == "" or Datavalue is None
                ):
                    Datavalue = ""

                if self.XML_eleLandCover[i] == "CanopyRatio" and (
                    Datavalue == "" or Datavalue is None
                ):
                    Datavalue = ""

                if self.XML_eleLandCover[
                    i
                ] == "InterceptionMaxWaterCanopy_mm" and (
                    Datavalue == "" or Datavalue is None
                ):
                    Datavalue = ""

                ET.SubElement(LandCover, self.XML_eleLandCover[i]).text = Datavalue
            self._LandCoverCount = self._LandCoverCount + 1


        self._GreenAmptCount = 0
        rootValue = root.findall(
            "{http://tempuri.org/GRMProject.xsd}GreenAmptParameter"
        )
        for element in rootValue:
            GreenAmptParameter = ET.SubElement(GRMProject, "GreenAmptParameter")
            for i in range(0, len(self.XML_eleGreenAmptParameter)):
                Datavalue = element.findtext(
                    "{http://tempuri.org/GRMProject.xsd}"
                    + self.XML_eleGreenAmptParameter[i]
                )
                if self.XML_eleGreenAmptParameter[i] == "GridValue" and (
                    Datavalue == "" or Datavalue is None
                ):
                    Datavalue = ""

                if self.XML_eleGreenAmptParameter[i] == "USERSoil" and (
                    Datavalue == "" or Datavalue is None
                ):
                    Datavalue = ""

                if self.XML_eleGreenAmptParameter[i] == "GRMCode" and (
                    Datavalue == "" or Datavalue is None
                ):
                    Datavalue = ""

                if self.XML_eleGreenAmptParameter[i] == "Porosity" and (
                    Datavalue == "" or Datavalue is None
                ):
                    Datavalue = ""

                if self.XML_eleGreenAmptParameter[i] == "EffectivePorosity" and (
                    Datavalue == "" or Datavalue is None
                ):
                    Datavalue = ""

                if self.XML_eleGreenAmptParameter[i] == "WFSoilSuctionHead" and (
                    Datavalue == "" or Datavalue is None
                ):
                    Datavalue = ""

                if self.XML_eleGreenAmptParameter[
                    i
                ] == "HydraulicConductivity" and (Datavalue == "" or Datavalue is None):
                    Datavalue = ""

                ET.SubElement(
                    GreenAmptParameter, self.XML_eleGreenAmptParameter[i]
                ).text = Datavalue
            self._GreenAmptCount = self._GreenAmptCount + 1

        self._SoilDepthCount = 0
        rootValue = root.findall("{http://tempuri.org/GRMProject.xsd}SoilDepth")

        for element in rootValue:
            SoilDepth = ET.SubElement(GRMProject, "SoilDepth")
            for i in range(0, len(self.XML_eleSoilDepth)):
                Datavalue = element.findtext(
                    "{http://tempuri.org/GRMProject.xsd}"
                    + self.XML_eleSoilDepth[i]
                )
                if self.XML_eleSoilDepth[i] == "GridValue" and (
                    Datavalue == "" or Datavalue is None
                ):
                    Datavalue = ""

                if self.XML_eleSoilDepth[i] == "UserDepthClass" and (
                    Datavalue == "" or Datavalue is None
                ):
                    Datavalue = ""

                if self.XML_eleSoilDepth[i] == "GRMCode" and (
                    Datavalue == "" or Datavalue is None
                ):
                    Datavalue = ""

                if self.XML_eleSoilDepth[i] == "SoilDepth":
                    if Datavalue != "" and Datavalue is not None:
                        ET.SubElement(SoilDepth, "SoilDepth_cm").text = Datavalue
                        flag_soildepth = False
                    else:
                        flag_soildepth = True

                elif self.XML_eleSoilDepth[i] == "SoilDepth_cm":
                    if flag_soildepth:
                        ET.SubElement(
                            SoilDepth, self.XML_eleSoilDepth[i]
                        ).text = Datavalue
                else:
                    ET.SubElement(
                        SoilDepth, self.XML_eleSoilDepth[i]
                    ).text = Datavalue

            self._SoilDepthCount = self._SoilDepthCount + 1

        root = ET.ElementTree(GRMProject).getroot()
        indent(root)
        # 여기서 gmp 파일을 QGRM 표준 양식으로 저장한다.
        ET.ElementTree(GRMProject).write(
            self.ProjectFile, encoding="utf-8", xml_declaration=True
        )

    #     def indent(self,Pro_path):
    #         arg=GetScriptDirectory_Path()+ "/ReWriteXML/ReadAndWriteXML.exe " + Pro_path
    #         callExecute(arg)

    def Set_XML_element_ProjectSettings(self):
        self.XML_eleProjectSettings = []

        self.XML_eleProjectSettings.append("GRMSimulationType")
        #self.XML_element.append("WatershedFile")
        self.XML_eleProjectSettings.append("DomainFile")
        self.XML_eleProjectSettings.append("SlopeFile")
        self.XML_eleProjectSettings.append("FlowDirectionFile")
        self.XML_eleProjectSettings.append("FlowAccumFile")
        self.XML_eleProjectSettings.append("StreamFile")
        self.XML_eleProjectSettings.append("ChannelWidthFile")
        self.XML_eleProjectSettings.append("InitialSoilSaturationRatioFile")
        self.XML_eleProjectSettings.append("LandCoverDataType")
        self.XML_eleProjectSettings.append("LandCoverFile")
        self.XML_eleProjectSettings.append("LandCoverVATFile")
        self.XML_eleProjectSettings.append("ConstantRoughnessCoeff")
        self.XML_eleProjectSettings.append("ConstantImperviousRatio")
        self.XML_eleProjectSettings.append("LAIFile")
        self.XML_eleProjectSettings.append("BlaneyCriddleCoefDataFile")
        self.XML_eleProjectSettings.append("SoilTextureDataType")
        self.XML_eleProjectSettings.append("SoilTextureFile")
        self.XML_eleProjectSettings.append("SoilTextureVATFile")
        self.XML_eleProjectSettings.append("ConstantSoilPorosity")
        self.XML_eleProjectSettings.append("ConstantSoilEffPorosity")
        self.XML_eleProjectSettings.append("ConstantSoilWettingFrontSuctionHead")
        self.XML_eleProjectSettings.append("ConstantSoilHydraulicConductivity")
        self.XML_eleProjectSettings.append("SoilDepthDataType")
        self.XML_eleProjectSettings.append("SoilDepthFile")
        self.XML_eleProjectSettings.append("SoilDepthVATFile")
        self.XML_eleProjectSettings.append("ConstantSoilDepth")
        self.XML_eleProjectSettings.append("InitialChannelFlowFile")
        self.XML_eleProjectSettings.append("PrecipitationDataFile")
        self.XML_eleProjectSettings.append("PrecipitationInterval_min")
        self.XML_eleProjectSettings.append("TemperatureMaxDataFile")
        self.XML_eleProjectSettings.append("TemperatureMaxInterval_min")
        self.XML_eleProjectSettings.append("TemperatureMinDataFile")
        self.XML_eleProjectSettings.append("TemperatureMinInterval_min")
        self.XML_eleProjectSettings.append("DaytimeLengthDataFile")
        self.XML_eleProjectSettings.append("DaytimeLengthInterval_min")
        self.XML_eleProjectSettings.append("DaytimeHoursRatioDataFile")
        self.XML_eleProjectSettings.append("SolarRadiationDataFile")
        self.XML_eleProjectSettings.append("SolarRadiationInterval_min")
        self.XML_eleProjectSettings.append("SnowPackTemperatureDataFile")
        self.XML_eleProjectSettings.append("SnowPackTemperatureInterval_min")
        self.XML_eleProjectSettings.append("FlowDirectionType")
        #         self.XML_element.append('IsParallel')
        self.XML_eleProjectSettings.append("MaxDegreeOfParallelism")
        self.XML_eleProjectSettings.append("SimulationStartingTime")
        self.XML_eleProjectSettings.append("ComputationalTimeStep_min")
        self.XML_eleProjectSettings.append("IsFixedTimeStep")
        self.XML_eleProjectSettings.append("SimulationDuration_hr")
        self.XML_eleProjectSettings.append("OutputTimeStep_min")
        self.XML_eleProjectSettings.append("SimulateInfiltration")
        self.XML_eleProjectSettings.append("SimulateSubsurfaceFlow")
        self.XML_eleProjectSettings.append("SimulateBaseFlow")
        self.XML_eleProjectSettings.append("SimulateInterception")
        self.XML_eleProjectSettings.append("SimulateEvapotranspiration")
        self.XML_eleProjectSettings.append("SimulateSnowMelt")
        self.XML_eleProjectSettings.append("SimulateFlowControl")
        self.XML_eleProjectSettings.append("MakeIMGFile")
        self.XML_eleProjectSettings.append("MakeASCFile")
        self.XML_eleProjectSettings.append("MakeSoilSaturationDistFile")
        self.XML_eleProjectSettings.append("MakeRfDistFile")
        self.XML_eleProjectSettings.append("MakeRFaccDistFile")
        self.XML_eleProjectSettings.append("MakeFlowDistFile")
        self.XML_eleProjectSettings.append("PrintOption")
        self.XML_eleProjectSettings.append("PrintAveValue")
        self.XML_eleProjectSettings.append("AveValueTimeInterval_min")
        self.XML_eleProjectSettings.append("ValueSeparator")
        self.XML_eleProjectSettings.append("WriteLog")
        self.XML_eleProjectSettings.append("AboutThisProject")
        self.XML_eleProjectSettings.append("AboutWatershed")
        self.XML_eleProjectSettings.append("AboutLandCoverMap")
        self.XML_eleProjectSettings.append("AboutSoilMap")
        self.XML_eleProjectSettings.append("AboutSoilDepthMap")
        self.XML_eleProjectSettings.append("AboutRainfall")
        # self.XML_element.append('ProjectSavedTime')
        # self.XML_element.append('ComputerName')
        # self.XML_element.append('ComputerUserName')
        # self.XML_element.append('GRMVersion')

    def Set_XML_element_SubWatershedSettings(self):
        self.XML_eleSubWatershedSettings = []
        self.XML_eleSubWatershedSettings.append("ID")
        self.XML_eleSubWatershedSettings.append("IniSaturation")
        self.XML_eleSubWatershedSettings.append("IniLossPRCP_mm")
        self.XML_eleSubWatershedSettings.append("MinSlopeOF")
        self.XML_eleSubWatershedSettings.append("MinSlopeChBed")
        self.XML_eleSubWatershedSettings.append("MinChBaseWidth")
        self.XML_eleSubWatershedSettings.append("ChRoughness")
        self.XML_eleSubWatershedSettings.append("DryStreamOrder")
        self.XML_eleSubWatershedSettings.append("IniFlow")
        self.XML_eleSubWatershedSettings.append("UnsaturatedKType")
        self.XML_eleSubWatershedSettings.append("CoefUnsaturatedK")
        self.XML_eleSubWatershedSettings.append("CalCoefLCRoughness")
        self.XML_eleSubWatershedSettings.append("CalCoefPorosity")
        self.XML_eleSubWatershedSettings.append("CalCoefWFSuctionHead")
        self.XML_eleSubWatershedSettings.append("CalCoefHydraulicK")
        self.XML_eleSubWatershedSettings.append("CalCoefSoilDepth")
        self.XML_eleSubWatershedSettings.append("InterceptionMethod")
        self.XML_eleSubWatershedSettings.append("PETMethod")
        self.XML_eleSubWatershedSettings.append("ETCoef")
        self.XML_eleSubWatershedSettings.append("SnowmeltMethod")
        self.XML_eleSubWatershedSettings.append("TempSnowRain")
        self.XML_eleSubWatershedSettings.append("SnowmeltingTemp")
        self.XML_eleSubWatershedSettings.append("SnowCovRatio")
        self.XML_eleSubWatershedSettings.append("SnowmeltCoef")
        self.XML_eleSubWatershedSettings.append("UserSet")

    def Set_XML_element_ChannelSettings(self):
        self.XML_eleChannelSettings = []
        self.XML_eleChannelSettings.append("WSID")
        self.XML_eleChannelSettings.append("CrossSectionType")
        self.XML_eleChannelSettings.append("SingleCSChannelWidthType")
        self.XML_eleChannelSettings.append("ChannelWidthEQc")
        self.XML_eleChannelSettings.append("ChannelWidthEQd")
        self.XML_eleChannelSettings.append("ChannelWidthEQe")
        self.XML_eleChannelSettings.append("ChannelWidthMostDownStream")
        self.XML_eleChannelSettings.append("LowerRegionHeight")
        self.XML_eleChannelSettings.append("LowerRegionBaseWidth")
        self.XML_eleChannelSettings.append("UpperRegionBaseWidth")
        self.XML_eleChannelSettings.append("CompoundCSChannelWidthLimit")
        self.XML_eleChannelSettings.append("BankSideSlopeRight")
        self.XML_eleChannelSettings.append("BankSideSlopeLeft")

    def Set_XML_element_FlowControlGrid(self):
        self.XML_eleFlowControlGrid = []
        self.XML_eleFlowControlGrid.append("ColX")
        self.XML_eleFlowControlGrid.append("RowY")
        self.XML_eleFlowControlGrid.append("Name")
        self.XML_eleFlowControlGrid.append("ControlType")
        self.XML_eleFlowControlGrid.append("FlowDataFile")
        self.XML_eleFlowControlGrid.append("DT_min")
        self.XML_eleFlowControlGrid.append("IniStorage")
        self.XML_eleFlowControlGrid.append("MaxStorage")
        self.XML_eleFlowControlGrid.append("NormalHighStorage")
        self.XML_eleFlowControlGrid.append("RestrictedStorage")
        self.XML_eleFlowControlGrid.append("RestrictedPeriod_Start")
        self.XML_eleFlowControlGrid.append("RestrictedPeriod_End")
        #         self.XML_element_FlowControlGrid.append('MaxStorageR')
        self.XML_eleFlowControlGrid.append("ROType")
        self.XML_eleFlowControlGrid.append("AutoROMmaxOutflow_CMS")
        self.XML_eleFlowControlGrid.append("ROConstRatio")
        self.XML_eleFlowControlGrid.append("ROConstDischarge")
        self.XML_eleFlowControlGrid.append("ROConstDischargeDuration_hr")
        self.XML_eleFlowControlGrid.append("DP_QT_StoD_CMS")
        self.XML_eleFlowControlGrid.append("DP_Qi_max_CMS")
        self.XML_eleFlowControlGrid.append("DP_Qo_max_CMS")
        self.XML_eleFlowControlGrid.append("DP_Wdi_m")
        self.XML_eleFlowControlGrid.append("DP_Ws_m")
        self.XML_eleFlowControlGrid.append("DP_Cr_StoD")

    def Set_XML_element_WatchPoints(self):
        self.XML_eleWatchPoints = []
        self.XML_eleWatchPoints.append("Name")
        self.XML_eleWatchPoints.append("ColX")
        self.XML_eleWatchPoints.append("RowY")

    def Set_XML_element_GreenAmptParameter(self):
        self.XML_eleGreenAmptParameter = []
        self.XML_eleGreenAmptParameter.append("GridValue")
        self.XML_eleGreenAmptParameter.append("USERSoil")
        self.XML_eleGreenAmptParameter.append("GRMCode")
        self.XML_eleGreenAmptParameter.append("Porosity")
        self.XML_eleGreenAmptParameter.append("EffectivePorosity")
        self.XML_eleGreenAmptParameter.append("WFSoilSuctionHead")
        self.XML_eleGreenAmptParameter.append("HydraulicConductivity")

    def Set_XML_element_SoilDepth(self):
        self.XML_eleSoilDepth = []
        self.XML_eleSoilDepth.append("GridValue")
        self.XML_eleSoilDepth.append("UserDepthClass")
        self.XML_eleSoilDepth.append("GRMCode")
        # python 버그???  SoilDepth 상위 태그와 subelement 이름이 같으면 값이 안들어감
        # 그래서 이름 다르게 넣고 나중에 Replace
        # 2020-05-27 박:오류 수정으로 변경 처리
        self.XML_eleSoilDepth.append("SoilDepth")

        self.XML_eleSoilDepth.append("SoilDepth_cm")

    def Set_XML_element_LandCover(self):
        self.XML_eleLandCover = []
        self.XML_eleLandCover.append("GridValue")
        self.XML_eleLandCover.append("UserLandCover")
        self.XML_eleLandCover.append("GRMCode")
        self.XML_eleLandCover.append("RoughnessCoefficient")
        self.XML_eleLandCover.append("ImperviousRatio")
        self.XML_eleLandCover.append("CanopyRatio")
        self.XML_eleLandCover.append("InterceptionMaxWaterCanopy_mm")


