# -*- coding: utf-8 -*-
"""
/***************************************************************************
 FlatDialog
                                 A QGIS plugin
 Flat
                             -------------------
        begin                : 2017-04-26
        git sha              : $Format:%H$
        copyright            : (C) 2017 by Hermesys
        email                : shpark@hermesys.co.kr
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""

import os

from qgis.PyQt import QtWidgets
from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtWidgets import QFileDialog

from grm.ui.FileFormat_dialog import FileFormat
from grm.lib.Regular_Expression import floatVerification, retrPdDayVerification
from grm.lib.Util import MsInfo
from grm.ui.AddFlowControl_dialog_base import Ui_FileFormatDialogBase


class AddFlowControl(QtWidgets.QDialog, Ui_FileFormatDialogBase):
    def __init__(
        self,
        _Project_Path="",
        _Flowcontrol_Edit_or_Insert_type="",
        _EditFlowControlName="",
        _EditFlowDT="",
        _EditFlowControlType="",
        _EditFlowControlDataFile="",
        _EditIniStorage="",
        _EditMaxStorage="",
        _EditNormalHighStorage="",
        _EditRestrictedStorage="",
        _EditRetiPeriodSt="",
        _EditRetiPeriodEd="",
        _EditROType="",
        _EditAutoROMmaxOutflow_CMS="",
        _EditROConstQ="",
        _EditROConstQDuration="",
        _EditDP_QThreshold_StoD_CMS="",
        _EditDP_Qi_max_CMS="",
        _EditDP_Qo_max_CMS="",
        _EditDP_Wdinlet_m="",
        _EditDP_Wstream_m="",
        _EditDP_CoefficientR_StoD="",
        _DataTimeFormat=True,  # grm_dialog_base.ui simulation 탭에서 set simulation starting time 체크박스 관련
        parent=None,
    ):
        super(AddFlowControl, self).__init__(parent)
        self.setupUi(self)

        self.project_path = _Project_Path
        self.datatimeFormat = _DataTimeFormat

        self._AddFlowcontrol_Edit_or_Insert_type = _Flowcontrol_Edit_or_Insert_type
        self._EditFlowControlName = _EditFlowControlName
        self._EditFlowDT = _EditFlowDT
        self._EditFlowControlType = _EditFlowControlType
        self._EditFlowControlDataFile = _EditFlowControlDataFile
        self._EditIniStorage = _EditIniStorage
        self._EditMaxStorage = _EditMaxStorage
        self._EditNormalHighStorage = _EditNormalHighStorage
        self._EditRestrictedStorage = _EditRestrictedStorage
        self._EditRetiPeriodSt = _EditRetiPeriodSt
        self._EditRetiPeriodEd = _EditRetiPeriodEd
        self._EditROType = _EditROType
        self._EditAutoROMmaxOutflow_CMS = _EditAutoROMmaxOutflow_CMS
        self._EditROConstQ = _EditROConstQ
        self._EditROConstQDuration = _EditROConstQDuration
        self._EditDP_QThreshold_StoD_CMS=_EditDP_QThreshold_StoD_CMS
        self._EditDP_Qi_max_CMS=_EditDP_Qi_max_CMS
        self._EditDP_Qo_max_CMS=_EditDP_Qo_max_CMS
        self._EditDP_Wdinlet_m=_EditDP_Wdinlet_m
        self._EditDP_Wstream_m=_EditDP_Wstream_m
        self._EditDP_CoefficientR_StoD=_EditDP_CoefficientR_StoD

        self._AddFlowControlDataFile = ""
        self._AddFlowControlType = ""
        self._AddFlowDT = ""
        self._AddFlowControlName = ""
        self._AddIniStorage = ""
        self._AddMaxStorage = "0"
        self._AddNormalHighStorage = "0"
        self._AddRestrictedStorage = "0"
        iniDate = "01M01D" if self.datatimeFormat else "0"
        self._AddRetiPeriodSt = iniDate
        self._AddRetiPeriodEd = iniDate
        self._AddROType = ""
        self._AddAutoROMmaxOutflow_CMS = ""
        self._AddROConstQ = ""
        self._AddROConstQDuration = ""
        self._AddDP_QThreshold_StoD_CMS="",
        self._AddDP_Qi_max_CMS="",
        self._AddDP_Qo_max_CMS="",
        self._AddDP_Wdinlet_m="",
        self._AddDP_Wstream_m="",
        self._AddDP_CoefficientR_StoD="",

        combolist = [
            "ReservoirOutflow",
            "Inlet",
            "ReservoirOperation",
            "SinkFlow",
            "SourceFlow",
            "DetensionPond",
        ]
        self.cmb_ControlType.addItems(combolist)
        self.cmb_ControlType.currentIndexChanged.connect(
            lambda: self.SelectControltype(
                self.cmb_ControlType,
                self.txt_TimeInterval,
                self.btnLoadFile,
                self.btnFileFormat,
                self.txtFilePath,
            )
        )
        self.preControlType = self.cmb_ControlType.currentText()

        self.btnLoadFile.clicked.connect(
            lambda: self.FileSelectDialog(self.txtFilePath)
        )
        self.btnFileFormat.clicked.connect(self.ViewFileFormat)
        self.rdoAutomatic.clicked.connect(self.ClickRdoAutomatic)
        self.txt_AutoROM_MaxOutflow.setEnabled(False)
        self.txt_RigidROM_Q.setEnabled(False)
        self.txt_ConstantDischarge_Duration.setEnabled(False)
        self.txt_Constant_discharge.setEnabled(False)
        self.SelectControltype(
            self.cmb_ControlType,
            self.txt_TimeInterval,
            self.btnLoadFile,
            self.btnFileFormat,
            self.txtFilePath,
        )
        self.rdoAutomatic.setChecked(True)

        self.rdoRigid.clicked.connect(self.ClickRdoRigid)
        self.rdoUsingConstant.clicked.connect(self.ClickRdoUsingConstant)
        self.btnCancel.clicked.connect(lambda: self.Close_Form(False, "cancel"))
        self.btnOK.clicked.connect(self.Ok_click)

        if self._AddFlowcontrol_Edit_or_Insert_type != "Insert":
            self.SetControlData()

        self.setWindowFlags(Qt.Window | Qt.WindowTitleHint | Qt.CustomizeWindowHint)
        self.groupBox_5.setStyleSheet("QGroupBox{padding-top:15px;margin-top:-15px;}")

    def SelectControltype(
        self, combox, txtinterval, btnLoadFile, btnFileFormat, txtFilePath
    ):
        crtTxt = combox.currentText()
        if crtTxt == "ReservoirOperation":
            self.groupBox_SetFlowData.setEnabled(False)  # set flow data
            self.txt_TimeInterval.setEnabled(False)
            self.groupBox_StorageCondition.setEnabled(True)
            self.groupBox_ResOperation.setEnabled(True)  # reservoir operation
            self.groupBox_DPparameter.setEnabled(False)

            if self.rdoAutomatic.isChecked():
                self.txt_AutoROM_MaxOutflow.setEnabled(True)
                self.txt_AutoROM_MaxOutflow.setText(self._EditAutoROMmaxOutflow_CMS)
                self.txt_RigidROM_Q.setEnabled(False)
                self.txt_Constant_discharge.setEnabled(False)
                self.txt_ConstantDischarge_Duration.setEnabled(False)
            elif self.rdoRigid.isChecked():
                self.txt_RigidROM_Q.setText(self._EditROConstQ)
                self.ClickRdoRigid()
            elif self.rdoUsingConstant.isChecked():
                self.rdoUsingConstant.setChecked(True)
                self.txt_Constant_discharge.setText(self._EditROConstQ)
                self.txt_ConstantDischarge_Duration.setText(self._EditROConstQDuration)
                self.ClickRdoUsingConstant()
        elif crtTxt in ["SinkFlow", "SourceFlow", "Inlet"]:
            self.groupBox_SetFlowData.setEnabled(True)
            self.txt_TimeInterval.setEnabled(True)
            self.groupBox_StorageCondition.setEnabled(False)
            self.groupBox_ResOperation.setEnabled(False)
            self.groupBox_DPparameter.setEnabled(False)
        elif crtTxt in ["DetensionPond"]:
            self.groupBox_SetFlowData.setEnabled(False)
            self.txt_TimeInterval.setEnabled(False)
            self.groupBox_StorageCondition.setEnabled(True)
            self.txtIniStorage.setEnabled(True)
            self.txtMaxStorage.setEnabled(True)
            self.txtNormalHighStorage.setEnabled(False)
            self.txtRestrictedStorage.setEnabled(False)
            self.txtRetiPeriodSt.setEnabled(False)
            self.txtRetiPeriodEd.setEnabled(False)
            self.groupBox_ResOperation.setEnabled(False)
            self.groupBox_DPparameter.setEnabled(True)
        else:
            self.groupBox_SetFlowData.setEnabled(True)
            self.txt_TimeInterval.setEnabled(True)
            self.groupBox_ResOperation.setEnabled(False)
            self.groupBox_StorageCondition.setEnabled(True)
            self.groupBox_DPparameter.setEnabled(False)            

        if (
            self.preControlType == "ReservoirOperation"
            or crtTxt == "ReservoirOperation"
        ):
            self.txtFilePath.setText("")

    def FileSelectDialog(self, txtpath):
        txtpath.clear()
        dir = os.path.dirname(os.path.realpath(self.project_path))
        self.filename = QFileDialog.getOpenFileName(self, "select file ", dir, "*.txt")[
            0
        ]
        txtpath.setText(self.filename)

    def ClickRdoAutomatic(self):
        self.txt_AutoROM_MaxOutflow.setEnabled(True)
        self.txt_RigidROM_Q.setEnabled(False)
        self.txt_ConstantDischarge_Duration.setEnabled(False)
        self.txt_Constant_discharge.setEnabled(False)

    def ClickRdoRigid(self):
        self.txt_AutoROM_MaxOutflow.setEnabled(False)
        self.txt_RigidROM_Q.setEnabled(True)
        self.txt_ConstantDischarge_Duration.setEnabled(False)
        self.txt_Constant_discharge.setEnabled(False)

    def ClickRdoUsingConstant(self):
        self.txt_AutoROM_MaxOutflow.setEnabled(False)
        self.txt_RigidROM_Q.setEnabled(False)
        self.txt_ConstantDischarge_Duration.setEnabled(True)
        self.txt_Constant_discharge.setEnabled(True)

    def ViewFileFormat(self):
        results = FileFormat()
        results.exec_()

    def Close_Form(self, OkCancel, insert_edit):
        if OkCancel:
            self._AddFlowcontrol_Edit_or_Insert_type = insert_edit
            self.close()
        else:
            self._AddFlowcontrol_Edit_or_Insert_type = "cancel"
            self.close()

    def keyPressEvent(self, e):
        if e.key() == 16777216:
            pass

    def Ok_click(self):
        if self._AddFlowcontrol_Edit_or_Insert_type == "Insert":
            if self.txt_Name.text().strip() == "":
                MsInfo(" Flow control name was not defined !!")
                self.txt_Name.setFocus()
                return
            else:
                self._AddFlowControlName = self.txt_Name.text()

            self._AddFlowControlType = self.cmb_ControlType.currentText()

            if self.cmb_ControlType.currentText() != "ReservoirOperation":
                if (self.txtFilePath.isEnabled() == True 
                    and self.txtFilePath.text() == ""):
                    MsInfo(" Please set the flow control data file !!")
                    self.txtFilePath.setFocus()
                    return
                else:
                    self._AddFlowControlDataFile = self.txtFilePath.text()
            else:
                #                 self._AddFlowcontrolFilePath = "ResurvoirOperation"
                self._AddFlowControlDataFile = ""

            if (self.txt_TimeInterval.isEnabled() == True 
                and self.txt_TimeInterval.text().strip() == ""):
                MsInfo(" Please enter the time interval !!")
                self.txt_TimeInterval.setFocus()
                return
            else:
                if self.txt_TimeInterval.isEnabled() == True:
                    if self.txt_TimeInterval.text().isdigit():
                        self._AddFlowDT = self.txt_TimeInterval.text()
                    else:
                        MsInfo(" Please enter the time interval !!")
                        self.txt_TimeInterval.setFocus()
                        return

            rst = self.confirmFlowValue()
            if not rst:
                return
            retrStrSt, retrStrEd, inistorg, maxstorg, normalstorg, retrstorg = rst

            self._AddIniStorage = inistorg
            self._AddMaxStorage = maxstorg
            self._AddNormalHighStorage = normalstorg
            self._AddRestrictedStorage = retrstorg
            self._AddRetiPeriodSt = retrStrSt
            self._AddRetiPeriodEd = retrStrEd

            if self.cmb_ControlType.currentText() == "ReservoirOperation":
                if self.rdoAutomatic.isChecked():
                    self._AddROType = "AutoROM"
                    self._AddAutoROMmaxOutflow_CMS = (
                        self.txt_AutoROM_MaxOutflow.text()
                    )

                elif self.rdoRigid.isChecked():
                    self._AddROType = "RigidROM"
                    self._AddROConstQ = self.txt_RigidROM_Q.text()
                    self._AddROConstQDuration = ""

                elif self.rdoUsingConstant.isChecked():
                    self._AddROType = "ConstantQ"
                    self._AddROConstQ = self.txt_Constant_discharge.text()
                    self._AddROConstQDuration = self.txt_ConstantDischarge_Duration.text()
            else:
                self._AddROType = ""
                self._AddROConstQ = ""
                self._AddROConstQDuration = ""

            if self.cmb_ControlType.currentText() == "DetensionPond":
                self._AddDP_QThreshold_StoD_CMS = self.txt_DP_thresholdQ.text()
                self._AddDP_Qi_max_CMS = self.txt_DP_MaxInflow.text()
                self._AddDP_Qo_max_CMS = self.txt_DP_MaxOutflow.text()
                self._AddDP_Wdinlet_m = self.txt_DP_Width_inlet.text()
                self._AddDP_Wstream_m = self.txt_DP_Width_stream.text()
                self._AddDP_CoefficientR_StoD = self.txt_DP_inflowCoeff.text()
            else:
                self._AddDP_QThreshold_StoD_CMS = ""
                self._AddDP_Qi_max_CMS = ""
                self._AddDP_Qo_max_CMS = ""
                self._AddDP_Wdinlet_m = ""
                self._AddDP_Wstream_m = ""
                self._AddDP_CoefficientR_StoD = ""

            self._Flowcontrolgrid_flag_Insert = True
            self.Close_Form(True, self._AddFlowcontrol_Edit_or_Insert_type)

        else: # insert 인 경우가 아니면
            if self.txt_Name.text() == "":
                MsInfo(" Flow control name was not defined !!")
                self.txt_Name.setFocus()
                return
            else:
                self._EditFlowControlName = self.txt_Name.text()

            self._EditFlowControlType = self.cmb_ControlType.currentText()
            
            if (self.txt_TimeInterval.isEnabled() == True 
                and self.txt_TimeInterval.text() == ""):
                MsInfo(" Please enter the time interval")
                self.txt_TimeInterval.setFocus()
                return
            else:
                self._EditFlowDT = self.txt_TimeInterval.text()

            if self.cmb_ControlType.currentText() != "ReservoirOperation":
                if (self.txtFilePath.isEnabled() == True 
                    and self.txtFilePath.text() == ""):
                    MsInfo(" Please set the flow control data file !!")
                    self.txtFilePath.setFocus()
                    return
                else:
                    self._EditFlowControlDataFile = self.txtFilePath.text()
            else:
                #                 self._EditFlowControlDataFile = "ReservoirOperation"
                self._EditFlowControlDataFile = ""

            rst = self.confirmFlowValue()
            if not rst:
                return
            retrStrSt, retrStrEd, inistorg, maxstorg, normalstorg, retrstorg = rst

            self._EditIniStorage = inistorg
            self._EditMaxStorage = maxstorg
            self._EditNormalHighStorage = normalstorg
            self._EditRestrictedStorage = retrstorg
            self._EditRetiPeriodSt = retrStrSt
            self._EditRetiPeriodEd = retrStrEd

            if self.cmb_ControlType.currentText() == "ReservoirOperation":
                if self.rdoAutomatic.isChecked():
                    self._EditROType = "AutoROM"
                    self._EditAutoROMmaxOutflow_CMS = self.txt_AutoROM_MaxOutflow.text()

                elif self.rdoRigid.isChecked():
                    self._EditROType = "RigidROM"
                    self._EditROConstQ = self.txt_RigidROM_Q.text()
                    self._EditROConstQDuration = ""

                elif self.rdoUsingConstant.isChecked():
                    self._EditROType = "ConstantQ"
                    self._EditROConstQ = self.txt_Constant_discharge.text()
                    self._EditROConstQDuration = self.txt_ConstantDischarge_Duration.text()
            else:
                self._EditROType = ""
                self._EditAutoROMmaxOutflow_CMS = ""
                self._EditROConstQ = ""
                self._EditROConstQDuration = ""

            if self.cmb_ControlType.currentText() == "DetensionPond":
                self._EditDP_QThreshold_StoD_CMS = self.txt_DP_thresholdQ.text()
                self._EditDP_Qi_max_CMS = self.txt_DP_MaxInflow.text()
                self._EditDP_Qo_max_CMS = self.txt_DP_MaxOutflow.text()
                self._EditDP_Wdinlet_m = self.txt_DP_Width_inlet.text()
                self._EditDP_Wstream_m = self.txt_DP_Width_stream.text()
                self._EditDP_CoefficientR_StoD = self.txt_DP_inflowCoeff.text()
            else:
                self._EditDP_QThreshold_StoD_CMS = ""
                self._EditDP_Qi_max_CMS = ""
                self._EditDP_Qo_max_CMS = ""
                self._EditDP_Wdinlet_m = ""
                self._EditDP_Wstream_m = ""
                self._EditDP_CoefficientR_StoD = ""

            self.Close_Form(True, self._AddFlowcontrol_Edit_or_Insert_type)

    def confirmFlowValue(self):
        retrStrSt = self.txtRetiPeriodSt.text().strip().upper()
        retrStrEd = self.txtRetiPeriodEd.text().strip().upper()
        inistorg = self.txtIniStorage.text().strip()
        maxstorg = self.txtMaxStorage.text().strip()
        normalstorg = self.txtNormalHighStorage.text().strip()
        retrstorg = self.txtRestrictedStorage.text().strip()
        l = [retrStrSt, retrStrEd, inistorg, maxstorg, normalstorg, retrstorg]

        for sto in l[2:]:
            if sto and not floatVerification(sto):
                MsInfo("Enter a number as storage value.")
                return False
        if (
            (l[:2] != [""] * 2)
            and (self.datatimeFormat)
            and (
                not retrPdDayVerification(retrStrSt)
                or not retrPdDayVerification(retrStrEd)
            )
        ):
            MsInfo(
                " Enter the Restricted period in the following format. \n mmMddD ex) 01M01D"
            )
            return False
        elif (
            (l[:2] != [""] * 2)
            and (not self.datatimeFormat)
            and (not floatVerification(retrStrSt) or not floatVerification(retrStrEd))
        ):  # 숫자형식
            MsInfo(" Enter a number in Restricted period. ")
            return False

        for i, j in enumerate(l):
            if self.datatimeFormat and i < 2 and not j:
                l[i] = "01M01D"
            elif (not self.datatimeFormat and i < 2 and not j) or i > 2 and not j:
                l[i] = "0"

        return l

    def SetControlData(self):
        self.txt_Name.setText(self._EditFlowControlName)
        controltype = self._EditFlowControlType
        index = self.cmb_ControlType.findText(str(controltype), Qt.MatchFixedString)
        if index >= 0:
            self.cmb_ControlType.setCurrentIndex(index)
        self.txt_TimeInterval.setText(self._EditFlowDT)
        self.txtFilePath.setText(self._EditFlowControlDataFile)
        self.txtIniStorage.setText(self._EditIniStorage)
        self.txtMaxStorage.setText(self._EditMaxStorage)
        self.txtNormalHighStorage.setText(self._EditNormalHighStorage)
        self.txtRestrictedStorage.setText(self._EditRestrictedStorage)
        self.txtRetiPeriodSt.setText(self._EditRetiPeriodSt)
        self.txtRetiPeriodEd.setText(self._EditRetiPeriodEd)

        if self._EditROType == "AutoROM":
            self.rdoAutomatic.setChecked(True)
            self.txt_AutoROM_MaxOutflow.setText(self._EditAutoROMmaxOutflow_CMS)
            self.ClickRdoAutomatic()
        elif self._EditROType == "RigidROM":
            self.rdoRigid.setChecked(True)
            self.txt_RigidROM_Q.setText(self._EditROConstQ)
            self.ClickRdoRigid()
        elif self._EditROType == "ConstantQ":
            self.rdoUsingConstant.setChecked(True)
            self.txt_Constant_discharge.setText(self._EditROConstQ)
            self.txt_ConstantDischarge_Duration.setText(self._EditROConstQDuration)
            self.ClickRdoUsingConstant()

        self.txt_DP_thresholdQ.setText( self._EditDP_QThreshold_StoD_CMS)
        self.txt_DP_MaxInflow.setText(self._EditDP_Qi_max_CMS)
        self.txt_DP_MaxOutflow.setText(self._EditDP_Qo_max_CMS)
        self.txt_DP_Width_inlet.setText(self._EditDP_Wdinlet_m)
        self.txt_DP_Width_stream.setText(self._EditDP_Wstream_m)
        self.txt_DP_inflowCoeff.setText(self._EditDP_CoefficientR_StoD)
