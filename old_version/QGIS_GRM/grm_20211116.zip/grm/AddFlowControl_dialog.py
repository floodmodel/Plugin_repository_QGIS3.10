# -*- coding: utf-8 -*-
"""
/***************************************************************************
 FlatDialog
                                 A QGIS plugin
 Flat
                             -------------------
        begin                : 2017-04-26
        git sha              : $Format:%H$
        copyright            : (C) 2017 by Hermesys
        email                : shpark@hermesys.co.kr
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""

import os

from qgis.PyQt import QtGui, QtWidgets, uic
from qgis.PyQt import QtWidgets
from qgis.core import *
from qgis.gui import *

from PyQt5 import uic
from PyQt5 import QtWidgets
from PyQt5.QtWidgets import *
from PyQt5.QtCore import Qt
from PyQt5.QtGui import *
from .FileFormat_dialog import FileFormat
import xml.etree.ElementTree as ET
from .lib.Util import *

_FilePath = ""

FORM_CLASS, _ = uic.loadUiType(os.path.join(os.path.dirname(__file__), 'AddFlowControl_dialog_base.ui'))


class AddFlowControl(QtWidgets.QDialog, FORM_CLASS):
    def __init__(self,
                 _Flowcontrol_Edit_or_Insert_type="",
                 _EditFlowName="",_EditFlowDT="",
                 _EditFlowControlType="",_EditFlowFlowDataFile="",
                 _EditFlowIniStorage="",_EditFlowMaxStorage="",
                 _EditFlowMaxStorageR="",_EditFlowROType="",
                 _EditFlowROConstQ="",_EditFlowROConstQDuration="",
                 parent=None):
        super(AddFlowControl, self).__init__(parent)
        self.setupUi(self)
        self._AddFlowcontrol_Edit_or_Insert_type=_Flowcontrol_Edit_or_Insert_type
        self._EditFlowName=_EditFlowName
        self._EditFlowDT=_EditFlowDT
        self._EditFlowControlType=_EditFlowControlType
        self._EditFlowFlowDataFile=_EditFlowFlowDataFile
        self._EditFlowIniStorage=_EditFlowIniStorage
        self._EditFlowMaxStorage=_EditFlowMaxStorage
        self._EditFlowMaxStorageR=_EditFlowMaxStorageR
        self._EditFlowROType=_EditFlowROType
        self._EditFlowROConstQ=_EditFlowROConstQ
        self._EditFlowROConstQDuration=_EditFlowROConstQDuration

        self._AddFlowcontrolFilePath=""
        self._AddFlowcontrolType=""
        self._AddFlowcontrolTimeInterval=""
        self._AddFlowcontrolName=""
        self._AddFlowcontrol_IniStorage=""
        self._AddFlowcontrol_MaxStorage=""
        self._AddFlowcontrol_MaxStorageR=""
        self._AddFlowcontrol_ROType=""
        self._AddFlowcontrol_ROConstQ=""
        self._AddFlowcontrol_ROConstQDuration=""


        combolist = ['ReservoirOutflow', 'Inlet', 'ReservoirOperation', 'SinkFlow','SourceFlow']
        self.cmb_ControlType.addItems(combolist)
        self.cmb_ControlType.currentIndexChanged.connect(
            lambda: self.SelectControtype(self.cmb_ControlType, self.txt_TimeInterval, self.btnLoadFile,
                                          self.btnFileFormat, self.txtFilePath))
        self.btnLoadFile.clicked.connect(lambda: self.FileSelectDialog(self.txtFilePath))
        self.btnFileFormat.clicked.connect(self.ViewFileFormat)
        self.rdoAutomatic.clicked.connect(self.ClickRdoAutomatic)
        self.txt_cms.setEnabled(False)
        self.txt_hours.setEnabled(False)
        self.txt_Constant_discharge.setEnabled(False)
        self.SelectControtype(self.cmb_ControlType, self.txt_TimeInterval, self.btnLoadFile,self.btnFileFormat, self.txtFilePath)
        self.rdoAutomatic.setChecked(True)

        self.rdoRigid.clicked.connect(self.ClickRdoRigid)
        self.rdoUsingConstant.clicked.connect(self.ClickRdoUsingConstant)
        self.btnCancel.clicked.connect(lambda : self.Close_Form(False,"cancel"))
        self.btnOK.clicked.connect(self.Ok_click)

        if self._AddFlowcontrol_Edit_or_Insert_type != "Insert":
            self.SetControlData()

        self.setWindowFlags(Qt.Window | Qt.WindowTitleHint | Qt.CustomizeWindowHint)
        self.groupBox_5.setStyleSheet("QGroupBox{padding-top:15px;margin-top:-15px;}")

    def SelectControtype(self, combox, txtinterval, btnLoadFile, btnFileFormat, txtFilePath):
        if combox.currentText() == "ReservoirOperation":
            txtinterval.setEnabled(True)
            btnLoadFile.setEnabled(False)
            btnFileFormat.setEnabled(False)
            txtFilePath.setEnabled(False)
            self.txtIniStorage.setEnabled(True)
            self.txtMaxStorage.setEnabled(True)
            self.txtMaxStorageRatio.setEnabled(True)
            self.rdoAutomatic.setEnabled(True)
            self.rdoRigid.setEnabled(True)
            self.rdoUsingConstant.setEnabled(True)
            # self.txt_cms.setEnabled(True)
            # self.txt_Constant_discharge.setEnabled(True)
            # self.txt_hours.setEnabled(True)


            if self.rdoAutomatic.isChecked():
                self.txt_cms.setEnabled(False)
                self.txt_Constant_discharge.setEnabled(False)
                self.txt_hours.setEnabled(False)
            elif self.rdoRigid.isChecked():
                self.txt_cms.setText(self._EditFlowROConstQ)
                self.ClickRdoRigid()
            elif self.rdoUsingConstant.isChecked():
                self.rdoUsingConstant.setChecked(True)
                self.txt_Constant_discharge.setText(self._EditFlowROConstQ)
                self.txt_hours.setText(self._EditFlowROConstQDuration)
                self.ClickRdoUsingConstant()




        else:
            txtinterval.setEnabled(True)
            btnLoadFile.setEnabled(True)
            btnFileFormat.setEnabled(True)
            txtFilePath.setEnabled(True)
            self.txtIniStorage.setEnabled(False)
            self.txtMaxStorage.setEnabled(False)
            self.txtMaxStorageRatio.setEnabled(False)
            self.rdoAutomatic.setEnabled(False)
            self.rdoRigid.setEnabled(False)
            self.rdoUsingConstant.setEnabled(False)
            self.txt_cms.setEnabled(False)
            self.txt_Constant_discharge.setEnabled(False)
            self.txt_hours.setEnabled(False)

    def FileSelectDialog(self, txtpath):
        txtpath.clear();
        dir = os.path.dirname(os.path.realpath(__file__))
        self.filename = QFileDialog.getOpenFileName(self, "select file ", dir, "*.txt")[0]
        txtpath.setText(self.filename)

    def ClickRdoAutomatic(self):
        self.txt_cms.setEnabled(False)
        self.txt_hours.setEnabled(False)
        self.txt_Constant_discharge.setEnabled(False)

    def ClickRdoRigid(self):
        self.txt_cms.setEnabled(True)
        self.txt_hours.setEnabled(False)
        self.txt_Constant_discharge.setEnabled(False)

    def ClickRdoUsingConstant(self):
        self.txt_cms.setEnabled(False)
        self.txt_hours.setEnabled(True)
        self.txt_Constant_discharge.setEnabled(True)

    def ViewFileFormat(self):
        results = FileFormat()
        results.exec_()

    def Close_Form(self,OkCancel,insert_edit):
        if OkCancel:
            self._AddFlowcontrol_Edit_or_Insert_type =insert_edit
            self.close()
        else:
            self._AddFlowcontrol_Edit_or_Insert_type= "cancel"
            self.close()

    def keyPressEvent(self, e):
        if e.key()==16777216:
            pass
        
    def Ok_click(self):
        if self._AddFlowcontrol_Edit_or_Insert_type == "Insert":
            if self.txt_Name.text().strip() =="" :
                MsInfo(" Input name, please")
                self.txt_Name.setFocus()
                return
            else:
                self._AddFlowcontrolName = self.txt_Name.text()
                
            self._AddFlowcontrolType = self.cmb_ControlType.currentText()
            if self.txt_TimeInterval.text().strip() == "":
                MsInfo(" Please enter a time interval")
                self.txt_TimeInterval.setFocus()
                return
            else:
                if self.txt_TimeInterval.text().isdigit():
                    self._AddFlowcontrolTimeInterval = self.txt_TimeInterval.text()
                else: 
                    MsInfo(" Please enter a time interval")
                    self.txt_TimeInterval.setFocus()
                    return
            if self.cmb_ControlType.currentText() != "ReservoirOperation":
                if self.txtFilePath.text()=="":
                    MsInfo("Please enter only numbers")
                    self.txtFilePath.setFocus()
                    return
                else:
                    self._AddFlowcontrolFilePath = self.txtFilePath.text()
            else :
                self._EditFlowFlowDataFile = "ResurvoirOperation"
            if self.cmb_ControlType.currentText() == "ReservoirOperation":
                if self.txtIniStorage.text() !="":
                    self._AddFlowcontrol_IniStorage = self.txtIniStorage.text()
                if self.txtMaxStorage.text()!="":
                    self._AddFlowcontrol_MaxStorage = self.txtMaxStorage.text()
                if self.txtMaxStorageRatio.text()!="":
                    self._AddFlowcontrol_MaxStorageR = self.txtMaxStorageRatio.text()
                if self.rdoAutomatic.isChecked():
                    self._AddFlowcontrol_ROType = "AutoROM"

                elif self.rdoRigid.isChecked():
                    self._AddFlowcontrol_ROType = "RigidROM"
                    self._AddFlowcontrol_ROConstQ = self.txt_cms.text()

                elif self.rdoUsingConstant.isChecked():
                    self._AddFlowcontrol_ROType = "ConstantQ"
                    self._AddFlowcontrol_ROConstQ = self.txt_Constant_discharge.text()
                    self._AddFlowcontrol_ROConstQDuration = self.txt_hours.text()
                self._Flowcontrolgrid_flag_Insert = True
            else:
                self._AddFlowcontrol_IniStorage = ""
                self._AddFlowcontrol_MaxStorage = ""
                self._AddFlowcontrol_MaxStorageR = ""
                self._AddFlowcontrol_ROType = ""
                self._AddFlowcontrol_ROConstQ = ""
                self._AddFlowcontrol_ROConstQDuration = ""
                self._Flowcontrolgrid_flag_Insert = True
            self.Close_Form(True,self._AddFlowcontrol_Edit_or_Insert_type)

        else:
            if self.txt_Name.text() == "":
                MsInfo(" Input name, please")
                self.txt_Name.setFocus()
                return
            else:
                self._EditFlowName = self.txt_Name.text()

            self._EditFlowControlType = self.cmb_ControlType.currentText()

            if self.txt_TimeInterval.text() == "":
                MsInfo(" Please enter a time interval")
                self.txt_TimeInterval.setFocus()
                return
            else:
                self._EditFlowDT = self.txt_TimeInterval.text()

            if self.cmb_ControlType.currentText() != "ReservoirOperation":
                if self.txtFilePath.text() == "":
                    MsInfo(" Please set file path")
                    self.txtFilePath.setFocus()
                    return
                else:
                    self._EditFlowFlowDataFile = self.txtFilePath.text()
            else:
                self._EditFlowFlowDataFile = "ResurvoirOperation"

            if self.cmb_ControlType.currentText() == "ReservoirOperation":
                if self.txtIniStorage.text() != "":
                    self._EditFlowIniStorage = self.txtIniStorage.text()

                if self.txtMaxStorage.text() != "":
                    self._EditFlowMaxStorage = self.txtMaxStorage.text()

                if self.txtMaxStorageRatio.text() != "":
                    self._EditFlowMaxStorageR = self.txtMaxStorageRatio.text()

                if self.rdoAutomatic.isChecked():
                    self._EditFlowROType = "AutoROM"

                elif self.rdoRigid.isChecked():
                    self._EditFlowROType = "RigidROM"
                    self._EditFlowROConstQ = self.txt_cms.text()

                elif self.rdoUsingConstant.isChecked():
                    self._EditFlowROType = "ConstantQ"
                    self._EditFlowROConstQ = self.txt_Constant_discharge.text()
                    self._EditFlowROConstQDuration = self.txt_hours.text()
            else:
                self._EditFlowIniStorage = ""
                self._EditFlowMaxStorage = ""
                self._EditFlowMaxStorageR = ""
                self._EditFlowROType = ""
                self._EditFlowROConstQ = ""
                self._EditFlowROConstQDuration = self.txt_hours.text()
            self.Close_Form(True,self._AddFlowcontrol_Edit_or_Insert_type)


    def SetControlData(self):
        self.txt_Name.setText(self._EditFlowName)
        controltype =self._EditFlowControlType
        index = self.cmb_ControlType.findText(str(controltype), Qt.MatchFixedString)
        if index >= 0:
            self.cmb_ControlType.setCurrentIndex(index)
        self.txt_TimeInterval.setText(self._EditFlowDT)
        self.txtFilePath.setText(self._EditFlowFlowDataFile)
        self.txtIniStorage.setText(self._EditFlowIniStorage)
        self.txtMaxStorage.setText(self._EditFlowMaxStorage)
        self.txtMaxStorageRatio.setText(self._EditFlowMaxStorageR)

        if self._EditFlowROType == "AutoROM":
            self.rdoAutomatic.setChecked(True)
        elif self._EditFlowROType == "RigidROM":
            self.rdoRigid.setChecked(True)
            self.txt_cms.setText(self._EditFlowROConstQ)
            self.ClickRdoRigid()
        elif self._EditFlowROType == "ConstantQ":
            self.rdoUsingConstant.setChecked(True)
            self.txt_Constant_discharge.setText(self._EditFlowROConstQ )
            self.txt_hours.setText(self._EditFlowROConstQDuration)
            self.ClickRdoUsingConstant()
        self.SelectControtype(self.cmb_ControlType, self.txt_TimeInterval, self.btnLoadFile,
                              self.btnFileFormat, self.txtFilePath)

    #def UpdateEditTable(self):
    #    self._FlowControlTable.setItem(self._EditFlowCurrentRow, 0, QTableWidgetItem(self._EditFlowName))
    #    self._FlowControlTable.setItem(self._EditFlowCurrentRow, 3, QTableWidgetItem(self._EditFlowDT))
    #    self._FlowControlTable.setItem(self._EditFlowCurrentRow, 4, QTableWidgetItem(self._EditFlowControlType))
    #    self._FlowControlTable.setItem(self._EditFlowCurrentRow, 5, QTableWidgetItem(self._EditFlowFlowDataFile))
    #    self._FlowControlTable.setItem(self._EditFlowCurrentRow, 6, QTableWidgetItem(self._EditFlowIniStorage))
    #    self._FlowControlTable.setItem(self._EditFlowCurrentRow, 7, QTableWidgetItem(self._EditFlowMaxStorage))
    #    self._FlowControlTable.setItem(self._EditFlowCurrentRow, 8, QTableWidgetItem(self._EditFlowMaxStorageR))
    #    self._FlowControlTable.setItem(self._EditFlowCurrentRow, 9, QTableWidgetItem(self._EditFlowROType))
    #    self._FlowControlTable.setItem(self._EditFlowCurrentRow, 10, QTableWidgetItem(self._EditFlowROConstQ))
    #    self._FlowControlTable.setItem(self._EditFlowCurrentRow, 11, QTableWidgetItem(self._EditFlowROConstQDuration))




        # if self.rdoAutomatic.isChecked():
        #     self._AddFlowcontrol_ROType = "AutoROM"
        #
        # elif self.rdoRigid.isChecked():
        #     self._AddFlowcontrol_ROType = "RigidROM"
        #     self._AddFlowcontrol_ROConstQ = self.txt_cms.text()
        #
        # elif self.rdoUsingConstant.isChecked():
        #     self._AddFlowcontrol_ROType = "ConstantQ"
        #     self._AddFlowcontrol_ROConstQ = self.txt_Constant_discharge.text()
        #     self._AddFlowcontrol_ROConstQDuration = self.txt_hours.text()



        # self.txt_cms(self._Edit)
        #
        # rdoAutomatic
        # rdoRigid
        # rdoUsingConstant


        # count  = _util.FlowControlGrid_XmlCount()
        # if self._Flowcontrolgrid_xmlCount==1:
        #     self.txt_Name.setText(GRM._xmltodict['GRMProject']['FlowControlGrid']['Name'])
        #     controltype =GRM._xmltodict['GRMProject']['FlowControlGrid']['ControlType']
        #     self.txt_TimeInterval.setText(GRM._xmltodict['GRMProject']['FlowControlGrid']['DT'])
        #     self.txtFilePath.setText(GRM._xmltodict['GRMProject']['FlowControlGrid']['FlowDataFile'])
        #
        # elif self._Flowcontrolgrid_xmlCount>1:
        #     for flowitem in GRM._xmltodict['GRMProject']['FlowControlGrid']:
        #         if flowitem['ColX']==self._ClickX and flowitem['RowY'] == self._ClickY :
        #             self.txt_Name.setText(flowitem['Name'])
        #             controltype = flowitem['ControlType']
        #             self.txt_TimeInterval.setText(flowitem['DT'])
        #             self.txtFilePath.setText(flowitem['FlowDataFile'])
        #             return
        #






        # if 'Name' in GRM._xmltodict['GRMProject']['FlowControlGrid']:
        #     _util.MessageboxShowError("count", "1")
        #     for flowitem in GRM._xmltodict['GRMProject']['FlowControlGrid']:
        #         _util.MessageboxShowError("count", "2")
        #         test.append(flowitem['name@'])
        #         _util.MessageboxShowError("count", "3")
        #         # _util.MessageboxShowError("count",str(len(test)))
        # else:
        #     _util.MessageboxShowError("OUT", "OUT")






        # ProjectFile = GRM._xmltodict['GRMProject']['ProjectSettings']['ProjectFile']
        # doc = ET.parse(ProjectFile)
        # root = doc.getroot()
        # for element in root.findall('{http://tempuri.org/GRMProject.xsd}FlowControlGrid'):
        #     # if x== element.findtext("{http://tempuri.org/GRMProject.xsd}ColX") and y ==element.findtext("{http://tempuri.org/GRMProject.xsd}RowY") :
        #     if element.findtext("{http://tempuri.org/GRMProject.xsd}ColX")=="90" and element.findtext("{http://tempuri.org/GRMProject.xsd}RowY")=="51":
        #         self.txt_Name.setText(element.findtext("{http://tempuri.org/GRMProject.xsd}Name"))
        #         self.txt_TimeInterval.setText(element.findtext("{http://tempuri.org/GRMProject.xsd}DT"))
        #         self.txtFilePath.setText(element.findtext("{http://tempuri.org/GRMProject.xsd}FlowDataFile"))
        #         self.txtIniStorage.setText(element.findtext("{http://tempuri.org/GRMProject.xsd}IniStorage"))
        #         self.txtMaxStorage.setText(element.findtext("{http://tempuri.org/GRMProject.xsd}MaxStorage"))
        #         self.txtMaxStorageRatio.setText(element.findtext("{http://tempuri.org/GRMProject.xsd}MaxStorageR"))
        #         types=element.findtext("{http://tempuri.org/GRMProject.xsd}ROType")
        #         if types=="AutoROM":
        #             self.rdoAutomatic.setChecked(True)
        #         elif types == "RigidROM":
        #             self.rdoRigidsetChecked(True)
        #         elif types == "ConstantQ":
        #             self.rdoUsingStorageEqation.setChecked(True)
        #
        #         self.txt_Constant_discharge.setText(element.findtext("{http://tempuri.org/GRMProject.xsd}ROConstQ"))
        #         self.txt_hours.setText(element.findtext("{http://tempuri.org/GRMProject.xsd}ROConstQDuration"))
        #         self.txt_hours.setText(element.findtext("{http://tempuri.org/GRMProject.xsd}ROConstQDuration"))
        #







                # self.tlbFlowControl.setItem(row, 4, QTableWidgetItem(element.findtext("{http://tempuri.org/GRMProject.xsd}ControlType")))
                # self.tlbFlowControl.setItem(row, 5, QTableWidgetItem(element.findtext("{http://tempuri.org/GRMProject.xsd}FlowDataFile")))
                # row = row + 1


