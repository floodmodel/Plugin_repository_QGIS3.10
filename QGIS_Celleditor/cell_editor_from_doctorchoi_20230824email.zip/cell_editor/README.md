# Serval

Serval is a QGIS plugin for setting raster cell values.

**Warning**: Any changes of a raster cell value are immediately written to disk. Make a copy of your precious raster.

See [wiki page](https://github.com/erpas/serval/wiki) for details.

## License

Serval is a free/libre software and is licensed under the GNU General Public License.